function initializeApp() {
  const audioManager = new AudioManager();
  let level;
  const handleStartGame = () => {
    document.getElementById('start-screen').classList.add('hidden');
    level = level || new FirstPersonLevel(audioManager, () => {
      document.getElementById('game-screen').classList.add('hidden');
      document.getElementById('game-screen').classList.remove('active');
      document.getElementById('start-screen').classList.remove('hidden');
      document.getElementById('start-screen').classList.add('active');
    });
    level.start();
  };

  new MainMenu(audioManager, handleStartGame);
}

document.addEventListener('DOMContentLoaded', initializeApp);
