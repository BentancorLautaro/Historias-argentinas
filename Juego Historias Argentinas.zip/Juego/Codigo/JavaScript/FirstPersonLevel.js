/**
 * Instancia jugable del Sprint 2.
 * Mecánica: leer diarios -> recolectar frases clave -> relacionar 12 recortes
 * en 4 tríadas. Cada tríada mezcla, en general, ideas de diarios diferentes.
 */
class FirstPersonLevel {
  constructor(audioManager, onExit) {
    this.audioManager = audioManager;
    this.onExit = onExit;
    this.gameWorld = document.getElementById('game-world');
    this.gameScreen = document.getElementById('game-screen');
    this.modal = document.getElementById('newspaper-modal');
    this.quizModal = document.getElementById('quiz-modal');
    this.boardModal = document.getElementById('board-modal');
    this.completeModal = document.getElementById('level-complete');

    this.collected = new Set();
    this.currentPaper = 0;
    this.currentKeys = new Set();
    this.quizIndex = 0;
    this.quizScore = 0;
    this.boardSelection = [];
    this.boardGroupsCompleted = new Set();
    this.boardScore = 0;

    // Periódicos reales del período; los textos del juego son recreaciones didácticas,
    // no transcripciones de ejemplares históricos.
    this.papers = [
      {
        title: 'LA GACETA MERCANTIL',
        shortTitle: 'LA GACETA MERCANTIL',
        date: 'Buenos Aires · 1845 · Edición del día',
        issue: 'DIARIO COMERCIAL, POLÍTICO Y LITERARIO',
        kicker: 'DEBATES DE LA CONFEDERACIÓN',
        headline: 'La autoridad provincial y el orden político vuelven al centro de la discusión',
        deck: 'Noticias, comentarios y correspondencias de la jornada reunidas en una portada de amplio registro.',
        columns: [
          [
            'Las conversaciones públicas de esta jornada vuelven a detenerse en la marcha de los asuntos provinciales. En calles, comercios y oficinas se comenta la conveniencia de conservar el orden y sostener la administración de los negocios públicos.',
            'Desde distintos puntos llegan noticias sobre disposiciones, reuniones y movimientos que interesan a la vida política. La circulación de cartas y partes mantiene atentos a los lectores que siguen de cerca cuanto ocurre en Buenos Aires y en las provincias.',
            'En este escenario, la autoridad provincial aparece entre los asuntos más discutidos. Los redactores señalan que toda decisión administrativa repercute en la tranquilidad de la población y en la marcha de las actividades cotidianas.',
            'Las costumbres rurales también aparecen en una breve nota remitida desde la campaña. Las relaciones entre Buenos Aires y las demás provincias continúan ocupando un espacio importante. Se esperan nuevas informaciones sobre comunicaciones, acuerdos y diferencias entre las distintas autoridades.'
          ],
          [
            'También llegan breves referencias al movimiento del comercio y a la llegada de embarcaciones. El movimiento portuario despierta especial atención entre comerciantes y viajeros. Los vendedores y consignatarios siguen con atención las noticias del puerto, mientras los viajeros comentan las novedades recogidas en los caminos.',
            'En los cafés y lugares de reunión se intercambian opiniones sobre la organización política. Unos reclaman mayor estabilidad; otros discuten la forma en que deben distribuirse las atribuciones y responsabilidades.',
            'Los lectores encuentran asimismo notas sobre acontecimientos de la ciudad, disposiciones municipales y avisos comerciales. La jornada transcurre entre noticias de interés público y asuntos propios de la vida diaria.',
            'Al cierre de la edición, las novedades recibidas desde el interior son todavía materia de comentario. La situación regional continúa siendo observada con atención por quienes siguen los asuntos de la Confederación.'
          ]
        ],
        keys: ['autoridad provincial', 'costumbres rurales', 'movimiento portuario']
      },
      {
        title: 'DIARIO DE LA TARDE',
        shortTitle: 'DIARIO DE LA TARDE',
        date: 'Buenos Aires · 1845 · Edición de la tarde',
        issue: 'INFORMACIÓN POLÍTICA Y DE LA CIUDAD',
        kicker: 'VIDA PÚBLICA',
        headline: 'La ciudad y la campaña ofrecen escenas diversas de la vida rioplatense',
        deck: 'Crónicas breves, costumbres, avisos y comentarios de la jornada para los lectores de la ciudad.',
        columns: [
          [
            'Desde primeras horas se observa movimiento en las calles principales. Carretas, vendedores, trabajadores y viajeros se cruzan con el tránsito habitual de la ciudad, mientras los comercios reciben mercaderías llegadas de distintos puntos.',
            'Los cronistas describen una vida urbana animada por conversaciones en las plazas, reuniones familiares y diligencias que mantienen ocupados a los habitantes. Entre los asuntos de la jornada también aparecen las noticias políticas recibidas durante la mañana.',
            'Más allá de las calles céntricas, las comunicaciones provenientes de la campaña presentan otra escena. El trabajo cotidiano, los viajes y las reuniones de vecinos muestran costumbres que los lectores reconocen como parte de la vida provincial.',
            'En los comentarios sobre estas regiones aparece con frecuencia la figura del gaucho, vinculada a los desplazamientos, las tareas rurales y las formas de sociabilidad del campo.'
          ],
          [
            'Los avisos comerciales anuncian ventas, alquileres, diligencias y servicios diversos. Cada noticia ofrece una pequeña imagen de las ocupaciones que sostienen la actividad diaria de la población.',
            'Las diferencias entre la ciudad y la campaña no impiden que ambas formen parte de una misma sociedad. Las cartas de los corresponsales muestran que las personas se desplazan, comercian y mantienen vínculos entre distintos espacios.',
            'En los hogares y lugares de reunión se comentan igualmente espectáculos. La vida pública continúa siendo tema de conversación en plazas y establecimientos., novedades y acontecimientos locales. Los redactores dedican algunas líneas a describir modas, reuniones y hábitos que despiertan curiosidad entre los lectores.',
            'La edición concluye con breves informes recibidos de los alrededores y con avisos para la siguiente jornada. La vida pública y las noticias de costumbres vuelven a ocupar un lugar destacado.'
          ]
        ],
        keys: ['vida urbana', 'figura del gaucho', 'vida pública']
      },
      {
        title: 'EL COMERCIO DEL PLATA',
        shortTitle: 'EL COMERCIO DEL PLATA',
        date: 'Montevideo · 1845 · Edición del día',
        issue: 'DIARIO POLÍTICO, COMERCIAL Y LITERARIO',
        kicker: 'RÍO DE LA PLATA',
        headline: 'Puertos, mercados y política comparten espacio en las noticias del Plata',
        deck: 'La edición reúne correspondencias, movimientos marítimos, actividad comercial y comentarios sobre la situación regional.',
        columns: [
          [
            'La mañana comienza con noticias de los muelles y de la llegada de embarcaciones. Comerciantes, cargadores y agentes observan con atención los movimientos que pueden alterar el ritmo de las operaciones.',
            'En las plazas y almacenes se habla de precios, contratos y novedades recibidas de otros puertos. La actividad comercial mantiene un movimiento constante y reúne a viajeros llegados desde distintos puntos de la región.',
            'Los corresponsales también dedican espacio a los sucesos políticos. La situación de los gobiernos y las disputas entre distintos proyectos de organización son observadas por quienes participan de los negocios y del tráfico regional.',
            'Entre las notas de la jornada se hace referencia a la organización política, asunto que vuelve a aparecer en cartas y comentarios enviados desde Buenos Aires y otras localidades.'
          ],
          [
            'Los barcos que parten llevan mercancías hacia distintos destinos y reciben cargas destinadas a nuevos mercados. El movimiento portuario mantiene ocupados a numerosos trabajadores durante buena parte del día.',
            'Una variación en las noticias políticas puede cambiar expectativas sobre el comercio, los caminos y la circulación de personas. Por ese motivo, las informaciones de gobierno se leen junto con las novedades económicas.',
            'La edición incluye además avisos para comerciantes, anuncios de servicios y referencias a viajeros. En el mercado regional se observan cambios que interesan a vendedores y compradores. La variedad de asuntos procura ofrecer una imagen amplia de lo que sucede a ambos lados del río.',
            'A última hora llegan nuevas correspondencias. Los redactores las incorporan a la edición para que los lectores puedan seguir el desarrollo de los acontecimientos regionales.'
          ]
        ],
        keys: ['actividad comercial', 'organización política', 'mercado regional']
      },
      {
        title: 'BRITISH PACKET AND ARGENTINE NEWS',
        shortTitle: 'BRITISH PACKET',
        date: 'Buenos Aires · 1845 · Edición del día',
        issue: 'NEWS, COMMERCE AND RIVER PLATE AFFAIRS',
        kicker: 'RIVER PLATE NEWS',
        headline: 'Noticias y correspondencias presentan distintas miradas sobre los asuntos del Plata',
        deck: 'Información política, comercial y regional reunida a partir de despachos, cartas y novedades recibidas.',
        columns: [
          [
            'La presente edición reúne informes recibidos desde Buenos Aires, Montevideo y otros puntos del Río de la Plata. Comerciantes y corresponsales siguen con atención los acontecimientos que afectan el movimiento y el intercambio.',
            'Los despachos políticos ocupan un lugar destacado. Los lectores buscan noticias sobre las decisiones de las autoridades y sobre los cambios que atraviesan a la región.',
            'Varias notas describen el peso de Buenos Aires en la vida política y comercial del área. Las cartas de viajeros y residentes aportan observaciones reunidas en distintos puntos.',
            'Al mismo tiempo, los buques, las cargas y los acuerdos comerciales aparecen con frecuencia entre las correspondencias recibidas por la redacción.'
          ],
          [
            'Las noticias del puerto informan llegadas y partidas, mientras los comerciantes intercambian datos sobre precios y entregas previstas. La circulación de mercancías mantiene una relación estrecha con el clima político.',
            'Los informes procedentes de distintas fuentes no siempre presentan los acontecimientos del mismo modo. Por ello, los lectores comparan declaraciones y consideran las circunstancias en que fue escrita cada relación.',
            'La edición incluye además avisos sobre viajeros, comercio local y correspondencias. Este material permite seguir la situación regional más allá de un único punto de vista.',
            'Se esperan nuevas cartas para la próxima edición. Mientras tanto, las noticias reunidas ofrecen una visión amplia de los asuntos políticos y comerciales del Río de la Plata.'
          ]
        ],
        keys: ['peso de Buenos Aires', 'circulación de mercancías', 'correspondencias']
      }
    ];

    this.quiz = [
      {
        q: '¿Qué relación ayuda a comprender mejor el conflicto político?',
        options: ['Autoridad provincial y organización política', 'Mar y montaña', 'Comercio y clima'],
        answer: 0,
        explain: 'Los diarios permiten relacionar el poder provincial con las distintas formas de organizar la vida política.'
      },
      {
        q: '¿Qué contraste social aparece en las fuentes?',
        options: ['Ciudad y campo', 'Invierno y verano', 'Noche y mañana'],
        answer: 0,
        explain: 'La vida urbana y rural aparece como un contraste útil para interpretar distintas formas de vida y costumbres.'
      },
      {
        q: '¿Qué temas pueden aparecer conectados en la prensa rioplatense?',
        options: ['Política, comercio y circulación', 'Color, tamaño y deporte', 'Velocidad, sonido y clima'],
        answer: 0,
        explain: 'Las fuentes presentan noticias políticas y comerciales dentro de un mismo escenario regional.'
      },
      {
        q: '¿Qué permite comparar varios diarios?',
        options: ['Reconocer cómo distintas fuentes presentan ideas relacionadas', 'Eliminar las diferencias entre fuentes', 'Copiar todos los textos sin analizarlos'],
        answer: 0,
        explain: 'La comparación de fuentes permite identificar ideas relacionadas que pueden venir de publicaciones diferentes.'
      }
    ];

    // Cada grupo es una tríada. En cada solución intervienen tres diarios distintos.
    this.boardGroups = [
      {
        id: 'politica',
        title: 'PODER Y ORGANIZACIÓN POLÍTICA',
        fragments: [
          { text: 'autoridad provincial', source: 'LA GACETA MERCANTIL' },
          { text: 'organización política', source: 'EL COMERCIO DEL PLATA' },
          { text: 'peso de Buenos Aires', source: 'BRITISH PACKET' }
        ]
      },
      {
        id: 'sociedad',
        title: 'CIUDAD, CAMPO Y COSTUMBRES',
        fragments: [
          { text: 'costumbres rurales', source: 'LA GACETA MERCANTIL' },
          { text: 'vida urbana', source: 'DIARIO DE LA TARDE' },
          { text: 'figura del gaucho', source: 'DIARIO DE LA TARDE' }
        ]
      },
      {
        id: 'comercio',
        title: 'COMERCIO Y CIRCULACIÓN',
        fragments: [
          { text: 'actividad comercial', source: 'EL COMERCIO DEL PLATA' },
          { text: 'movimiento portuario', source: 'LA GACETA MERCANTIL' },
          { text: 'circulación de mercancías', source: 'BRITISH PACKET' }
        ]
      },
      {
        id: 'fuentes',
        title: 'COMPARAR LAS FUENTES',
        fragments: [
          { text: 'vida pública', source: 'DIARIO DE LA TARDE' },
          { text: 'mercado regional', source: 'EL COMERCIO DEL PLATA' },
          { text: 'correspondencias', source: 'BRITISH PACKET' }
        ]
      }
    ];

    this.boardClippings = this.boardGroups.flatMap((group) =>
      group.fragments.map((fragment, fragmentIndex) => ({
        id: `${group.id}-${fragmentIndex}`,
        groupId: group.id,
        groupTitle: group.title,
        text: fragment.text,
        source: fragment.source
      }))
    );

    this.init();
  }

  init() {
    document.querySelectorAll('.newspaper').forEach((paper) => {
      paper.addEventListener('click', () => this.openPaper(Number(paper.dataset.paper)));
    });

    document.getElementById('collect-paper').addEventListener('click', () => this.collectPaper());
    document.getElementById('close-paper').addEventListener('click', () => this.closePaper());
    document.getElementById('quiz-next').addEventListener('click', () => this.nextQuestion());
    document.getElementById('board-reset-selection').addEventListener('click', () => this.resetBoardSelection());
    document.getElementById('board-next').addEventListener('click', () => this.continueBoard());
    document.getElementById('return-menu').addEventListener('click', () => this.onExit());
  }

  start() {
    this.reset();
    this.gameScreen.classList.remove('hidden');
    this.gameScreen.classList.add('active');
  }

  reset() {
    this.collected.clear();
    this.currentKeys.clear();
    this.quizIndex = 0;
    this.quizScore = 0;
    this.boardSelection = [];
    this.boardGroupsCompleted.clear();
    this.boardScore = 0;

    document.querySelectorAll('.newspaper').forEach((p) => p.classList.remove('collected'));
    this.updateProgress();

    [this.modal, this.quizModal, this.boardModal, this.completeModal]
      .forEach((m) => m.classList.add('hidden'));

    document.getElementById('interact-hint').textContent = 'HACÉ CLIC EN UN DIARIO PARA LEERLO';
  }

  openPaper(index) {
    if (this.collected.has(index)) return;

    this.currentPaper = index;
    this.currentKeys.clear();

    const paper = this.papers[index];
    document.getElementById('paper-title').textContent = paper.title;
    document.getElementById('paper-date').textContent = paper.date;
    document.getElementById('paper-issue').textContent = paper.issue;
    document.getElementById('paper-kicker').textContent = paper.kicker;
    document.getElementById('paper-headline').textContent = paper.headline;
    document.getElementById('paper-deck').textContent = paper.deck;

    const textContainer = document.getElementById('paper-text');

    // Las frases clave son cortas y aparecen dispersas dentro de una portada extensa.
    // Se busca cada frase en todos los párrafos/columnas y se convierte en un botón subrayado.
    const paragraphs = paper.columns.flat();
    const matches = [];
    paper.keys.forEach((key, keyIndex) => {
      for (let paragraphIndex = 0; paragraphIndex < paragraphs.length; paragraphIndex++) {
        const position = paragraphs[paragraphIndex].toLocaleLowerCase().indexOf(key.toLocaleLowerCase());
        if (position >= 0) {
          matches.push({ paragraphIndex, position, key, keyIndex });
          break;
        }
      }
    });

    const buildParagraph = (text, paragraphIndex) => {
      const match = matches.find((item) => item.paragraphIndex === paragraphIndex);
      if (!match) {
        // El contexto sigue siendo legible: solo una parte del material secundario
        // se presenta tachada para indicar que no hace falta memorizarlo.
        const secondary = paragraphIndex % 3 === 1 ? ' paper-irrelevant' : '';
        return `<p class="paper-secondary${secondary}">${text}</p>`;
      }
      const before = text.slice(0, match.position);
      const after = text.slice(match.position + match.key.length);
      return `<p class="paper-relevant"><span class="paper-context">${before}</span><button type="button" class="key-phrase" data-key="${match.keyIndex}" aria-label="Recolectar idea clave: ${match.key}">${match.key}</button><span class="paper-context">${after}</span></p>`;
    };

    const half = Math.ceil(paragraphs.length / 2);
    const left = paragraphs.slice(0, half);
    const right = paragraphs.slice(half);
    const leftIndex = paragraphs.map((_, i) => i).slice(0, half);
    const rightIndex = paragraphs.map((_, i) => i).slice(half);

    textContainer.innerHTML = `
      <div class="paper-column">${left.map((text, i) => buildParagraph(text, leftIndex[i])).join('')}</div>
      <div class="paper-column">${right.map((text, i) => buildParagraph(text, rightIndex[i])).join('')}</div>
    `;

    // Respaldo final: si una frase no apareciera por un cambio de contenido, se muestra
    // como extracto corto para que el diario siga teniendo exactamente 3 ideas.
    paper.keys.forEach((key, keyIndex) => {
      if (!textContainer.querySelector(`.key-phrase[data-key="${keyIndex}"]`)) {
        const fallback = document.createElement('button');
        fallback.type = 'button';
        fallback.className = 'key-phrase key-extract';
        fallback.dataset.key = keyIndex;
        fallback.textContent = key;
        fallback.setAttribute('aria-label', `Recolectar idea clave: ${key}`);
        textContainer.appendChild(fallback);
      }
    });

    textContainer.querySelectorAll('.key-phrase').forEach((button) => {
      button.addEventListener('click', () => this.collectKeyPhrase(Number(button.dataset.key)));
    });

    document.getElementById('paper-key-progress').textContent =
      `0 / ${paper.keys.length} FRASES CLAVE`;

    document.getElementById('collect-paper').classList.add('hidden');
    document.getElementById('paper-key-progress').classList.remove('complete');

    this.modal.classList.remove('hidden');
  }

  collectKeyPhrase(index) {
    if (this.currentKeys.has(index)) return;

    this.currentKeys.add(index);

    const button = document.querySelector(
      `#paper-text .key-phrase[data-key="${index}"]`
    );

    if (button) {
      button.classList.add('key-collected');
      button.disabled = true;
    }

    const total = this.papers[this.currentPaper].keys.length;
    const current = this.currentKeys.size;

    document.getElementById('paper-key-progress').textContent =
      `${current} / ${total} FRASES CLAVE`;

    this.audioManager?.playClickSound?.();

    if (current === total) {
      document.getElementById('paper-key-progress').classList.add('complete');
      document.getElementById('collect-paper').classList.remove('hidden');
      document.getElementById('collect-paper').textContent = 'CONTINUAR CON EL DIARIO';
    }
  }

  closePaper() {
    this.modal.classList.add('hidden');
  }

  collectPaper() {
    if (this.currentKeys.size !== this.papers[this.currentPaper].keys.length) return;

    this.collected.add(this.currentPaper);

    const paperElement = document.querySelector(
      `.newspaper[data-paper="${this.currentPaper}"]`
    );

    paperElement?.classList.add('collected');

    this.updateProgress();
    this.closePaper();
    this.audioManager?.playClickSound?.();

    if (this.collected.size === this.papers.length) {
      this.openQuiz();
    }
  }

  updateProgress() {
    document.getElementById('paper-progress').textContent =
      `${this.collected.size} / 4 DIARIOS LEÍDOS`;

    document.getElementById('paper-progress-fill').style.width =
      `${this.collected.size * 25}%`;
  }

  openQuiz() {
    this.quizIndex = 0;
    this.quizScore = 0;
    this.quizModal.classList.remove('hidden');
    this.renderQuestion();
  }

  renderQuestion() {
    const item = this.quiz[this.quizIndex];
    const content = document.getElementById('quiz-content');

    content.innerHTML = `
      <div class="quiz-number">PREGUNTA ${this.quizIndex + 1} / ${this.quiz.length}</div>
      <h3>${item.q}</h3>
      <div class="quiz-options">
        ${item.options.map((o, i) =>
          `<button type="button" data-answer="${i}">${o}</button>`
        ).join('')}
      </div>
    `;

    document.getElementById('quiz-feedback').textContent = '';
    document.getElementById('quiz-next').classList.add('hidden');

    content.querySelectorAll('button').forEach((btn) => {
      btn.addEventListener('click', () =>
        this.answerQuestion(Number(btn.dataset.answer))
      );
    });
  }

  answerQuestion(answer) {
    const item = this.quiz[this.quizIndex];
    const buttons = [...document.querySelectorAll('#quiz-content .quiz-options button')];

    buttons.forEach((b) => b.disabled = true);
    buttons[answer].classList.add(answer === item.answer ? 'correct' : 'wrong');

    if (answer === item.answer) {
      this.quizScore++;
      document.getElementById('quiz-feedback').textContent =
        `CORRECTO · ${item.explain}`;
    } else {
      buttons[item.answer].classList.add('correct');
      document.getElementById('quiz-feedback').textContent =
        `PARA AVANZAR: ${item.explain}`;
    }

    document.getElementById('quiz-next').textContent =
      this.quizIndex === this.quiz.length - 1 ? 'IR AL TABLERO' : 'SIGUIENTE';
    document.getElementById('quiz-next').classList.remove('hidden');
  }

  nextQuestion() {
    if (this.quizIndex < this.quiz.length - 1) {
      this.quizIndex++;
      this.renderQuestion();
    } else {
      this.openBoard();
    }
  }

  openBoard() {
    this.quizModal.classList.add('hidden');
    this.boardSelection = [];
    this.boardGroupsCompleted.clear();
    this.boardScore = 0;
    this.boardModal.classList.remove('hidden');
    this.renderBoard();
  }

  renderBoard() {
    const container = document.getElementById('board-clippings');
    const feedback = document.getElementById('board-feedback');
    const formed = document.querySelector('#formed-idea span');

    this.boardSelection = [];
    feedback.textContent = 'Elegí exactamente tres recortes que formen una misma idea.';
    formed.textContent = '—';

    const available = this.boardClippings.filter(
      (clipping) => !this.boardGroupsCompleted.has(clipping.groupId)
    );

    const shuffled = [...available].sort(() => Math.random() - 0.5);

    container.innerHTML = shuffled.map((clipping) => `
      <button type="button" class="clipping" data-id="${clipping.id}" data-group="${clipping.groupId}">
        <span class="pin"></span>
        <span class="clipping-source">${clipping.source}</span>
        <span class="clipping-text">${clipping.text}</span>
      </button>
    `).join('');

    container.querySelectorAll('.clipping').forEach((card) => {
      card.addEventListener('click', () => this.selectBoardClipping(card.dataset.id, card));
    });

    this.updateBoardProgress();
  }

  selectBoardClipping(id, card) {
    if (this.boardGroupsCompleted.size === this.boardGroups.length) return;

    const alreadySelected = this.boardSelection.some((item) => item.id === id);
    if (alreadySelected) return;

    this.boardSelection.push({
      id,
      groupId: card.dataset.group,
      card
    });
    card.classList.add('clipping-selected');

    document.querySelector('#formed-idea span').textContent =
      this.boardSelection.map((item) => item.card.querySelector('.clipping-text').textContent).join(' · ');

    if (this.boardSelection.length < 3) {
      document.getElementById('board-feedback').textContent =
        `${this.boardSelection.length} / 3 recortes elegidos. Buscá uno que complete la relación.`;
      return;
    }

    const sameGroup = this.boardSelection.every(
      (item) => item.groupId === this.boardSelection[0].groupId
    );

    if (sameGroup) {
      const group = this.boardGroups.find((item) => item.id === this.boardSelection[0].groupId);
      this.boardGroupsCompleted.add(group.id);
      this.boardScore++;
      this.boardSelection.forEach((item) => {
        item.card.disabled = true;
        item.card.classList.add('clipping-correct');
      });
      document.getElementById('board-feedback').textContent =
        `TRÍADA CORRECTA · ${group.title}`;
      document.getElementById('board-next').textContent =
        this.boardGroupsCompleted.size === this.boardGroups.length
          ? 'TERMINAR INVESTIGACIÓN'
          : 'SEGUIR RELACIONANDO';
      document.getElementById('board-next').classList.remove('hidden');
      this.updateBoardProgress();
      this.boardSelection = [];
    } else {
      this.boardSelection.forEach((item) => item.card.classList.add('clipping-wrong'));
      document.getElementById('board-feedback').textContent =
        'Esos tres recortes no pertenecen a la misma relación. Probá con otra combinación.';
      setTimeout(() => {
        this.boardSelection.forEach((item) => item.card.classList.remove('clipping-selected', 'clipping-wrong'));
        this.boardSelection = [];
        document.querySelector('#formed-idea span').textContent = '—';
      }, 650);
    }
  }

  continueBoard() {
    if (this.boardGroupsCompleted.size === this.boardGroups.length) {
      this.finishBoard();
      return;
    }

    document.getElementById('board-next').classList.add('hidden');
    this.renderBoard();
  }

  resetBoardSelection() {
    this.boardSelection.forEach((item) => item.card.classList.remove('clipping-selected', 'clipping-wrong'));
    this.boardSelection = [];
    document.querySelector('#formed-idea span').textContent = '—';
    document.getElementById('board-feedback').textContent =
      'Selección limpia. Elegí tres recortes que formen una misma idea.';
  }

  updateBoardProgress() {
    document.getElementById('board-progress').textContent =
      `TRÍADAS RELACIONADAS: ${this.boardGroupsCompleted.size} / ${this.boardGroups.length}`;
    document.getElementById('board-score').textContent =
      `${this.boardGroupsCompleted.size} / ${this.boardGroups.length}`;
  }

  finishBoard() {
    if (this.boardGroupsCompleted.size !== this.boardGroups.length) return;
    this.boardModal.classList.add('hidden');
    this.finishLevel();
  }

  finishLevel() {
    document.getElementById('final-papers').textContent =
      `${this.collected.size} / 4 DIARIOS`;

    document.getElementById('final-quiz').textContent =
      `${this.quizScore} / 4 RESPUESTAS · ${this.boardScore} / 4 TRÍADAS`;

    this.completeModal.classList.remove('hidden');
  }

  isModalOpen() {
    return (
      !this.modal.classList.contains('hidden') ||
      !this.quizModal.classList.contains('hidden') ||
      !this.boardModal.classList.contains('hidden') ||
      !this.completeModal.classList.contains('hidden')
    );
  }
}
