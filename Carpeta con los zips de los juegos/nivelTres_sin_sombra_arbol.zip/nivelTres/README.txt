Estructura:

- nivelTres.html -> estructura HTML del nivel
- css/style.css -> todos los estilos CSS
- js/nivelTres.js -> logica principal JavaScript
- js/intro.js -> funcionamiento del boton de la introduccion

No se modificaron las mecanicas del nivel; solamente se separaron HTML, CSS y JavaScript en archivos independientes.
