
const HP = 8, TRAMOS = 6, TRONCOS_ARBOL = 2;
const RM = window.matchMedia('(prefers-reduced-motion: reduce)');
const dur = ms => RM.matches ? 1 : ms;
const $ = id => document.getElementById(id);

const RECETAS = [
  {id:'aserrar', nom:'Aserrar tablones', usa:{troncos:1}, da:{tablones:2}, txt:['1 tronco','2 tablones'], golpes:5, verbo:'serruchar'},
  {id:'lijar', nom:'Lijar la madera', usa:{tablones:2}, da:{tablonesLijados:2}, txt:['2 tablones','2 tablones lijados'], golpes:6, verbo:'lijar'},
  {id:'tratar', nom:'Tratar la madera', usa:{tablonesLijados:2}, da:{tablonesTratados:2}, txt:['2 tablones lijados','2 tablones tratados'], golpes:4, verbo:'tratar'},
  {id:'pilote', nom:'Afilar un pilote', usa:{troncos:1}, da:{pilotes:1}, txt:['1 tronco','1 pilote'], golpes:4, verbo:'afilar'}
];

let S, prev = {};
function nuevo(){
  S = {troncos:0, tablones:0, tablonesLijados:0, tablonesTratados:0, pilotes:0, hp:HP, busy:false, playerBusy:false, workerBusy:false, last:null, cruzo:false, proceso:null, trabajador:false, workerTask:null, workerTimer:null, workerFatiga:100, workerDescanso:false, workerDescansoHasta:0, workerRestTimer:null, workerUltimoMovimiento:0, workerProceso:null, workerReserva:null, historia:0, b:Array.from({length:TRAMOS}, () => ({p:false,t:false}))};
  const g = $('gaucho'); if (g) g.remove();
}

/* ---------- Talar ---------- */
function updArbol(){
  const h = HP - S.hp, w = Math.min(h, 4) * 5;
  $('corteI').setAttribute('d', h ? `M110 205 L${110 + w} 214 L110 223 Z` : '');
  $('corteD').setAttribute('d', h >= 3 ? `M130 195 L${130 - (h - 2) * 5} 204 L130 213 Z` : '');
  $('golpes').textContent = `Golpes: ${h}/${HP}`;
}
function talar(){
  if (S.playerBusy || S.hp <= 0) return;
  const zona = $('zonaCorte');
  const cx = Number(zona.getAttribute('cx')), cy = Number(zona.getAttribute('cy'));
  // El jugador tiene que acertar el punto de corte, no simplemente pulsar un botón.
  S.hp--; S.playerBusy = true;
  $('hacha').animate([{transform:'rotate(-40deg)'},{transform:'translate(48px,-28px) rotate(28deg)',offset:.42},{transform:'rotate(-40deg)'}], {duration:dur(300),easing:'ease-out'});
  $('arbol').animate([{transform:'rotate(0)'},{transform:'rotate(2deg)',offset:.35},{transform:'rotate(-1deg)',offset:.7},{transform:'rotate(0)'}], {duration:dur(280),easing:'ease-out'});
  astillas(); updArbol();
  setTimeout(() => { S.playerBusy=false; if (S.hp<=0) caer(); }, dur(330));
}
function moverZona(){
  const x = 112 + Math.random()*16, y = 198 + Math.random()*30;
  $('zonaCorte').animate([{transform:`translate(${x-120}px,${y-214}px) scale(.7)`,opacity:.3},{transform:`translate(${x-120}px,${y-214}px) scale(1)`,opacity:1}],{duration:dur(180),fill:'forwards'});
  $('zonaCorte').setAttribute('cx',x); $('zonaCorte').setAttribute('cy',y);
}
function astillas(){
  const g = $('astillas');
  for (let i = 0; i < 5; i++) {
    const c = document.createElementNS('http://www.w3.org/2000/svg', 'rect');
    c.setAttribute('x', 106); c.setAttribute('y', 210); c.setAttribute('width', 4); c.setAttribute('height', 3);
    c.setAttribute('class', 'f-corte'); g.appendChild(c);
    const dx = -30 + Math.random() * 26 - 10, dy = -20 + Math.random() * 40;
    c.animate([{transform:'translate(0,0) rotate(0)', opacity:1},{transform:`translate(${dx}px,${dy}px) rotate(${Math.random()*200}deg)`, opacity:0}],
      {duration:dur(520), easing:'ease-out', delay:dur(110)}).onfinish = () => c.remove();
  }
}
function caer(){
  S.workerBusy = true;
  const a = $('arbol').animate([{transform:'rotate(0)',opacity:1},{transform:'rotate(86deg)',opacity:1,offset:.85},{transform:'rotate(90deg)',opacity:0}],
    {duration:dur(950), easing:'ease-in', fill:'forwards', delay:dur(150)});
  a.onfinish = () => {
    a.cancel();
    S.troncos += TRONCOS_ARBOL; flotante(`+${TRONCOS_ARBOL} troncos`);
    S.hp = HP; updArbol(); moverZona();
    $('arbol').animate([{transform:'scale(.15)'},{transform:'scale(1)'}], {duration:dur(700), easing:'ease-out'});
    S.workerBusy = false; if(S.workerTask==='talar'){ drawWorker(); setTimeout(workerLoop, dur(750)); } refrescar();
  };
}
function flotante(txt){
  const d = document.createElement('div'); d.className = 'flot'; d.textContent = txt; $('stage').appendChild(d);
  d.animate([{transform:'translate(-50%,10px)',opacity:0},{transform:'translate(-50%,0)',opacity:1,offset:.2},{transform:'translate(-50%,-34px)',opacity:0}],
    {duration:dur(1100), easing:'ease-out'}).onfinish = () => d.remove();
}

/* ---------- Craftear ---------- */
const alcanza = r => Object.entries(r.usa).every(([k, v]) => S[k] >= v);
function craftear(id){
  const r = RECETAS.find(x => x.id === id); if (!r || !alcanza(r) || S.proceso) return;
  S.proceso = {id, paso:0};
  renderProceso();
}
function terminarProceso(){
  if(!S.proceso) return;
  const r=RECETAS.find(x=>x.id===S.proceso.id);
  for (const [k,v] of Object.entries(r.usa)) S[k]-=v;
  for (const [k,v] of Object.entries(r.da)) S[k]+=v;
  S.proceso=null; flotante(r.nom+' terminado'); refrescar();
}
function hacerGolpeProceso(){
  if(!S.proceso || S.playerBusy) return;
  const r=RECETAS.find(x=>x.id===S.proceso.id);
  S.playerBusy=true;
  const tool=document.querySelector('[data-tool="'+r.id+'"]');
  if(tool) tool.animate([{transform:'translate(0,0)'},{transform:'translate(-8px,5px) rotate(-8deg)'},{transform:'translate(0,0)'}],{duration:dur(180),easing:'ease-out'});
  S.proceso.paso++; renderProceso();
  setTimeout(()=>{S.playerBusy=false; if(S.proceso && S.proceso.paso>=r.golpes) terminarProceso();},dur(200));
}
function moverProcesoConMouse(e){
  if(!S.proceso || S.playerBusy) return;
  const svg=e.target.closest('.tallerSvg'); if(!svg) return;
  const r=RECETAS.find(x=>x.id===S.proceso.id);
  // Solo TRATAR mantiene el modo de mover el mouse. Aserrar y lijar usan circulos.
  if(r && (r.id==='aserrar' || r.id==='lijar')) return;
  const now=performance.now();
  if(now-S.workerUltimoMovimiento<230) return;
  const rect=svg.getBoundingClientRect();
  if(e.clientX<rect.left || e.clientX>rect.right || e.clientY<rect.top || e.clientY>rect.bottom) return;
  S.workerUltimoMovimiento=now;
  hacerGolpeProceso();
}
function circuloTrabajoClick(e){
  const hit=e.target.closest('.zonaTrabajo');
  if(!hit || !S.proceso || S.playerBusy) return;
  const r=RECETAS.find(x=>x.id===S.proceso.id);
  if(!r || (r.id!=='aserrar' && r.id!=='lijar')) return;
  e.preventDefault();
  hacerGolpeProceso();
}
function renderProceso(){
  const zona=$('recetas');
  if(!S.proceso){ drawRecetas(); return; }
  const r=RECETAS.find(x=>x.id===S.proceso.id), restante=r.golpes-S.proceso.paso, pct=Math.min(100,S.proceso.paso/r.golpes*100);
  let art='';
  if(r.id==='lijar') art=`<svg class="tallerSvg" data-hit="1" viewBox="0 0 420 190" role="img" aria-label="Banco para lijar madera"><rect width="420" height="190" class="f-cielo"/><rect x="55" y="72" width="310" height="45" rx="5" class="f-tablon"/><path d="M55 117h310l-18 28H73z" class="f-madera"/><g data-tool="lijar" class="herramienta"><rect x="145" y="55" width="92" height="20" rx="4" class="f-corte"/><rect x="155" y="45" width="72" height="10" rx="3" class="f-metal"/></g><circle data-a="process-hit" class="zonaTrabajo" cx="${180+(S.proceso.paso%5)*35}" cy="92" r="24"/><text x="210" y="168" text-anchor="middle" class="f-ink" font-size="13" font-weight="900">HACÉ CLIC EN EL CÍRCULO</text></svg>`;
  else if(r.id==='aserrar') art=`<svg class="tallerSvg" data-hit="1" viewBox="0 0 420 190" role="img" aria-label="Banco para aserrar madera"><rect width="420" height="190" class="f-cielo"/><rect x="55" y="72" width="310" height="45" rx="5" class="f-tablon"/><g data-tool="aserrar" class="herramienta"><rect x="150" y="35" width="100" height="6" class="f-metal"/><path d="M150 41l12 10 12-10 12 10 12-10 12 10 12-10 12 10 12-10 12 10" fill="none" stroke="currentColor" stroke-width="3"/></g><circle data-a="process-hit" class="zonaTrabajo" cx="${105+(S.proceso.paso%7)*38}" cy="94" r="22"/><text x="210" y="168" text-anchor="middle" class="f-ink" font-size="13" font-weight="900">HACÉ CLIC EN EL CÍRCULO</text></svg>`;
  else art=`<svg class="tallerSvg" data-hit="1" viewBox="0 0 420 190" role="img" aria-label="Banco para tratar madera"><rect width="420" height="190" class="f-cielo"/><rect x="55" y="78" width="310" height="42" rx="5" class="f-tablon"/><rect x="85" y="48" width="250" height="12" rx="3" class="f-metal"/><g data-tool="tratar" class="herramienta"><rect x="188" y="28" width="10" height="40" class="f-madera"/><path d="M170 65h45l-8 28h-29z" class="f-corte"/></g><circle cx="${100+(S.proceso.paso%6)*45}" cy="99" r="22" class="zonaTrabajo"/></svg>`;
  const instruccion=(r.id==='aserrar'||r.id==='lijar')?'Hacé clic en el círculo que aparece sobre la madera para trabajar. El punto cambia en cada acción.':'Mové el mouse sobre la zona de trabajo para '+r.verbo+', sin apretar botones.';
  zona.innerHTML=`<div class="zonaProceso"><b>${r.nom}</b><div class="nota">${instruccion} Faltan ${restante} acción${restante===1?'':'es'}.</div>${art}<div class="progreso"><i style="width:${pct}%"></i></div><div class="nota">Progreso: ${S.proceso.paso}/${r.golpes}</div></div>`;
}
function reclutar(){
  if(S.trabajador || S.troncos<2 || S.cruzo) return;
  S.troncos-=2; S.trabajador=true; S.workerFatiga=100; S.workerDescanso=false; flotante('Trabajador contratado'); drawWorker(); drawInv();
}
function workerTask(task){
  if(!S.trabajador || S.workerTask || S.cruzo) return;
  if(task==='talar'){ S.workerTask='talar'; workerLoop(); return; }
  const id=task==='aserrar'?'aserrar':task==='lijar'?'lijar':'tratar';
  const r=RECETAS.find(x=>x.id===id);
  if(!alcanza(r)) return;
  S.workerProceso={id, paso:0};
  S.workerReserva={...r.usa};
  for(const [k,v] of Object.entries(r.usa)) S[k]-=v;
  S.workerTask=id;
  drawRecetas();
  workerLoop();
}
function terminarWorkerProceso(){
  if(!S.workerProceso) return;
  const r=RECETAS.find(x=>x.id===S.workerProceso.id);
  for(const [k,v] of Object.entries(r.da)) S[k]+=v;
  S.workerProceso=null; S.workerReserva=null;
  flotante('Trabajador terminó: '+r.nom);
  refrescar();
}
function workerLoop(){
  if(!S.workerTask) return;

  // El cansancio del recluta es independiente del jugador.
  // Mientras descansa, el jugador puede seguir haciendo cualquier tarea.
  if(S.workerDescanso){
    const actualizarDescanso=()=>{
      if(!S.workerDescanso || !S.workerTask) return;
      const restante=Math.max(0,S.workerDescansoHasta-Date.now());
      drawWorker(restante);
      if(restante>0) S.workerRestTimer=setTimeout(actualizarDescanso,100);
    };
    actualizarDescanso();
    if(!S.workerTimer){
      S.workerTimer=setTimeout(()=>{
        S.workerTimer=null;
        S.workerFatiga=100;
        S.workerDescanso=false;
        S.workerDescansoHasta=0;
        if(S.workerRestTimer){clearTimeout(S.workerRestTimer);S.workerRestTimer=null;}
        drawWorker();
        workerLoop();
      },Math.max(1,S.workerDescansoHasta-Date.now()));
    }
    return;
  }

  if(S.workerFatiga<=0){
    S.workerDescanso=true;
    S.workerDescansoHasta=Date.now()+dur(8000);
    if(S.workerTimer){clearTimeout(S.workerTimer);S.workerTimer=null;}
    drawWorker(8000);
    workerLoop();
    return;
  }

  if(S.workerTask==='talar'){
    if(S.hp<=0){ S.workerTask=null; drawWorker(); return; }
    S.workerBusy=true;
    S.hp--;
    S.workerFatiga=Math.max(0,S.workerFatiga-6);
    drawWorker();
    $('hacha').animate([{transform:'rotate(-40deg)'},{transform:'translate(48px,-28px) rotate(28deg)',offset:.42},{transform:'rotate(-40deg)'}],{duration:dur(260),easing:'ease-out'});
    astillas(); updArbol();
    S.workerTimer=setTimeout(()=>{
      S.workerBusy=false;
      S.workerTimer=null;
      if(S.hp<=0) caer(); else workerLoop();
    },dur(360));
    return;
  }

  if(!S.workerProceso){S.workerTask=null;drawWorker();return;}
  const r=RECETAS.find(x=>x.id===S.workerProceso.id);
  S.workerProceso.paso++;
  S.workerFatiga=Math.max(0,S.workerFatiga-6);
  drawWorker();
  if(S.workerProceso.paso>=r.golpes){
    S.workerTimer=setTimeout(()=>{
      S.workerTimer=null;
      terminarWorkerProceso();
      S.workerTask=null;
      drawWorker();
    },dur(450));
  } else {
    S.workerTimer=setTimeout(()=>{S.workerTimer=null;workerLoop();},dur(650));
  }
}

function pararTrabajador(){
  if(!S.trabajador) return;
  if(S.workerTimer){ clearTimeout(S.workerTimer); S.workerTimer=null; }
  if(S.workerRestTimer){ clearTimeout(S.workerRestTimer); S.workerRestTimer=null; }
  S.workerDescansoHasta=0;
  if(S.workerReserva){
    for(const [k,v] of Object.entries(S.workerReserva)) S[k]+=v;
    S.workerReserva=null;
    S.workerProceso=null;
  }
  S.workerTask=null;
  S.workerDescanso=false;
  S.workerBusy=false;
  drawWorker();
  refrescar();
}
function drawWorker(descansoMs=null){
  const st=$('workerStatus'), info=$('workerInfo'), a=$('workerActions'); if(!st)return;
  if(!S.trabajador){st.textContent='Sin trabajador';st.className='workerBadge';info.textContent='Podés reclutar un trabajador para que te ayude con las tareas.';a.innerHTML='<button class="btn pri" type="button" data-a="recruit">Reclutar trabajador <small>Costo: 2 troncos</small></button>';return;}
  st.textContent=S.workerDescanso?'Cansado — descansando':(S.workerTask?'Trabajando…':'Disponible'); st.className='workerBadge '+(S.workerDescanso?'':(S.workerTask?'':'ok'));
  if(S.workerDescanso){
    const segundos=Math.ceil(Math.max(0,(descansoMs==null?(S.workerDescansoHasta-Date.now()):descansoMs))/1000);
    info.innerHTML=`Está descansando. Cansancio: ${Math.round(100-S.workerFatiga)}%. <strong>Reinicio en: ${segundos} segundos</strong>`;
  }else{
    info.textContent=S.workerTask?`Está ayudando con: ${S.workerTask==='talar'?'talar':S.workerTask==='aserrar'?'serruchar':S.workerTask==='lijar'?'lijar':'tratar'}. Cansancio: ${Math.round(100-S.workerFatiga)}%.`:`Elegí una tarea para que te ayude. Cansancio: ${Math.round(100-S.workerFatiga)}%.`;
  }
  a.innerHTML=`<button class="btn" type="button" data-a="worker" data-k="talar" ${S.workerTask?'disabled':''}>Ayudar a talar</button><button class="btn" type="button" data-a="worker" data-k="aserrar" ${S.workerTask?'disabled':''}>Ayudar a serruchar</button><button class="btn" type="button" data-a="worker" data-k="lijar" ${S.workerTask?'disabled':''}>Ayudar a lijar</button><button class="btn" type="button" data-a="worker" data-k="tratar" ${S.workerTask?'disabled':''}>Ayudar a tratar</button>${S.workerTask?'<button class="btn" type="button" data-a="worker-stop">Parar trabajador</button>':''}`;
}
function falta(){
  const pSin = S.b.filter(x => !x.p).length, tSin = S.b.filter(x => !x.t).length;
  const needP = Math.max(0, pSin - S.pilotes), needT = Math.max(0, tSin * 3 - S.tablonesTratados);
  return Math.max(0, needP + Math.ceil(needT / 2) - S.troncos);
}
function drawRecetas(){
  if(S.proceso){ renderProceso(); return; }
  $('recetas').innerHTML = RECETAS.map(r => `<div class="receta"><div><div class="nom">${r.nom}</div>
    <div class="formula"><b>${r.txt[0]}</b> → <b>${r.txt[1]}</b></div></div>
    <button class="btn pri" type="button" data-a="craft" data-k="${r.id}" ${alcanza(r) ? '' : 'disabled'}>Craftear</button></div>`).join('');
  const f = falta(), fin = S.b.every(x => x.p && x.t);
  $('guia').textContent = fin ? 'No hace falta más madera.' : f > 0 ? `Para terminar el puente todavía tenés que talar ${f} tronco${f === 1 ? '' : 's'}.` : 'Con lo que tenés alcanza para terminar el puente.';
}

const HISTORIA_PUENTE = [
  ['Sección 1 · El campesino argentino',
   'El capítulo presenta al campesino al llegar a la edad viril: independiente y libre de sujeción, formado por la naturaleza y por la falta de una sociedad organizada.',
   '“Yo crecí acostumbrado a valerme por mí mismo. La libertad es parte de mi vida, pero también me deja lejos de un orden común.”'],
  ['Sección 2 · Una campaña dispersa',
   'Sarmiento describe las estancias pastoriles distribuidas a grandes distancias y contrasta esa vida con la agricultura, donde las tareas y relaciones acercan a los habitantes.',
   '“Aquí las casas están lejos unas de otras. No es como en el campo agrícola, donde el trabajo obliga a encontrarse y a depender de los demás.”'],
  ['Sección 3 · La vida pastoril',
   'En la campaña pastoril, los ganados necesitan menos brazos y el hombre queda con pocas ocupaciones forzosas; el hogar puede resultarle ajeno y lo impulsa a salir.',
   '“Tengo pocas obligaciones que me retengan en casa. El campo abierto y el caballo me llaman más que quedarme quieto.”'],
  ['Sección 4 · La sociedad ficticia',
   'El capítulo explica que esa desasociación genera la necesidad de una “sociedad ficticia”: espacios de reunión que compensan la falta de vínculos cotidianos.',
   '“Si vivimos tan separados, necesitamos encontrarnos de alguna manera. Quizás por eso buscamos la pulpería y las reuniones: allí dejamos de estar solos.”'],
  ['Sección 5 · Las reputaciones gauchas',
   'De esas reuniones surgen reputaciones ligadas al valor, el arrojo, la destreza y también a la oposición a la justicia regular de la ciudad.',
   '“En estos encuentros uno gana nombre por su valor y su destreza. Pero también aprendo que esa libertad puede enfrentarse con la justicia y las reglas de la ciudad.”'],
  ['Sección 6 · El cambio de 1810',
   'La Revolución de 1810 lleva movimiento y armas a la campaña. Las asociaciones de la pulpería y la estancia terminan vinculándose con la formación de las montoneras provinciales.',
   '“Ahora el ruido de las armas llega hasta nosotros. Lo que antes era una reunión de hombres de campo empieza a convertirse en algo mucho más grande y peligroso.”']
];
function drawHistoria(){
  const card=$('historiaPuente'); if(!card) return;
  if(S.historia<=0){card.hidden=true;return;}
  const idx=Math.min(S.historia,HISTORIA_PUENTE.length)-1;
  const h=HISTORIA_PUENTE[idx];
  card.hidden=false;
  $('historiaNumero').textContent=`Sección ${idx+1} de ${HISTORIA_PUENTE.length}`;
  $('historiaTitulo').textContent=h[0];
  $('historiaTexto').textContent=h[1];
  $('historiaPensamiento').innerHTML=`<b>PENSAMIENTO DEL GAUCHO</b>${h[2]}`;
}

/* ---------- Puente ---------- */
function paso(){
  for (let i = 0; i < TRAMOS; i++) { if (!S.b[i].p) return {i, k:'p'}; if (!S.b[i].t) return {i, k:'t'}; }
  return null;
}
function construir(){
  const s = paso(); if (!s) return;
  if (s.k === 'p' && S.pilotes >= 1) { S.pilotes--; S.b[s.i].p = true; }
  else if (s.k === 't' && S.tablonesTratados >= 3) { S.tablonesTratados -= 3; S.b[s.i].t = true; S.historia = Math.max(S.historia, s.i + 1); }
  else return;
  S.last = s; refrescar();
}
function drawPuente(){
  const nx = paso(), cx = i => 135 + 90 * i;
  let o = `<rect width="720" height="230" class="f-cielo"/>
    <!-- cielo con profundidad: nubes pixeladas y aves -->
    <path d="M0 128 Q120 86 240 116 T480 108 T720 118 V150 H0 Z" class="f-hoja" opacity=".30"/>
    <g class="cielo-pixel" aria-hidden="true">
      <path class="nube" d="M70 45h18v-7h20v-6h28v6h14v7h18v8H70z"/>
      <path class="nube-luz" d="M82 44h20v-5h22v5h18v5H82z"/>
      <path class="nube" d="M505 60h16v-6h22v-7h25v7h16v6h16v8h-95z"/>
      <path class="nube-luz" d="M518 59h20v-5h23v5h17v5h-60z"/>
      <path class="ave" d="M285 52h5l5-4 5 4 5-4h5"/>
      <path class="ave" d="M405 76h4l4-3 4 3 4-3h4"/>
      <path class="ave" d="M575 38h4l4-3 4 3 4-3h4"/>
    </g>
    <rect y="140" width="720" height="90" class="f-agua"/>`;

  /* Orillas más naturales: capas de tierra, césped irregular, piedras y vegetación. */
  o += `<g class="orilla-pixel">
    <!-- margen de tierra izquierda -->
    <path class="f-tierra" d="M0 128h18v-3h17v4h16v-6h20v5h15v-3h12v105H0z"/>
    <path class="f-tierra-oscura" d="M0 157h20v-4h18v6h19v-5h17v7h18v-4h10v69H0z"/>
    <path class="f-tierra-clara" d="M0 139h14v-4h17v5h13v-3h18v6h16v-4h17v7H0z"/>
    <!-- margen de tierra derecha -->
    <path class="f-tierra" d="M628 126h12v4h16v-5h19v6h17v-4h15v3h13v-2h20v102H628z"/>
    <path class="f-tierra-oscura" d="M628 158h14v-5h17v6h18v-4h16v7h19v-5h14v68H628z"/>
    <path class="f-tierra-clara" d="M628 140h15v-5h17v6h16v-4h18v5h14v-3h12v8H628z"/>

    <!-- borde de pasto irregular izquierdo -->
    <path class="f-pasto" d="M0 131h7v-7h3v7h6v-11h3v11h7v-6h4v6h6v-10h3v10h8v-7h3v7h7v-12h3v12h7v-7h4v7h8v-10h3v10h8v-5h4v8H0z"/>
    <path class="f-pasto2" d="M0 138h10v-6h3v6h8v-9h3v9h9v-5h3v5h8v-8h3v8h10v-6h3v6h8v-10h3v10h9v-6h3v6h10v-5h3v8H0z"/>
    <!-- borde de pasto irregular derecho -->
    <path class="f-pasto" d="M628 131h7v-10h3v10h8v-7h3v7h8v-12h3v12h8v-6h3v6h9v-9h3v9h8v-12h3v12h8v-7h3v7h9v-10h3v10h8v-6h3v6h9v-11h3v11h9v-5h3v8H628z"/>
    <path class="f-pasto2" d="M628 138h9v-7h3v7h8v-9h3v9h9v-5h3v5h8v-8h3v8h9v-6h3v6h10v-10h3v10h8v-6h3v6h10v-8h3v8h9v-5h3v8H628z"/>

    <!-- manchas de tierra pixeladas -->
    <g class="suelo-textura">
      <rect x="14" y="170" width="9" height="4"/><rect x="28" y="188" width="5" height="3"/><rect x="49" y="205" width="12" height="4"/>
      <rect x="70" y="178" width="7" height="3"/><rect x="83" y="215" width="8" height="4"/><rect x="642" y="174" width="10" height="4"/>
      <rect x="665" y="201" width="6" height="3"/><rect x="690" y="183" width="11" height="4"/><rect x="705" y="214" width="7" height="4"/>
    </g>

    <!-- piedras con sombra -->
    <g class="decor-pixel">
      <path class="f-piedra-sombra" d="M18 153h7v-3h10v3h5v7H18z"/><path class="f-piedra" d="M22 150h10v3h7v4H22z"/>
      <path class="f-piedra-sombra" d="M74 191h9v-3h8v7H74z"/><path class="f-piedra2" d="M78 187h8v3h7v4H78z"/>
      <path class="f-piedra-sombra" d="M654 155h8v-4h10v7h-4v4h-14z"/><path class="f-piedra" d="M659 151h9v3h5v4h-14z"/>
      <path class="f-piedra-sombra" d="M698 195h8v-3h10v7h-18z"/><path class="f-piedra2" d="M702 191h8v3h6v4h-14z"/>

      <!-- flores -->
      <rect x="51" y="166" width="3" height="12" class="f-tallo"/><rect x="46" y="162" width="6" height="5" class="f-flor"/><rect x="53" y="162" width="6" height="5" class="f-flor2"/>
      <rect x="679" y="172" width="3" height="12" class="f-tallo"/><rect x="674" y="168" width="6" height="5" class="f-flor2"/><rect x="681" y="168" width="6" height="5" class="f-flor"/>

      <!-- juncos junto al agua -->
      <path d="M90 142v-20m5 20v-14m5 14v-18M630 142v-19m-5 19v-14m-5 14v-17" class="f-junco"/>
    </g>
  </g>`;

  /* Agua con líneas escalonadas y una franja de orilla húmeda. */
  for (const y of [162, 180, 198, 216]) {
    let d = `M94 ${y}`;
    for (let k = 0; k < 21; k++) d += ` q12 -4 24 0 t24 0`;
    o += `<path d="${d}" class="s-ola"/>`;
  }
  o += `<rect x="94" y="151" width="532" height="79" class="f-agua-profunda" opacity=".35"/>`;

  const nuevoDe = (i, k) => S.last && S.last.i === i && S.last.k === k ? ' nuevo' : '';
  for (let i = 0; i < TRAMOS; i++) if (S.b[i].p) {
    const x = cx(i);
    o += `<g class="${nuevoDe(i,'p').trim()}">
      <rect x="${x-8}" y="133" width="16" height="66" class="f-pilote"/>
      <rect x="${x-5}" y="136" width="4" height="57" class="f-pilote-luz"/>
      <rect x="${x+4}" y="141" width="3" height="51" class="f-pilote-sombra"/>
    </g>`;
  }
  if (nx && nx.k === 'p') o += `<g class="ghost" data-a="build"><rect x="${cx(nx.i)-8}" y="134" width="16" height="62" rx="2"/></g>`;

  /* Puente: cada tramo tiene tablones, vetas, clavos, vigas y barandas. */
  for (let i = 0; i < TRAMOS; i++) if (S.b[i].t) {
    const x = cx(i);
    o += `<g class="${nuevoDe(i,'t').trim()}">
      <rect x="${x-47}" y="126" width="94" height="16" class="f-puente-borde"/>
      <rect x="${x-44}" y="128" width="43" height="10" class="f-tablon s-tab"/>
      <rect x="${x+1}" y="128" width="43" height="10" class="f-tablon s-tab"/>
      <rect x="${x-42}" y="130" width="28" height="2" class="f-madera-luz"/>
      <rect x="${x-35}" y="134" width="18" height="1" class="f-madera-sombra"/>
      <rect x="${x+6}" y="130" width="28" height="2" class="f-madera-luz"/>
      <rect x="${x+12}" y="134" width="20" height="1" class="f-madera-sombra"/>
      <rect x="${x-40}" y="129" width="3" height="3" class="f-clavo"/>
      <rect x="${x-8}" y="129" width="3" height="3" class="f-clavo"/>
      <rect x="${x+8}" y="129" width="3" height="3" class="f-clavo"/>
      <rect x="${x+37}" y="129" width="3" height="3" class="f-clavo"/>
      <rect x="${x-47}" y="114" width="5" height="15" class="f-pilote"/>
      <rect x="${x+42}" y="114" width="5" height="15" class="f-pilote"/>
      <rect x="${x-47}" y="113" width="94" height="5" class="f-pilote"/>
      <rect x="${x-44}" y="114" width="88" height="2" class="f-madera-luz"/>
      <rect x="${x-47}" y="140" width="94" height="5" class="f-puente-sombra"/>
      <rect x="${x-41}" y="143" width="82" height="2" class="f-puente-borde"/>
      <!-- pequeñas sombras bajo los tablones -->
      <rect x="${x-43}" y="138" width="40" height="2" class="f-madera-sombra"/>
      <rect x="${x+3}" y="138" width="40" height="2" class="f-madera-sombra"/>
    </g>`;
  }
  if (nx && nx.k === 't') o += `<g class="ghost" data-a="build"><rect x="${cx(nx.i)-45}" y="126" width="90" height="12" rx="2"/></g>`;

  $('puente').innerHTML = o;
  const g = $('gaucho'); if (g) $('puente').appendChild(g);
}
function drawAcciones(){
  const s = paso(), a = $('acciones'), t = S.b.filter(x => x.t).length;
  $('nTramos').textContent = t;
  if (!s) {
    $('estado').innerHTML = '<span class="fin">Puente terminado</span>';
    $('ayuda').textContent = S.cruzo ? 'El gaucho cruzó el puente. Nivel 3 completado.' : 'Los seis tramos están en su lugar.';
    a.innerHTML = S.cruzo
      ? `<button class="btn" type="button" data-a="menu">Volver al menú</button>`
      : `<button class="btn pri" type="button" data-a="cruzar">Cruzar el puente</button>`;
    return;
  }
  const esP = s.k === 'p', ok = esP ? S.pilotes >= 1 : S.tablonesTratados >= 3;
  $('estado').textContent = `Tramo ${s.i + 1} de ${TRAMOS}: ${esP ? 'clavar el pilote' : 'colocar los tablones'}`;
  $('ayuda').textContent = ok ? 'Tenés las piezas. Tocá el contorno punteado o el botón.' : esP ? 'Te falta un pilote. Afilá uno con un tronco.' : `Te faltan tablones tratados (${S.tablonesTratados}/3). Aserrá, lijá y tratá la madera.`;
  a.innerHTML = `<button class="btn pri" type="button" data-a="build" ${ok ? '' : 'disabled'}>${esP ? 'Clavar pilote' : 'Colocar tablones tratados'}<small>${esP ? 'usa 1 pilote' : 'usa 3 tablones tratados'}</small></button>`;
}
function volverAlMenu(){
  try {
    const p = window.parent;
    if (p && p !== window) {
      const levelThree = p.document.getElementById('level-three-screen');
      const levelSelect = p.document.getElementById('level-select-screen');
      if (typeof p.alternarPantalla === 'function' && levelThree && levelSelect) {
        p.alternarPantalla(levelThree, false);
        p.alternarPantalla(levelSelect, true);
        return;
      }
      if (levelThree) levelThree.style.display = 'none';
      if (levelSelect) levelSelect.style.display = '';
    }
  } catch(e) {}
  if (window.history.length > 1) window.history.back();
}
function cruzar(){
  if ($('gaucho')) return;
  const ns = 'http://www.w3.org/2000/svg', g = document.createElementNS(ns, 'g');
  g.id = 'gaucho';
  g.innerHTML = `<ellipse cx="0" cy="-27" rx="10" ry="2.6" class="f-ink"/><rect x="-4" y="-31" width="8" height="5" rx="1" class="f-ink"/>
    <circle cx="0" cy="-22" r="4.2" class="f-corte"/><rect x="-5" y="-18" width="10" height="11" rx="2" class="f-rep"/>
    <rect x="-4.5" y="-7" width="3.5" height="7" class="f-ink"/><rect x="1" y="-7" width="3.5" height="7" class="f-ink"/>`;
  g.style.transform = 'translate(24px,128px)';
  $('puente').appendChild(g);
  g.animate([{transform:'translate(24px,128px)'},{transform:'translate(696px,128px)'}], {duration:dur(5200), easing:'linear', fill:'forwards'})
    .onfinish = () => { S.cruzo = true; drawAcciones(); };
}

/* ---------- Inventario y refresco ---------- */
function drawInv(){
  for (const [k, id] of [['troncos','vTroncos'],['tablones','vTablones'],['tablonesLijados','vLijados'],['tablonesTratados','vTratados'],['pilotes','vPilotes']]) {
    const el = $(id); el.textContent = S[k];
    if (prev[k] !== undefined && prev[k] !== S[k]) el.animate([{transform:'scale(1.5)'},{transform:'scale(1)'}], {duration:dur(300), easing:'ease-out'});
    prev[k] = S[k];
  }
}
function refrescar(){ drawInv(); drawRecetas(); drawPuente(); drawAcciones(); drawWorker(); drawHistoria(); }

document.addEventListener('pointermove', moverProcesoConMouse);

document.addEventListener('click', circuloTrabajoClick);
document.addEventListener('click', e => {
  const b = e.target.closest('[data-a]'); if (!b || b.disabled) return;
  const a = b.dataset.a;
  if (a === 'craft') craftear(b.dataset.k);
  else if (a === 'process') hacerGolpeProceso();
  else if (a === 'recruit') reclutar();
  else if (a === 'worker') workerTask(b.dataset.k);
  else if (a === 'worker-stop') pararTrabajador();
  else if (a === 'build') construir();
  else if (a === 'cruzar') cruzar();
  else if (a === 'reinicio') { nuevo(); updArbol(); moverZona(); refrescar(); }
  else if (a === 'menu') volverAlMenu();
});
$('btnTalar').addEventListener('click', talar);
$('arbolSvg').addEventListener('click', e => {
  if (S.playerBusy || S.hp<=0) return;
  const pt=$('arbolSvg').createSVGPoint(); pt.x=e.clientX; pt.y=e.clientY;
  const local=pt.matrixTransform($('arbolSvg').getScreenCTM().inverse());
  const zx=Number($('zonaCorte').getAttribute('cx')), zy=Number($('zonaCorte').getAttribute('cy'));
  if(Math.hypot(local.x-zx,local.y-zy)<=24){ talar(); moverZona(); }
});
nuevo(); updArbol(); moverZona(); refrescar();
