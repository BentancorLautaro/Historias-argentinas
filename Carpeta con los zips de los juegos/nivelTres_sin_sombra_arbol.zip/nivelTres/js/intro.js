
document.getElementById('btn-comenzar-intro').addEventListener('click',function(){
  const intro=document.getElementById('intro-funcionamiento');
  if(intro) intro.remove();
});
