/**
 * Inicializa la aplicación y conecta los módulos principales.
 * Es el punto de composición donde se crean servicios y callbacks.
 */

import { GestorAudio } from './audio.js';
import { GestorMenu } from './menu.js';
import { NivelUno } from './nivelUno.js';
import { NivelDos } from './nivelDos.js';
import { NIVEL_JUGABLE, NIVEL_DOS_JUGABLE } from './configuracion.js';
import { alternarPantalla } from './interfaz.js';

function inicializarAplicacion() {
  const audio = new GestorAudio();
  let nivelActual = NIVEL_JUGABLE;
  let nivelUno = null;
  let nivelDos = null;
  let menu = null;

  const volverAlMenuTrasNivel = (idPantallaJuego, nivelCompletado) => {
    const pantallaJuego = document.getElementById(idPantallaJuego);
    alternarPantalla(pantallaJuego, false);
    audio.detenerHojas();
    menu.mostrarSeleccionTrasCompletar(nivelCompletado);
  };

  const iniciarNivel = (nivelSeleccionado, desdeIntro = false) => {
    nivelActual = Number(nivelSeleccionado);

    if (nivelActual === 3 && !desdeIntro) {
      alternarPantalla(document.getElementById('level-select-screen'), false);
      alternarPantalla(document.getElementById('level-three-intro-screen'), true);
      return;
    }

    if (nivelActual !== NIVEL_JUGABLE && nivelActual !== NIVEL_DOS_JUGABLE && nivelActual !== 3) {
      const retroalimentacion = document.getElementById('level-select-feedback');
      retroalimentacion.textContent = `NIVEL ${nivelActual} DESBLOQUEADO · SU INSTANCIA JUGABLE TODAVÍA NO ESTÁ INTEGRADA`;
      return;
    }

    alternarPantalla(document.getElementById('level-select-screen'), false);

    if (nivelActual === 3) {
      alternarPantalla(document.getElementById('level-three-intro-screen'), false);
      alternarPantalla(document.getElementById('level-three-screen'), true);
      const frame = document.getElementById('level-three-frame');
      if (frame) frame.src = './nivelTres.html';
      return;
    }

    if (nivelActual === NIVEL_JUGABLE) {
      if (!nivelUno) {
        nivelUno = new NivelUno(audio, (nivelCompletado) => {
          volverAlMenuTrasNivel('game-screen', nivelCompletado);
        });
      }
      nivelUno.iniciar();
      return;
    }

    if (!nivelDos) {
      nivelDos = new NivelDos(audio, (nivelCompletado) => {
        volverAlMenuTrasNivel('game-screen-dos', nivelCompletado);
      });
    }
    nivelDos.iniciar();
  };

  window.addEventListener('message', (event) => {
    if (event.data?.type === 'nivel3-salir') {
      alternarPantalla(document.getElementById('level-three-screen'), false);
      menu.mostrarSeleccionNiveles();
    } else if (event.data?.type === 'nivel3-completo') {
      volverAlMenuTrasNivel('level-three-screen', 3);
    }
  });

  menu = new GestorMenu(audio, iniciarNivel);
}

export { inicializarAplicacion };
