/**
 * Navega entre menú principal, niveles, créditos y configuración.
 * El desbloqueo persistente se delega en persistencia.js.
 */

import {
  NIVEL_MAXIMO,
  CLAVE_NIVEL_DESBLOQUEADO
} from './configuracion.js';
import {
  obtenerNivelDesbloqueado,
  guardarNivelDesbloqueado
} from './persistencia.js';
import { GestorAjustes } from './ajustes.js';
import { alternarPantalla } from './interfaz.js';

class GestorMenu {
  constructor(audio, alIniciarNivel) {
    this.audio = audio;
    this.alIniciarNivel = alIniciarNivel;
    this.claveAlmacenamiento = CLAVE_NIVEL_DESBLOQUEADO;

    this.pantallaInicio = document.getElementById('start-screen');
    this.pantallaNiveles = document.getElementById('level-select-screen');
    this.pantallaCreditos = document.getElementById('credits-screen');
    this.pantallaAjustes = document.getElementById('settings-screen');
    this.pantallaAyuda = document.getElementById('help-screen');
    this.pantallaNivelTresIntro = document.getElementById('level-three-intro-screen');
    this.retroalimentacion = document.getElementById('level-select-feedback');

    this.gestorAjustes = new GestorAjustes(this.audio);
    this.inicializarEventos();
    this.gestorAjustes.inicializar();
    // Nivel 3 queda desbloqueado desde el inicio.
    guardarNivelDesbloqueado(3);
    this.actualizarTarjetas();
  }

  obtenerNivelDesbloqueado() {
    return obtenerNivelDesbloqueado();
  }

  establecerNivelDesbloqueado(nivel) {
    guardarNivelDesbloqueado(nivel);
    this.actualizarTarjetas();
  }

  actualizarTarjetas() {
    const desbloqueado = Math.max(3, this.obtenerNivelDesbloqueado());

    document.querySelectorAll('.level-card').forEach((tarjeta) => {
      const nivel = Number(tarjeta.dataset.level);
      const habilitado = nivel <= desbloqueado;

      tarjeta.classList.toggle('is-locked', !habilitado);
      tarjeta.classList.toggle('is-unlocked', habilitado);
      tarjeta.setAttribute('aria-disabled', String(!habilitado));

      const estado = tarjeta.querySelector('.level-card-status');
      if (estado) estado.textContent = habilitado ? 'DESBLOQUEADO' : 'BLOQUEADO';
    });
  }

  inicializarEventos() {
    document.getElementById('btn-play').addEventListener('click', () => {
      this.audio.reproducirClick();
      this.mostrarSeleccionNiveles();
    });

    document.getElementById('btn-credits').addEventListener('click', () => {
      this.audio.reproducirClick();
      this.navegarA(this.pantallaCreditos);
    });

    document.getElementById('btn-help').addEventListener('click', () => {
      this.audio.reproducirClick();
      this.navegarA(this.pantallaAyuda);
    });

    document.getElementById('btn-settings').addEventListener('click', () => {
      this.audio.reproducirClick();
      this.navegarA(this.pantallaAjustes);
    });

    document.getElementById('btn-back-credits').addEventListener('click', () => {
      this.audio.reproducirClick();
      this.navegarA(this.pantallaInicio);
    });

    document.getElementById('btn-back-help').addEventListener('click', () => {
      this.audio.reproducirClick();
      this.navegarA(this.pantallaInicio);
    });

    document.getElementById('btn-back-settings').addEventListener('click', () => {
      this.audio.reproducirClick();
      this.navegarA(this.pantallaInicio);
    });

    document.getElementById('btn-start-level-three').addEventListener('click', () => {
      this.audio.reproducirClick();
      this.alIniciarNivel(3, true);
    });

    document.getElementById('btn-back-level-three-intro').addEventListener('click', () => {
      this.audio.reproducirClick();
      this.navegarA(this.pantallaNiveles);
    });

    document.getElementById('btn-back-levels').addEventListener('click', () => {
      this.audio.reproducirClick();
      this.retroalimentacion.textContent = '';
      this.navegarA(this.pantallaInicio);
    });

    document.querySelectorAll('.level-card').forEach((tarjeta) => {
      tarjeta.addEventListener('click', () => this.seleccionarNivel(Number(tarjeta.dataset.level)));
    });

    document.querySelectorAll('button').forEach((boton) => {
      boton.addEventListener('mouseenter', () => this.audio.reproducirHover());
    });
  }

  seleccionarNivel(nivel) {
    const desbloqueado = Math.max(3, this.obtenerNivelDesbloqueado());

    if (nivel > desbloqueado) {
      this.audio.reproducirClick();
      this.retroalimentacion.textContent = `NIVEL ${nivel} BLOQUEADO · COMPLETÁ EL NIVEL ${nivel - 1} PARA DESBLOQUEARLO`;
      return;
    }

    this.audio.reproducirClick();
    this.retroalimentacion.textContent = '';
    this.alIniciarNivel(nivel);
  }

  mostrarSeleccionNiveles() {
    this.retroalimentacion.textContent = '';
    this.actualizarTarjetas();
    this.navegarA(this.pantallaNiveles);
  }

  mostrarSeleccionTrasCompletar(nivelCompletado) {
    const siguiente = Number(nivelCompletado) + 1;
    if (siguiente <= NIVEL_MAXIMO) this.establecerNivelDesbloqueado(siguiente);
    this.mostrarSeleccionNiveles();
  }

  navegarA(pantallaObjetivo) {
    [this.pantallaInicio, this.pantallaNiveles, this.pantallaCreditos, this.pantallaAjustes, this.pantallaAyuda, this.pantallaNivelTresIntro, document.getElementById('level-three-screen'), document.getElementById('game-screen'), document.getElementById('game-screen-dos')]
      .forEach((pantalla) => alternarPantalla(pantalla, false));
    alternarPantalla(pantallaObjetivo, true);
  }
}

export { GestorMenu };
