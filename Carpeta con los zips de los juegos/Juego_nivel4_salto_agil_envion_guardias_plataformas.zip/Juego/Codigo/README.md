# Juego educativo: investigación histórica sobre *Facundo*

## Antes de trabajar con el proyecto

Si sos una IA o una persona que va a mantener este juego, leé primero:

1. `README_MODULARIZACION.md` — arquitectura y responsabilidades generales.
2. `MODULARIZACION.md` — notas de organización del código.
3. `GUIA_MODIFICACION_POR_NIVEL.md` — mapa de archivos por capítulo, secciones, mecánicas y variables ajustables.
4. `README_NIVEL_DOS.md` — contexto específico del capítulo 2.

**Regla principal:** encontrar el archivo responsable y hacer cambios pequeños. No reemplazar la arquitectura modular con un archivo gigante ni modificar la mecánica compartida sin revisar qué capítulos la usan.

## Ejecutar

El juego carga secciones HTML mediante `fetch` y utiliza módulos ES. Abrí la carpeta `Juego/Codigo/` desde un servidor local, por ejemplo XAMPP, y accedé por `http://localhost/.../Codigo/`. No uses `file://`, porque el navegador puede bloquear la carga de secciones y módulos.

## Estructura

- `index.html`: entrada de la aplicación.
- `secciones/`: pantallas HTML independientes.
- `js/`: lógica modular, datos, estado, persistencia y mecánicas.
- `css/`: estilos de cada pantalla y reglas compartidas.
- `../Assets/`: imágenes, audio, mapas y material de referencia.

## Capítulos

- **Capítulo 1 — El diario de Facundo:** leer y comparar diarios, responder preguntas y conectar recortes de distintas fuentes. La coordinación está en `js/nivelUno.js`; los textos y datos están en `js/datosNivelUno.js`.
- **Capítulo 2 — Voces en la Pulpería:** recorrer el pueblo, conversar con personajes, obtener pistas a través de mecánicas diferenciadas, responder preguntas y conectar evidencias. La coordinación está en `js/nivelDos.js`; los personajes y datos están en `js/datosNivelDos.js`.

## Configuración secreta de testing

En la pantalla Configuración, hacer cinco clics en el título `CONFIGURACION`. Aparecerá el panel de pruebas: introducir `1010` y pulsar `DESBLOQUEAR` para desbloquear las tarjetas de todos los niveles en ese navegador. Es una ayuda de desarrollo local, no una protección de seguridad. Los niveles sin contenido jugable completo pueden seguir sin estar implementados aunque la tarjeta quede desbloqueada.

## Validaciones recomendadas después de modificar

1. Ejecutar `node --check` para cada JavaScript modificado.
2. Comprobar que los nombres de `id`/clases de HTML coincidan con los selectores del JS y CSS.
3. Abrir el juego desde servidor local y revisar la consola del navegador.
4. Probar el recorrido afectado y comprobar que guardar, recargar y volver al menú sigan funcionando.
5. Al entregar un ZIP, comprobar su integridad y resumir los archivos modificados y las pruebas reales ejecutadas.

Para localizar un archivo concreto, consultar `GUIA_MODIFICACION_POR_NIVEL.md`.


## Ajustes de flujo del Nivel 2 (27/10/2026)
- El capítulo termina al interrogar a los cuatro personajes; el cuestionario final y el tablero de unir recortes ya no forman parte del recorrido.
- La misión de Don Eusebio requiere volver a hablar con él después de reunir los testimonios de Doña Jacinta, Mateo y Tomasa.
- El Cantor ahora muestra una pantalla de derrota al llegar a 0 de Gloria Criolla y permite reintentar.
- Los textos previos a cada minijuego amplían el contexto histórico del personaje y explican la relación entre su rol, el desafío y la investigación.

## Sprites de personajes (Nivel 2)

Los PNG se colocan en `Assets/Recursos Graficos/Sprites/`. Los nombres y tamaños recomendados están en `Assets/Recursos Graficos/Sprites/README.md`. Para NPC, editar las rutas de las imágenes en `Codigo/secciones/nivel-dos.html`; para sprites del jugador y animación por dirección, editar `Codigo/css/nivelDos.css`.
