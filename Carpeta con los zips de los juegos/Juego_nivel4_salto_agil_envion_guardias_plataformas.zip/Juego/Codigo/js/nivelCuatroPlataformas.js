class NivelCuatroPlataformas {
  constructor(alCompletar, alSalir) {
    this.canvas = document.getElementById('plataformas-canvas');
    this.ctx = this.canvas.getContext('2d');
    this.overlay = document.getElementById('plataformas-overlay');
    this.lectura = document.getElementById('plataformas-lectura');
    this.alCompletar = alCompletar;
    this.alSalir = alSalir;
    this.teclas = new Set(); this.activo = false; this.pausado = false; this.terminado = false;
    this.anterior = 0; this.acumulado = 0; this.velocidadGuardadaLectura = 0; this.vidas = 3; this.provisiones = 0; this.tieneCarta = false; this.checkpoint = 180;
    this.jugador = {x:70,y:360,w:25,h:42,vx:0,vy:0,suelo:false,invulnerable:0,direccion:1};
    this.mundo = {ancho:5100,alto:540,camara:0};
    this.plataformas = []; this.zanjas = []; this.objetos = []; this.enemigos = []; this.puntos = []; this.carteles = []; this.peligros = [];
    this.construirMundo(); this.conectarEventos(); this.dibujar(0);
  }
  construirMundo() {
    const suelo = (x,w,y=440)=>this.plataformas.push({x,y,w,h:100,tipo:'tierra'});
    // Cuatro sectores conectados, con saltos calculados para una velocidad horizontal moderada.
    suelo(0,700); suelo(755,650); suelo(1460,720); suelo(2220,600); suelo(2850,620); suelo(3500,700); suelo(4240,860);
    const p=(x,y,w,h=18,tipo='madera')=>this.plataformas.push({x,y,w,h,tipo});
    [[180,365,95],[330,330,95],[520,360,90],[820,365,100],[990,320,100],[1160,355,90],[1510,360,110],[1690,315,100],[1900,355,100],[2260,350,100],[2430,305,100],[2640,350,90],[2920,360,110],[3110,315,100],[3330,350,100],[3560,350,110],[3750,300,100],[3970,350,100],[4300,355,110],[4500,310,110],[4730,350,100]].forEach(a=>p(...a));
    this.zanjas=[{x:700,w:55},{x:1405,w:55},{x:2180,w:40},{x:2820,w:30},{x:3460,w:40},{x:4200,w:40}];
    // Peligros estáticos colocados en el camino: hay que saltarlos.
    this.peligros=[{x:620,w:30,h:26,tipo:'pinchos'},{x:1040,w:34,h:28,tipo:'fogata'},{x:1325,w:30,h:26,tipo:'pinchos'},{x:1815,w:36,h:28,tipo:'fogata'},{x:2070,w:32,h:26,tipo:'pinchos'},{x:2565,w:34,h:28,tipo:'fogata'},{x:2760,w:30,h:26,tipo:'pinchos'},{x:3290,w:36,h:28,tipo:'fogata'},{x:3395,w:30,h:26,tipo:'pinchos'},{x:4020,w:36,h:28,tipo:'fogata'},{x:4140,w:30,h:26,tipo:'pinchos'},{x:4650,w:34,h:28,tipo:'fogata'}];
    this.puntos=[{x:1520,activado:false},{x:2870,activado:false},{x:4250,activado:false}];
    this.objetos=[{x:125,y:400,tipo:'carta',recogido:false},{x:430,y:285,tipo:'provision',recogido:false},{x:900,y:400,tipo:'provision',recogido:false},{x:1200,y:310,tipo:'documento',recogido:false,texto:'La Revolución de Mayo de 1810 formó una junta de gobierno en Buenos Aires. El proceso abrió un período de cambios y conflictos; no significó que todo el territorio tuviera una respuesta uniforme.'},{x:1780,y:275,tipo:'provision',recogido:false},{x:2350,y:400,tipo:'documento',recogido:false,texto:'Las ciudades y las campañas rurales tenían economías, vínculos sociales y formas de autoridad diferentes. Sus intereses no siempre coincidían, aunque estaban conectados.'},{x:2730,y:310,tipo:'provision',recogido:false},{x:3210,y:285,tipo:'documento',recogido:false,texto:'Las montoneras fueron fuerzas armadas irregulares, con fuerte presencia de jinetes rurales, que participaron en conflictos políticos del siglo XIX. Sus objetivos y composición variaron según la región y el momento.'},{x:3860,y:270,tipo:'provision',recogido:false},{x:4430,y:400,tipo:'documento',recogido:false,texto:'Sarmiento interpretó la historia argentina mediante la oposición entre civilización y barbarie. Es una mirada influyente, pero discutida: no debe confundirse su valoración de los gauchos con una descripción neutral aceptada por todos los historiadores.'}];
    // Todos los guardias empiezan detrás del jugador; ninguno aparece delante al iniciar.
    this.enemigos=[{x:-170,min:0,max:900,v:0,w:28,h:42,tipo:'guardia'},{x:-245,min:0,max:1700,v:0,w:28,h:42,tipo:'guardia'},{x:-320,min:0,max:2500,v:0,w:28,h:42,tipo:'guardia'},{x:-395,min:0,max:3200,v:0,w:28,h:42,tipo:'guardia'},{x:-470,min:0,max:3900,v:0,w:28,h:42,tipo:'guardia'},{x:-545,min:0,max:4700,v:0,w:28,h:42,tipo:'guardia'}];
    this.carteles=[{x:360,titulo:'EL RANCHO',texto:'El viaje comienza en un rancho de la campaña. Llevás una carta: cruzá las zanjas y buscá el camino hacia el campamento.'},{x:1630,titulo:'LOS CAMINOS DE LAS PAMPAS',texto:'Los caminos rurales conectaban estancias, pueblos y puestos. Los caballos eran esenciales para recorrer largas distancias.'},{x:2980,titulo:'EL CAMPAMENTO',texto:'En los años posteriores a 1810, distintos grupos se movilizaron por motivos políticos y militares. La vida rural también quedó atravesada por esos conflictos.'},{x:4500,titulo:'EL ASENTAMIENTO',texto:'Entregá la carta a la persona que espera junto al rancho para terminar la misión.'}];
  }
  conectarEventos(){
    window.addEventListener('keydown',e=>{if(['ArrowLeft','ArrowRight','ArrowUp',' ','w','W','a','A','d','D','e','E','Escape'].includes(e.key))e.preventDefault(); if((e.key==='e'||e.key==='E')&&this.lecturaAbierta){this.cerrarLectura();return;}if(e.key==='Escape'&&this.activo&&!this.terminado&&!this.lectura.classList.contains('hidden')){this.cerrarLectura();return;}if(e.key==='Escape'&&this.activo&&!this.terminado){this.pausar();return;}if((e.key===' '||e.key==='ArrowUp'||e.key==='w'||e.key==='W')&&!this.teclas.has(e.key))this.saltar();if((e.key==='e'||e.key==='E')&&!this.lecturaAbierta)this.interactuar();this.teclas.add(e.key);});
    window.addEventListener('keyup',e=>this.teclas.delete(e.key));
    document.getElementById('plataformas-jugar').addEventListener('click',()=>{if(this.terminado&&this.jugador.x>4900){this.alCompletar();return;}if(this.pausado){this.pausado=false;this.overlay.classList.add('hidden');this.anterior=performance.now();requestAnimationFrame(t=>this.bucle(t));return;}if(this.terminado)this.reiniciarEstado();this.iniciar();});
    document.getElementById('plataformas-pausa').addEventListener('click',()=>this.pausar());
    document.getElementById('plataformas-salir').addEventListener('click',()=>{this.detener();this.alSalir();});
    document.getElementById('plataformas-cerrar-lectura').addEventListener('click',()=>this.cerrarLectura());
  }
  iniciar(){this.overlay.classList.add('hidden');this.activo=true;this.pausado=false;this.anterior=performance.now();this.terminado=false;requestAnimationFrame(t=>this.bucle(t));}
  reiniciarEstado(){this.vidas=3;this.provisiones=0;this.tieneCarta=false;this.checkpoint=180;this.jugador={x:70,y:360,w:25,h:42,vx:0,vy:0,suelo:false,invulnerable:0,direccion:1};this.objetos.forEach(o=>o.recogido=false);this.puntos.forEach(p=>p.activado=false);document.getElementById('plataformas-jugar').textContent='JUGAR';document.getElementById('plataformas-jugar').onclick=null;this.terminado=false;this.mundo.camara=0;}
  detener(){this.activo=false;this.teclas.clear();}
  pausar(){if(!this.activo||this.terminado)return;this.pausado=!this.pausado;this.teclas.clear();if(this.pausado){this.overlay.classList.remove('hidden');document.getElementById('plataformas-titulo').textContent='PAUSA';document.getElementById('plataformas-mensaje').textContent='La aventura está pausada.';document.getElementById('plataformas-jugar').textContent='CONTINUAR';}else{this.overlay.classList.add('hidden');this.anterior=performance.now();requestAnimationFrame(t=>this.bucle(t));}}
  saltar(){if(this.activo&&!this.pausado&&!this.terminado&&this.lectura.classList.contains('hidden')&&this.jugador.suelo){this.jugador.vy=-540;this.jugador.suelo=false;this.jugador.sueloCoyote=0;}}
  interactuar(){if(!this.activo||this.pausado||this.terminado)return;const j=this.jugador;const cerca=(o)=>Math.abs((o.x||0)-(j.x+j.w/2))<65;
    const c=this.carteles.find(o=>cerca(o));if(c){this.mostrarLectura(c.titulo,c.texto);return;}
    const doc=this.objetos.find(o=>o.tipo==='documento'&&!o.recogido&&cerca(o));if(doc){this.mostrarLectura('DOCUMENTO DE CAMINO',doc.texto);doc.recogido=true;return;}
    if(j.x>4860){if(this.tieneCarta){this.victoria();}else this.mostrarLectura('FALTA LA CARTA','Volvé al comienzo del camino y recogé la carta que te encargaron llevar.');}}
  mostrarLectura(titulo,texto){if(this.lecturaAbierta)return;this.velocidadGuardadaLectura=this.jugador.vx;this.lecturaAbierta=true;document.getElementById('plataformas-lectura-titulo').textContent=titulo;document.getElementById('plataformas-lectura-texto').textContent=texto;this.lectura.classList.remove('hidden');this.teclas.clear();}
  cerrarLectura(){this.lectura.classList.add('hidden');this.lecturaAbierta=false;this.teclas.clear();if(this.activo&&!this.pausado&&!this.terminado){/* Reanudar conservando el envión que tenía el jugador antes de leer. */this.jugador.vx=this.velocidadGuardadaLectura;this.anterior=performance.now();requestAnimationFrame(t=>this.bucle(t));}}
  bucle(t){if(!this.activo||this.pausado||this.terminado||this.lecturaAbierta)return;const dt=Math.min((t-this.anterior)/1000,.032);this.anterior=t;this.actualizar(dt);this.dibujar(t);requestAnimationFrame(n=>this.bucle(n));}
  actualizar(dt){const j=this.jugador;const izq=this.teclas.has('ArrowLeft')||this.teclas.has('a')||this.teclas.has('A');const der=this.teclas.has('ArrowRight')||this.teclas.has('d')||this.teclas.has('D');const velocidad=izq?-220:der?220:0;const aceleracion=velocidad!==0?Math.min(1,dt*12):Math.min(1,dt*2.2);j.vx+=(velocidad-j.vx)*aceleracion;if(Math.abs(j.vx)<2)j.vx=0;if(j.vx)j.direccion=Math.sign(j.vx);const antesY=j.y;j.x=Math.max(0,Math.min(this.mundo.ancho-j.w,j.x+j.vx*dt));j.vy=Math.min(760,j.vy+1350*dt);j.y+=j.vy*dt;j.suelo=false;
    // Colisión vertical con superficies: aterriza solo al caer desde arriba.
    if(j.vy>=0){for(const p of this.plataformas){if(j.x+j.w>p.x&&j.x<p.x+p.w&&antesY+j.h<=p.y+4&&j.y+j.h>=p.y){j.y=p.y-j.h;j.vy=0;j.suelo=true;}}}
    if(j.vy<0){for(const p of this.plataformas){if(j.x+j.w>p.x&&j.x<p.x+p.w&&antesY>=p.y+p.h&&j.y<=p.y+p.h){j.y=p.y+p.h;j.vy=0;}}}
    // Zanja: si el jugador no alcanzó la plataforma, cae y reaparece en el punto de control.
    if(j.y>560)this.perderVida();
    this.enemigos.forEach(e=>{
      // IA de persecución con gravedad: los guardias saltan para subir a plataformas.
      const velocidadPersecucion=190+Math.min(70,j.x/70);
      const objetivo=j.x-e.w+3;
      if(e.x<objetivo)e.x=Math.min(objetivo,e.x+velocidadPersecucion*dt);
      // No teleportarlos sobre el jugador: si lo pasan, vuelven a quedar detrás.
      if(e.x>j.x+j.w-4)e.x=j.x-e.w+3;
      const antesGuardiaY=e.y;
      e.vy=(e.vy||0)+1350*dt;
      e.y+=e.vy*dt;
      e.suelo=false;
      if(e.vy>=0){for(const p of this.plataformas){if(e.x+e.w>p.x&&e.x<p.x+p.w&&antesGuardiaY+e.h<=p.y+4&&e.y+e.h>=p.y){e.y=p.y-e.h;e.vy=0;e.suelo=true;}}}
      if(e.vy<0){for(const p of this.plataformas){if(e.x+e.w>p.x&&e.x<p.x+p.w&&antesGuardiaY>=p.y+p.h&&e.y<=p.y+p.h){e.y=p.y+p.h;e.vy=0;}}}
      // Si hay una plataforma elevada delante y el guardia está apoyado, intenta saltar.
      if(e.suelo){const plataforma=this.plataformas.find(p=>p.tipo!=='tierra'&&p.x+p.w>e.x+e.w&&p.x-e.x<115&&p.y<e.y+e.h-12);if(plataforma){e.vy=-500;e.suelo=false;}}
      // En suelo abierto, mantener a los perseguidores apoyados en el terreno.
      if(e.y>440-e.h&&e.x>=0){e.y=440-e.h;e.vy=0;e.suelo=true;}
      if(j.invulnerable<=0&&j.x<e.x+e.w&&j.x+j.w>e.x&&j.y<e.y+e.h&&j.y+j.h>e.y)this.perderVida();
    });
    this.peligros.forEach(p=>{const py=440-p.h;if(j.invulnerable<=0&&j.x+j.w>p.x&&j.x<p.x+p.w&&j.y+j.h>py&&j.y<440)this.perderVida();});
    if(j.invulnerable>0)j.invulnerable-=dt;
    this.objetos.forEach(o=>{if(o.recogido)return;const oy=o.tipo==='provision'||o.tipo==='documento'?o.y:400;if(j.x<o.x+24&&j.x+j.w>o.x&&j.y<oy+24&&j.y+j.h>oy){if(o.tipo==='carta'){o.recogido=true;this.tieneCarta=true;this.mostrarLectura('CARTA RECOGIDA','La carta está en tus manos. Cruzá las pampas y entregala en el asentamiento.');}else if(o.tipo==='provision'){o.recogido=true;this.provisiones++;}else {o.recogido=true;this.mostrarLectura('DOCUMENTO DE CAMINO',o.texto);}}});
    this.puntos.forEach(p=>{if(!p.activado&&j.x>p.x){p.activado=true;this.checkpoint=p.x;document.getElementById('plataformas-sector').textContent='PUNTO DE CONTROL ACTIVADO';}});
    this.mundo.camara=Math.max(0,Math.min(this.mundo.ancho-this.canvas.width,j.x-this.canvas.width*.35));
    document.getElementById('plataformas-vidas').textContent='♥ '.repeat(this.vidas).trim()||'SIN VIDAS';document.getElementById('plataformas-cartas').textContent=`Carta: ${this.tieneCarta?1:0}/1`;document.getElementById('plataformas-provisiones').textContent=`Provisiones: ${this.provisiones}`;
    const x=j.x;document.getElementById('plataformas-sector').textContent=x<700?'SECTOR 1 · EL RANCHO':x<2200?'SECTOR 2 · LOS CAMINOS DE LAS PAMPAS':x<4200?'SECTOR 3 · EL CAMPAMENTO':'SECTOR 4 · EL ASENTAMIENTO';if(j.x>4900&&this.tieneCarta)this.victoria();
  }
  perderVida(){if(this.jugador.invulnerable>0||this.terminado)return;this.vidas--;if(this.vidas<=0){this.terminado=true;this.activo=false;this.overlay.classList.remove('hidden');document.getElementById('plataformas-titulo').textContent='FIN DEL VIAJE';document.getElementById('plataformas-mensaje').textContent='Te quedaste sin vidas, pero podés intentarlo otra vez.';document.getElementById('plataformas-jugar').textContent='REINTENTAR';this.vidas=3;return;}this.jugador.x=this.checkpoint;this.jugador.y=340;this.jugador.vx=0;this.jugador.vy=0;this.jugador.invulnerable=1.8;this.teclas.clear();
    // Reiniciar a todos los perseguidores detrás del punto de reaparición para evitar que campeen el spawn.
    this.enemigos.forEach((e,i)=>{e.x=Math.max(-e.w,this.jugador.x-260-i*95);e.y=440-e.h;e.v=0;e.vy=0;e.suelo=true;});}
  victoria(){if(this.terminado)return;this.terminado=true;this.activo=false;this.overlay.classList.remove('hidden');document.getElementById('plataformas-titulo').textContent='¡Mensaje entregado!';document.getElementById('plataformas-mensaje').textContent='En el capítulo IV, «Revolución de 1810», Sarmiento narra el impacto de la revolución y el papel de las campañas en los conflictos posteriores. Su oposición entre ciudad y campo es una interpretación del autor, no una descripción neutral de toda la sociedad.';document.getElementById('plataformas-jugar').textContent='VOLVER A NIVELES';}
  dibujar(t){
    const c=this.ctx,cam=this.mundo.camara;c.imageSmoothingEnabled=false;c.clearRect(0,0,960,540);
    // Cielo en bandas, con horizonte cálido y nubes pixeladas.
    c.fillStyle='#87b9c8';c.fillRect(0,0,960,540);c.fillStyle='#a9ced0';c.fillRect(0,130,960,170);c.fillStyle='#d9d9b1';c.fillRect(0,260,960,80);
    // Sol bajo, nubes con sombra y parallax en varias distancias.
    c.fillStyle='#f0d79a';c.fillRect(748,68,42,42);c.fillRect(758,58,22,62);c.fillRect(738,78,62,22);
    for(let i=0;i<7;i++){let x=((i*193-cam*.12)%1250+1250)%1250-100,y=45+(i%3)*35;c.fillStyle='#8db4bd';c.fillRect(x+8,y+8,50,12);c.fillRect(x+18,y,27,12);c.fillStyle='#e0e4cf';c.fillRect(x,y,54,12);c.fillRect(x+10,y-8,28,12);c.fillRect(x+32,y,24,12);}
    // Sierras lejanas, lomas intermedias y pastizales próximos.
    c.fillStyle='#a4b99a';for(let i=0;i<8;i++){let x=((i*190-cam*.19)%1500+1500)%1500-120;c.beginPath();c.moveTo(x,325);c.lineTo(x+80,225+(i%3)*18);c.lineTo(x+170,325);c.fill();}
    c.fillStyle='#829c72';for(let i=0;i<10;i++){let x=((i*150-cam*.32)%1400+1400)%1400-100;c.fillRect(x,320,155,95);c.fillRect(x+25,295,105,35);c.fillRect(x+45,280,60,18);}
    c.fillStyle='#6d895a';c.fillRect(0,385,960,155);c.fillStyle='#78945e';c.fillRect(0,400,960,35);
    // Árboles, postes y cercas en capas, con textura de pixel art.
    for(let i=0;i<18;i++){let wx=i*310+120,x=wx-cam*.62;if(x<-40||x>1000)continue;c.fillStyle='#624b32';c.fillRect(x+12,326,9,62);c.fillStyle='#3f6547';c.fillRect(x,292,34,32);c.fillRect(x-8,307,18,25);c.fillStyle='#55784b';c.fillRect(x+5,280,25,20);c.fillStyle='#7e9a60';c.fillRect(x+7,289,8,6);}
    for(let i=0;i<30;i++){let wx=260+i*170,x=wx-cam;if(x<-20||x>980)continue;c.fillStyle='#8a6842';c.fillRect(x,402,4,37);c.fillRect(x+45,402,4,37);c.fillRect(x-3,410,54,5);c.fillRect(x-3,425,54,5);c.fillStyle='#b18a56';c.fillRect(x+1,405,2,5);}
    // Suelo con capas de tierra, raíces, piedras y briznas. Los huecos permanecen abiertos.
    this.plataformas.forEach(p=>{const x=Math.round(p.x-cam);if(x+p.w<0||x>960)return;
      if(p.tipo==='tierra'){c.fillStyle='#65452f';c.fillRect(x,p.y,p.w,p.h);c.fillStyle='#8b6240';c.fillRect(x,p.y,p.w,10);c.fillStyle='#b2a06a';c.fillRect(x,p.y,p.w,4);c.fillStyle='#71834e';for(let q=5;q<p.w;q+=17){c.fillRect(x+q,p.y-4,2,5);c.fillRect(x+q+3,p.y-2,2,3);}for(let q=8;q<p.w;q+=29){c.fillStyle='#65452f';c.fillRect(x+q,p.y+18+(q%3)*8,7,3);c.fillStyle='#9b7951';c.fillRect(x+q+2,p.y+34+(q%2)*7,4,3);}c.fillStyle='#4c3929';for(let q=16;q<p.w;q+=73){c.fillRect(x+q,p.y+p.h-12,10,3);c.fillRect(x+q+4,p.y+p.h-16,3,5);}}
      else {c.fillStyle='#68482e';c.fillRect(x,p.y,p.w,p.h);c.fillStyle='#b58a54';c.fillRect(x,p.y,p.w,5);c.fillStyle='#8b6139';c.fillRect(x,p.y+6,p.w,p.h-6);for(let q=8;q<p.w;q+=24){c.fillStyle='#d0a66a';c.fillRect(x+q,p.y+7,2,3);c.fillStyle='#533a27';c.fillRect(x+q+10,p.y+12,4,2);}}
    });
    this.zanjas.forEach(z=>{const x=Math.round(z.x-cam);c.fillStyle='#40352a';c.fillRect(x,440,z.w,100);c.fillStyle='#302a23';c.fillRect(x,440,z.w,12);c.fillStyle='#58422d';for(let q=4;q<z.w;q+=12)c.fillRect(x+q,460+(q%3)*12,5,3);c.fillStyle='#6e8953';c.fillRect(x-3,437,5,5);c.fillRect(x+z.w-2,437,5,5);});
    const deco=[{x:65,y:365,t:'rancho'},{x:870,y:385,t:'carreta'},{x:1510,y:390,t:'tienda'},{x:1700,y:385,t:'fogata'},{x:2310,y:390,t:'carreta'},{x:2920,y:390,t:'tienda'},{x:3100,y:390,t:'caballo'},{x:4300,y:385,t:'rancho'},{x:4620,y:390,t:'caballo'}];deco.forEach(d=>this.dibujarDecoracion(c,Math.round(d.x-cam),d.y,d.t));
    this.carteles.forEach(o=>{const x=Math.round(o.x-cam);c.fillStyle='#513923';c.fillRect(x-2,367,8,73);c.fillStyle='#8a633c';c.fillRect(x-4,369,3,68);c.fillStyle='#d8bd80';c.fillRect(x-32,349,70,23);c.fillStyle='#8c6841';c.fillRect(x-32,349,70,3);c.fillStyle='#3b3022';c.font='bold 8px monospace';c.fillText('LEER [E]',x-25,364);});
    this.objetos.forEach(o=>{if(o.recogido)return;const x=Math.round(o.x-cam),y=o.y;if(o.tipo==='carta'){c.fillStyle='#7b5937';c.fillRect(x-2,y+3,22,23);c.fillStyle='#f4e4b7';c.fillRect(x,y,18,22);c.fillStyle='#c9b58a';c.fillRect(x+2,y+3,14,16);c.fillStyle='#a64d3a';c.fillRect(x+4,y+6,10,2);c.fillRect(x+4,y+11,8,2);c.fillStyle='#d5b36d';c.fillRect(x+6,y+17,5,2);}
      else if(o.tipo==='provision'){c.fillStyle='#755238';c.fillRect(x+2,y+3,18,17);c.fillStyle='#c6a064';c.fillRect(x,y+2,18,16);c.fillStyle='#e3c784';c.fillRect(x+3,y,12,3);c.fillStyle='#8c6a42';c.fillRect(x+5,y+6,8,8);c.fillStyle='#6b7544';c.fillRect(x+8,y+7,3,6);}
      else {c.fillStyle='#75533a';c.fillRect(x+2,y+2,20,25);c.fillStyle='#f3e5bf';c.fillRect(x,y,20,25);c.fillStyle='#c8b48a';c.fillRect(x+2,y+2,16,21);c.fillStyle='#a34b38';c.fillRect(x+4,y+5,12,2);c.fillRect(x+4,y+10,10,2);c.fillRect(x+4,y+15,7,2);c.fillStyle='#d5bd8b';c.fillRect(x+13,y+18,4,4);}});
    this.puntos.forEach(p=>{const x=Math.round(p.x-cam);c.fillStyle='#513b27';c.fillRect(x,370,7,70);c.fillStyle=p.activado?'#d7bd72':'#8b6843';c.fillRect(x-8,361,24,18);c.fillStyle='#f2e3b8';c.fillRect(x-5,364,18,11);c.fillStyle='#a14d39';c.fillRect(x,366,8,2);});
    this.peligros.forEach(p=>{const x=Math.round(p.x-cam),base=440;if(x+p.w<0||x>960)return;if(p.tipo==='pinchos'){c.fillStyle='#5c4a38';c.fillRect(x,base-3,p.w,4);c.fillStyle='#b7b6a2';for(let q=0;q<p.w;q+=8){c.beginPath();c.moveTo(x+q,base-3);c.lineTo(x+q+4,base-p.h);c.lineTo(x+q+8,base-3);c.fill();}c.fillStyle='#77766b';for(let q=2;q<p.w;q+=8)c.fillRect(x+q,base-7,2,3);}else{c.fillStyle='#59412c';c.fillRect(x,base-5,p.w,5);c.fillRect(x+4,base-8,p.w-8,3);c.fillStyle='#c45c2c';c.fillRect(x+6,base-p.h+8,p.w-12,p.h-12);c.fillStyle='#f3ad43';c.fillRect(x+10,base-p.h+3,p.w-20,p.h-12);c.fillStyle='#ffe08a';c.fillRect(x+13,base-p.h+8,5,10);c.fillStyle='#d9d1a5';c.fillRect(x+2,base-2,5,2);c.fillRect(x+p.w-7,base-2,5,2);}});
    this.enemigos.forEach(e=>this.dibujarEnemigo(c,Math.round(e.x-cam),e.y||408,e,t));
    this.dibujarJugador(c,Math.round(this.jugador.x-cam),Math.round(this.jugador.y),t);
    c.fillStyle='#23372b';c.fillRect(8,8,180,27);c.fillStyle='#d4b36b';c.fillRect(8,8,Math.max(0,180*Math.min(1,this.jugador.x/this.mundo.ancho)),3);c.fillStyle='#f6e8c5';c.font='12px monospace';c.fillText(`RECORRIDO ${Math.min(100,Math.floor(this.jugador.x/this.mundo.ancho*100))}%`,16,25);
    // Viñeta pixelada muy sutil para separar el plano de juego del marco.
    c.fillStyle='#25392a22';c.fillRect(0,520,960,20);
  }
  dibujarEnemigo(c,x,y,e,t){
    // Guardia a pie con uniforme histórico simplificado; silueta claramente humana.
    const paso=Math.floor(t/120)%2;c.save();
    c.fillStyle='#2b3028';c.fillRect(x+5,y+31,7,9+(paso?2:0));c.fillRect(x+17,y+31,7,9+(paso?0:2));
    c.fillStyle='#6f4931';c.fillRect(x+4,y+15,22,18);c.fillStyle='#9b7046';c.fillRect(x+7,y+17,16,12);
    c.fillStyle='#d1b28a';c.fillRect(x+1,y+18,5,14);c.fillRect(x+24,y+18,5,14);
    c.fillStyle='#c89b6b';c.fillRect(x+9,y+4,12,12);c.fillStyle='#29241f';c.fillRect(x+9,y+2,12,4);c.fillRect(x+6,y+5,18,3);
    c.fillStyle='#3b3026';c.fillRect(x+11,y+9,2,2);c.fillRect(x+17,y+9,2,2);
    c.fillStyle='#8c3328';c.fillRect(x+5,y+15,20,4);c.fillStyle='#d5b879';c.fillRect(x+13,y+16,4,3);
    c.restore();
  }
  dibujarJugador(c,x,y,t){const j=this.jugador;if(j.invulnerable>0&&Math.floor(t/90)%2===0)return;const corriendo=Math.abs(j.vx)>30,salto=!j.suelo,paso=corriendo?Math.floor(t/85)%2:0;
    // Sombra, botas, bombacha, camisa, pañuelo y sombrero de ala ancha.
    c.fillStyle='#35402d66';c.fillRect(x+1,y+40,26,4);
    c.fillStyle='#30271f';c.fillRect(x+4,y+33,8,8);c.fillRect(x+15,y+33+(paso&&!salto?2:0),8,8);c.fillStyle='#6e5438';c.fillRect(x+3,y+38,10,4);c.fillRect(x+14,y+38+(paso&&!salto?2:0),10,4);
    c.fillStyle='#5d7048';c.fillRect(x+4,y+20,18,15);c.fillStyle='#82915c';c.fillRect(x+6,y+21,13,8);c.fillStyle='#d7c49a';c.fillRect(x+8,y+23,3,7);c.fillRect(x+15,y+23,3,7);c.fillStyle='#47382a';c.fillRect(x+3,y+19,21,3);c.fillStyle='#a04d3b';c.fillRect(x+5,y+16,18,5);c.fillStyle='#d9a16a';c.fillRect(x+7,y+16,4,2);
    c.fillStyle='#e9c69b';c.fillRect(x+8,y+5,13,12);c.fillStyle='#3d3024';c.fillRect(x+8,y+4,14,5);c.fillStyle='#f0d5ae';c.fillRect(x+10,y+8,2,2);c.fillRect(x+17,y+8,2,2);c.fillStyle='#392d22';c.fillRect(x+11,y+12,7,2);
    c.fillStyle='#4a3827';c.fillRect(x+3,y+4,24,3);c.fillRect(x+7,y,16,4);c.fillStyle='#87613b';c.fillRect(x+7,y+3,17,2);c.fillStyle='#c4a06a';c.fillRect(x+5,y+5,20,2);
    c.fillStyle='#d8d0ad';c.fillRect(x+10,y+22,2,7);c.fillRect(x+15,y+22,2,7);if(j.tieneCarta){c.fillStyle='#f0dfb0';c.fillRect(x+20,y+22,5,7);c.fillStyle='#a54b38';c.fillRect(x+21,y+24,3,1);}
  }
  dibujarDecoracion(c,x,y,t){if(x<-120||x>1050)return;
    if(t==='rancho'){
      c.fillStyle='#57402b';c.fillRect(x-7,y-43,96,46);c.fillStyle='#b38a58';c.fillRect(x,y-38,80,38);c.fillStyle='#9a7047';c.fillRect(x+5,y-32,70,29);c.fillStyle='#6b4b30';c.fillRect(x-12,y-45,106,10);c.fillStyle='#8b5f39';c.fillRect(x-5,y-51,92,8);c.fillStyle='#c39a61';c.fillRect(x+2,y-42,75,3);c.fillStyle='#493323';c.fillRect(x+31,y-22,18,22);c.fillStyle='#b58a54';c.fillRect(x+34,y-19,12,19);c.fillStyle='#513a27';c.fillRect(x+9,y-27,13,12);c.fillStyle='#e1c995';c.fillRect(x+12,y-24,7,7);c.fillStyle='#755236';c.fillRect(x+55,y-28,13,25);c.fillStyle='#c49a5c';for(let i=0;i<5;i++)c.fillRect(x+8+i*15,y-35,2,5);c.fillStyle='#62462e';c.fillRect(x+25,y-3,5,5);c.fillRect(x+53,y-3,5,5);
    }else if(t==='carreta'){
      c.fillStyle='#60442c';c.fillRect(x+2,y-25,62,22);c.fillStyle='#b58a50';c.fillRect(x+5,y-23,55,16);c.fillStyle='#d3b171';c.fillRect(x+7,y-21,51,3);c.fillStyle='#8d6339';for(let i=0;i<5;i++)c.fillRect(x+10+i*10,y-18,3,10);c.fillStyle='#62472e';c.fillRect(x+10,y-30,49,5);c.fillRect(x+4,y-32,7,8);c.fillRect(x+57,y-32,7,8);c.fillStyle='#473525';c.fillRect(x+9,y-5,17,17);c.fillRect(x+42,y-5,17,17);c.fillStyle='#c09a60';c.fillRect(x+12,y-2,11,11);c.fillRect(x+45,y-2,11,11);c.fillStyle='#63482e';c.fillRect(x+16,y-1,3,9);c.fillRect(x+13,y+2,9,3);c.fillRect(x+49,y-1,3,9);c.fillRect(x+46,y+2,9,3);c.fillStyle='#62472e';c.fillRect(x+28,y-3,4,8);
    }else if(t==='tienda'){
      c.fillStyle='#63482f';c.fillRect(x+5,y-3,47,4);c.fillStyle='#b6a16d';c.beginPath();c.moveTo(x,y);c.lineTo(x+28,y-42);c.lineTo(x+58,y);c.fill();c.fillStyle='#d0bc82';c.beginPath();c.moveTo(x+7,y-3);c.lineTo(x+28,y-35);c.lineTo(x+49,y-3);c.fill();c.fillStyle='#7a5b3b';c.fillRect(x+26,y-22,5,22);c.fillStyle='#4e3b29';c.fillRect(x+24,y-5,9,5);c.fillStyle='#9b8557';c.fillRect(x+14,y-15,5,7);c.fillRect(x+38,y-15,5,7);
    }else if(t==='fogata'){
      c.fillStyle='#6a4c32';c.fillRect(x,y-3,38,5);c.fillRect(x+3,y-6,31,3);c.fillStyle='#8a5a32';c.fillRect(x+6,y-4,25,3);c.fillStyle='#d87932';c.fillRect(x+11,y-19,14,16);c.fillStyle='#f1b548';c.fillRect(x+14,y-24,8,17);c.fillStyle='#f5d778';c.fillRect(x+17,y-17,4,10);c.fillStyle='#9e5732';c.fillRect(x+5,y-8,4,4);c.fillRect(x+31,y-8,4,4);
    }else if(t==='caballo'){
      c.fillStyle='#4d3928';c.fillRect(x+2,y-27,35,21);c.fillRect(x+25,y-38,11,17);c.fillRect(x+29,y-42,8,8);c.fillRect(x+3,y-29,8,6);c.fillRect(x-4,y-31,8,5);c.fillStyle='#8a6240';c.fillRect(x+5,y-25,27,14);c.fillStyle='#a67b4d';c.fillRect(x+8,y-23,15,7);c.fillStyle='#513a28';c.fillRect(x+8,y-8,5,13);c.fillRect(x+26,y-8,5,13);c.fillRect(x+15,y-8,4,13);c.fillStyle='#30261d';c.fillRect(x+34,y-36,3,3);c.fillStyle='#c5a16b';c.fillRect(x+30,y-29,7,3);c.fillStyle='#3d2c20';c.fillRect(x+22,y-37,4,9);c.fillRect(x-7,y-34,5,7);c.fillStyle='#a78656';c.fillRect(x+7,y-17,16,3);
    }
  }
}
export { NivelCuatroPlataformas };
