/**
 * Inicializa la aplicación y conecta los módulos principales.
 * Es el punto de composición donde se crean servicios y callbacks.
 */

import { GestorAudio } from './audio.js';
import { GestorMenu } from './menu.js';
import { NivelUno } from './nivelUno.js';
import { NivelDos } from './nivelDos.js';
import { NivelCuatroPlataformas } from './nivelCuatroPlataformas.js';
import { NIVEL_JUGABLE, NIVEL_DOS_JUGABLE } from './configuracion.js';
import { alternarPantalla } from './interfaz.js';
import { eliminarPartidaGuardada } from './persistencia.js';

function inicializarAplicacion() {
  const audio = new GestorAudio();
  let nivelActual = NIVEL_JUGABLE;
  let nivelUno = null;
  let nivelDos = null;
  let nivelCuatro = null;
  let menu = null;

  const volverAlMenuTrasNivel = (idPantallaJuego, nivelCompletado) => {
    try { sessionStorage.removeItem('facundo-nivel-en-curso'); } catch (_) {}
    const pantallaJuego = document.getElementById(idPantallaJuego);
    alternarPantalla(pantallaJuego, false);
    audio.detenerHojas();
    menu.mostrarSeleccionTrasCompletar(nivelCompletado);
  };

  const iniciarNivel = (nivelSeleccionado) => {
    nivelActual = Number(nivelSeleccionado);

    // Niveles con instancia jugable integrada.
    if (![NIVEL_JUGABLE, NIVEL_DOS_JUGABLE, 4].includes(nivelActual)) {
      const retroalimentacion = document.getElementById('level-select-feedback');
      retroalimentacion.textContent = `NIVEL ${nivelActual} DESBLOQUEADO · SU INSTANCIA JUGABLE TODAVÍA NO ESTÁ INTEGRADA`;
      return;
    }

    // Ocultar todas las pantallas de navegación antes de mostrar el nivel.
    // Esto también evita que el menú principal quede visible detrás del juego.
    ['start-screen', 'level-select-screen', 'credits-screen', 'settings-screen', 'help-screen', 'game-screen-cuatro']
      .forEach((id) => {
        const pantalla = document.getElementById(id);
        if (pantalla) alternarPantalla(pantalla, false);
      });

    if (nivelActual === NIVEL_JUGABLE) {
      if (!nivelUno) {
        nivelUno = new NivelUno(audio, (nivelCompletado) => {
          volverAlMenuTrasNivel('game-screen', nivelCompletado);
        });
      }
      nivelUno.iniciar();
      document.documentElement.classList.remove('resume-in-progress');
      return;
    }

    if (nivelActual === 4) {
      if (!nivelCuatro) {
        nivelCuatro = new NivelCuatroPlataformas(
          () => volverAlMenuTrasNivel('game-screen-cuatro', 4),
          () => { alternarPantalla(document.getElementById('game-screen-cuatro'), false); menu.mostrarSeleccionNiveles(); }
        );
      }
      alternarPantalla(document.getElementById('game-screen-cuatro'), true);
      document.documentElement.classList.remove('resume-in-progress');
      return;
    }

    if (!nivelDos) {
      nivelDos = new NivelDos(audio, (nivelCompletado) => {
        volverAlMenuTrasNivel('game-screen-dos', nivelCompletado);
      });
    }
    nivelDos.iniciar();
    document.documentElement.classList.remove('resume-in-progress');
  };

  menu = new GestorMenu(audio, iniciarNivel);

  // Menú de pausa compartido: Escape en PC y botón ☰/× en móviles y tabletas.
  const pausa = document.getElementById('game-pause-menu');
  const musicaPausa = document.getElementById('pause-music-volume');
  const sonidosPausa = document.getElementById('pause-sfx-volume');
  const musicaValor = document.getElementById('pause-music-value');
  const sonidosValor = document.getElementById('pause-sfx-value');
  const efectosOn = document.getElementById('pause-effects-on');
  const efectosOff = document.getElementById('pause-effects-off');
  let pausaAbierta = false;
  const nivelVisible = () => {
    const uno = document.getElementById('game-screen');
    const dos = document.getElementById('game-screen-dos');
    const cuatro = document.getElementById('game-screen-cuatro');
    return (uno && !uno.classList.contains('hidden')) || (dos && !dos.classList.contains('hidden')) || (cuatro && !cuatro.classList.contains('hidden'));
  };
  const abrirPausa = () => {
    if (!pausa || !nivelVisible()) return;
    pausaAbierta = true;
    pausa.classList.remove('hidden');
    document.documentElement.classList.add('menu-pausa-abierto');
    document.getElementById('pause-resume')?.focus();
  };
  const cerrarPausa = () => {
    if (!pausa) return;
    pausaAbierta = false;
    pausa.classList.add('hidden');
    document.documentElement.classList.remove('menu-pausa-abierto');
  };
  document.querySelectorAll('.game-pause-trigger').forEach((boton) => boton.addEventListener('click', abrirPausa));
  document.getElementById('game-pause-close')?.addEventListener('click', cerrarPausa);
  document.getElementById('pause-resume')?.addEventListener('click', cerrarPausa);
  document.addEventListener('keydown', (evento) => {
    if (pausaAbierta && evento.key !== 'Escape' && !['Tab','ArrowLeft','ArrowRight','Home','End'].includes(evento.key)) { evento.stopImmediatePropagation(); return; }
    if (evento.key === 'Escape' && nivelVisible()) {
      evento.preventDefault();
      if (pausaAbierta) cerrarPausa(); else abrirPausa();
    }
  });
  document.getElementById('pause-restart-level')?.addEventListener('click', () => {
    if (!nivelVisible()) return;
    const confirmar = window.confirm('¿Querés reiniciar este nivel desde el principio? Se perderá el progreso de la partida actual.');
    if (!confirmar) return;
    cerrarPausa();
    // Borrar el guardado persistente ANTES de iniciar: iniciar() carga el
    // progreso guardado de forma asíncrona y, si no se elimina, restaura
    // inmediatamente las pistas/preguntas que acabamos de reiniciar.
    eliminarPartidaGuardada();
    try {
      sessionStorage.setItem('facundo-nivel-en-curso', String(nivelActual));
      sessionStorage.removeItem('facundo-pantalla-actual');
    } catch (_) {}
    iniciarNivel(nivelActual);
  });

  document.getElementById('pause-level-select')?.addEventListener('click', () => {
    cerrarPausa();
    const nivelUnoVisible = document.getElementById('game-screen');
    const nivelDosVisible = document.getElementById('game-screen-dos');
    const nivelCuatroVisible = document.getElementById('game-screen-cuatro');
    if (nivelUnoVisible) alternarPantalla(nivelUnoVisible, false);
    if (nivelDosVisible) alternarPantalla(nivelDosVisible, false);
    if (nivelCuatroVisible) alternarPantalla(nivelCuatroVisible, false);
    try { sessionStorage.removeItem('facundo-nivel-en-curso'); sessionStorage.setItem('facundo-pantalla-actual', 'seleccion'); } catch (_) {}
    menu.mostrarSeleccionNiveles();
  });
  const actualizarValor = (rango, salida) => { if (rango && salida) salida.value = `${rango.value}%`; };
  if (musicaPausa) {
    musicaPausa.value = String(audio.volumenMusica);
    actualizarValor(musicaPausa, musicaValor);
    musicaPausa.addEventListener('input', () => { audio.establecerVolumenMusica(musicaPausa.value); actualizarValor(musicaPausa, musicaValor); const ajuste = document.getElementById('music-volume'); if (ajuste) ajuste.value = musicaPausa.value; });
  }
  if (sonidosPausa) {
    sonidosPausa.value = String(audio.volumenGeneral);
    actualizarValor(sonidosPausa, sonidosValor);
    sonidosPausa.addEventListener('input', () => { audio.establecerVolumenGeneral(sonidosPausa.value); actualizarValor(sonidosPausa, sonidosValor); const ajuste = document.getElementById('general-volume'); if (ajuste) ajuste.value = sonidosPausa.value; });
  }
  const actualizarBotonesEfectos = () => { efectosOn?.classList.toggle('is-selected', audio.efectosActivados); efectosOff?.classList.toggle('is-selected', !audio.efectosActivados); };
  efectosOn?.addEventListener('click', () => { audio.establecerEfectosActivados(true); actualizarBotonesEfectos(); });
  efectosOff?.addEventListener('click', () => { audio.establecerEfectosActivados(false); actualizarBotonesEfectos(); });
  actualizarBotonesEfectos();

  // Si se recarga la página durante un nivel, volver directamente a ese nivel.
  // El nivel recupera su progreso desde persistencia.js al inicializarse.
  try {
    const pantallaGuardada = sessionStorage.getItem('facundo-pantalla-actual');
    const nivelEnCurso = Number(sessionStorage.getItem('facundo-nivel-en-curso'));
    // La pantalla de navegación guardada tiene prioridad: si el usuario está
    // en selección de niveles y pulsa F5, no debe reabrirse un nivel ni el inicio.
    // Si hay un nivel activo, siempre tiene prioridad sobre la pantalla guardada.
    // Así F5 dentro del Nivel 2 vuelve al Nivel 2, aunque antes se haya pasado por selección.
    if (nivelEnCurso === NIVEL_JUGABLE || nivelEnCurso === NIVEL_DOS_JUGABLE || nivelEnCurso === 4) {
      iniciarNivel(nivelEnCurso);
    } else if (pantallaGuardada === 'seleccion') {
      menu.mostrarSeleccionNiveles();
    }
    // Sin una pantalla guardada en esta sesión, se mantiene el menú principal por defecto.
  } catch (error) {
    // Si el almacenamiento no está disponible, se conserva el menú normal.
  }
}

export { inicializarAplicacion };
