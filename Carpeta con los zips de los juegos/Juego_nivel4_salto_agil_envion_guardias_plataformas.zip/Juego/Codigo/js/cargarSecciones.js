/**
 * Carga los sectores HTML independientes antes de iniciar la lógica del juego.
 * Requiere abrir el proyecto mediante un servidor local (por ejemplo XAMPP).
 */
const SECCIONES = [
  './secciones/menu-principal.html',
  './secciones/ayuda.html',
  './secciones/seleccion-niveles.html',
  './secciones/nivel-uno.html',
  './secciones/nivel-dos.html',
  './secciones/nivel-cuatro-plataformas.html',
  './secciones/pantallas-secundarias.html'
];

async function cargarSecciones() {
  const app = document.getElementById('game-app');
  const indicador = document.getElementById('app-sections-loading');
  let etapa = 'inicio';
  try {
    etapa = 'carga de archivos HTML';
    const fragmentos = await Promise.all(SECCIONES.map(async (ruta) => {
      const respuesta = await fetch(ruta);
      if (!respuesta.ok) throw new Error(`No se pudo cargar ${ruta} (${respuesta.status})`);
      return respuesta.text();
    }));
    indicador?.remove();
    for (const html of fragmentos) app.insertAdjacentHTML('beforeend', html);
    etapa = 'importación de inicializacion.js';
    const { inicializarAplicacion } = await import('./inicializacion.js');
    etapa = 'inicialización de la aplicación';
    inicializarAplicacion();
  } catch (error) {
    console.error(`Error en la etapa «${etapa}» al cargar el juego:`, error);
    if (error?.stack) console.error('Pila completa del error:', error.stack);
    if (indicador) indicador.textContent = 'No se pudieron cargar las secciones. Abrí el juego desde el servidor local de XAMPP y revisá la consola.';
  }
}

cargarSecciones();
