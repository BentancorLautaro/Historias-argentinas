# Estructura modular del HTML

El HTML de cada sector del juego ahora está separado en `secciones/`. Para modificar una pantalla, editá su archivo sin tocar las demás:

- `secciones/menu-principal.html`: menú principal.
- `secciones/seleccion-niveles.html`: tarjetas y selección de niveles.
- `secciones/nivel-uno.html`: interfaz del nivel uno.
- `secciones/nivel-dos.html`: interfaz del nivel dos y sus escenas/minijuegos.
- `secciones/ayuda.html`: instrucciones.
- `secciones/pantallas-secundarias.html`: créditos y configuración.

`index.html` conserva el documento base y `js/cargarSecciones.js` carga las secciones en orden antes de inicializar la lógica. Los módulos JavaScript y estilos existentes se mantienen.

**Importante:** como las secciones se cargan con `fetch`, abrí el proyecto mediante un servidor local (por ejemplo `http://localhost/...` en XAMPP), no haciendo doble clic en `index.html` como `file://`.
