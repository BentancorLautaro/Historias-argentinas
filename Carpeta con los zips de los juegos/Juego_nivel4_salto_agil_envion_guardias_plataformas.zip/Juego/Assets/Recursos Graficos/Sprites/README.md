# Guía de sprites del juego

Guardá en esta carpeta los PNG de los personajes. Los nombres deben coincidir exactamente, incluyendo guiones y extensión `.png`. Usá pixel art, fondo transparente y evitá márgenes transparentes grandes.

## NPC: imagen frontal quieta

Cada NPC necesita una imagen de frente, mirando hacia la cámara. Tamaño recomendado: **64 × 96 px** (también sirve 96 × 128 px si se conserva la proporción).

- `npc-rastreador-frente.png` — Cirilo, el Rastreador.
- `npc-baqueano-frente.png` — Don Eusebio, el Baqueano.
- `npc-gaucho-malo-frente.png` — Gaucho Malo.
- `npc-cantor-frente.png` — el Cantor de la pulpería.
- `npc-dona-jacinta-frente.png` — Doña Jacinta, la pulpera.
- `npc-mateo-arriero-frente.png` — Mateo, el arriero.
- `npc-tomasa-curandera-frente.png` — Tomasa, la curandera.

## Jugador: 12 imágenes

Todos los sprites del jugador deben compartir tamaño y punto de apoyo de los pies. Tamaño recomendado: **64 × 80 px**.

### Quieto (4 direcciones)
- `jugador-frente.png` — mira hacia la pantalla.
- `jugador-espalda.png` — mira hacia el fondo.
- `jugador-izquierda.png` — perfil hacia la izquierda.
- `jugador-derecha.png` — perfil hacia la derecha.

### Caminando (2 cuadros por dirección)
- `jugador-frente-camina-1.png`
- `jugador-frente-camina-2.png`
- `jugador-espalda-camina-1.png`
- `jugador-espalda-camina-2.png`
- `jugador-izquierda-camina-1.png`
- `jugador-izquierda-camina-2.png`
- `jugador-derecha-camina-1.png`
- `jugador-derecha-camina-2.png`

En total son **19 PNG**: 7 de NPC y 12 del jugador. En cada pareja de caminata, alterná piernas y brazos sin cambiar la posición de los pies.

## Archivos de código relacionados

- NPC y rutas de sus imágenes: `Codigo/secciones/nivel-dos.html`.
- Apariencia de los NPC, tamaño y respaldo visual: `Codigo/css/nivelDos.css`.
- Apariencia y animación del jugador: `Codigo/css/nivelDos.css` y los módulos JavaScript de movimiento del nivel 2.
- Mientras no exista un PNG válido, se conserva la silueta o imagen de respaldo que tenga implementada el juego.
