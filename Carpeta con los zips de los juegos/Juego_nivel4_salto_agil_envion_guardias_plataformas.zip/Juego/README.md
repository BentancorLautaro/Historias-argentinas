# El Diario de Facundo — guía del proyecto para personas e IA

## Propósito
Juego educativo narrativo basado en `Assets/Facundo (fuente de informacion para los niveles.pdf`. La meta no es solo completar minijuegos: el jugador debe comparar fuentes, reconocer perspectivas, interpretar testimonios y construir explicaciones usando evidencias.

## Antes de modificar el proyecto
1. Leer este README y `Codigo/README_MODULARIZACION.md`.
2. Revisar el módulo afectado y sus dependencias antes de editar.
3. Conservar el idioma y tono rioplatense de los textos del juego.
4. No eliminar contenido, mecánicas, personajes, controles, audio, persistencia ni estilos para resolver un problema puntual.
5. Evitar reescribir archivos enteros si basta con un cambio localizado.
6. Mantener separados datos narrativos, estado de partida, lógica de minijuegos, interfaz y estilos.
7. Si se agrega una mecánica, documentar su propósito educativo y cómo se conecta con el capítulo.
8. Comprobar sintaxis JS con `node --check`, imports, referencias DOM y ZIP. Probar en navegador cuando sea posible y declarar con honestidad qué pruebas se ejecutaron.
9. No afirmar que algo fue probado visualmente si solo se validó sintaxis.

## Cómo ejecutar
La página carga fragmentos HTML con `fetch`, por lo que no debe abrirse directamente como `file://`. Ejecutar desde un servidor local (por ejemplo XAMPP): copiar la carpeta dentro de `htdocs` y abrir la ruta local correspondiente a `Juego/Codigo/index.html`, ajustándola según dónde se copie el proyecto.

## Estructura principal
```text
Juego/
├── README.md                         # Guía para futuras personas/IA
├── Assets/                           # PDF de referencia, sonidos y gráficos
├── Documentación/                    # Material complementario
└── Codigo/
    ├── index.html                    # Documento base y punto de entrada
    ├── secciones/                    # Fragmentos HTML cargados dinámicamente
    ├── css/                          # Estilos separados por responsabilidad
    ├── js/                            # Módulos ES y lógica del juego
    ├── README_MODULARIZACION.md      # Detalle técnico de la modularización
    ├── README_SPRINT2.md
    └── README_NIVEL_DOS.md
```

## Módulos JavaScript importantes
- `principal.js`: punto de entrada.
- `cargarSecciones.js`: carga los fragmentos HTML antes de iniciar la aplicación.
- `inicializacion.js`: compone servicios, menú y niveles; reanuda el nivel tras recargar.
- `menu.js`, `ajustes.js`, `configuracion.js`: navegación, ajustes y constantes.
- `audio.js`: música, efectos y volúmenes.
- `persistencia.js`: guardado y carga del progreso.
- `estadoJuego.js`, `estadoNivelDos.js`: estado mutable de cada nivel.
- `nivelUno.js`, `nivelDos.js`: orquestadores; coordinan módulos sin concentrar toda la lógica.
- `datosNivelUno.js`, `datosNivelDos.js`: contenido narrativo, preguntas, personajes, grupos y recortes.
- `diarios.js`: lectura de fuentes y recolección de frases clave del capítulo 1.
- `interrogatorio.js`: diálogos y lanzamiento de minijuegos de personajes del capítulo 2.
- `mecanicaRastreador.js`, `mecanicaBaqueano.js`, `mecanicaGauchoMalo.js`, `mecanicaCantor.js`: minijuegos particulares.
- `preguntas.js`: cuestionario reutilizado por ambos capítulos.
- `tablero.js`: relación de recortes/ideas reutilizada por ambos capítulos.
- `introducciones.js`: presentaciones reutilizables de capítulos y minijuegos con callback de continuación.
- `interfaz.js`, `interfazNivelDos.js`: referencias DOM y operaciones visuales simples.
- `mapaMovimiento.js`: movimiento e interacción en el pueblo del capítulo 2.

## Flujo educativo y narrativo
### Capítulo 1 — El diario de Facundo
1. Presentación del capítulo: investigar antes de sacar conclusiones.
2. Lectura de cuatro diarios y marcado de frases clave.
3. Introducción al cuestionario: responder apoyándose en las fuentes.
4. Introducción al tablero: conectar recortes y comparar perspectivas.
5. Cierre con resultados.

### Capítulo 2 — Voces en la Pulpería
1. Presentación del capítulo: reconstruir la historia escuchando y comparando testimonios.
2. Recorrido del pueblo y conversación con personajes.
3. Antes de cada minijuego de personaje, una introducción presenta quién es, por qué su desafío representa su manera de aportar información y qué hay que hacer.
4. Introducción al cuestionario: contrastar las pistas de los testigos.
5. Introducción al tablero: relacionar versiones y evidencias.
6. Cierre con resultados.

Las introducciones deben ser breves y funcionales: explicar **quién**, **por qué esta actividad**, **qué relación tiene con el capítulo** y **qué se espera que aprenda/practique el jugador**. No deben revelar las respuestas del minijuego.

## Convenciones para futuros cambios
- Usar módulos ES (`import` / `export`) y nombres claros en español, salvo convenciones ya establecidas.
- Preferir funciones y clases con una responsabilidad definida.
- Pasar dependencias mediante el constructor y comunicar el avance con callbacks, evitando dependencias circulares.
- Mantener el contenido en `datosNivel*.js`; la lógica de interacción en el gestor correspondiente; la presentación en `secciones/` y `css/`.
- Agregar introducciones mediante `mostrarIntroduccion({...})`; no duplicar modales ni CSS por minijuego.
- Conservar accesibilidad básica: etiquetas, `role="dialog"`, `aria-modal`, foco visible y botones semánticos.
- Conservar autoguardado y claves de `localStorage` salvo que exista una razón explícita para migrarlas.
- No cambiar mecánicas educativas solo para simplificar el código; documentar cualquier cambio de reglas.

## Prompt de referencia para una IA
> Antes de editar, leé `Juego/README.md`, `Juego/Codigo/README_MODULARIZACION.md` y los módulos relacionados. Explicá brevemente qué archivos intervienen y qué comportamiento existente podría verse afectado. Implementá solo el cambio solicitado, respetando modularización, contenido educativo, persistencia, accesibilidad y estilo rioplatense. No elimines funciones no relacionadas. Al terminar, ejecutá comprobaciones de sintaxis/imports y describí exactamente qué validaste; no afirmes haber probado en navegador si no lo hiciste.

## Sprites de personajes (Nivel 2)

Los PNG se colocan en `Assets/Recursos Graficos/Sprites/`. Los nombres y tamaños recomendados están en `Assets/Recursos Graficos/Sprites/README.md`. Para NPC, editar las rutas de las imágenes en `Codigo/secciones/nivel-dos.html`; para sprites del jugador y animación por dirección, editar `Codigo/css/nivelDos.css`.
