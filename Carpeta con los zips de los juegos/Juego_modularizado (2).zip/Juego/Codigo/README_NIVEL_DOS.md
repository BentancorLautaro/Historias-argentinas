# Nivel 2 — Voces en la Pulpería

Se incorporó la instancia jugable del Nivel 2 sin modificar la lógica interna
del Nivel 1. Se reutilizaron los módulos genéricos ya existentes
(`GestorPreguntas` y `GestorTablero`) y se agregó un nuevo módulo,
`GestorInterrogatorio`, que coordina el interrogatorio de los cuatro
personajes.

## Personajes y mecánicas

Los cuatro personajes interrogables corresponden a los cuatro tipos
populares que Sarmiento describe en el Capítulo II de *Facundo*, y **cada
uno usa una mecánica de juego distinta** para entregar sus tres pistas:

| Personaje | Mecánica | Cómo se juega |
| --- | --- | --- |
| **El Rastreador** | Secuencia ordenada | Las huellas aparecen mezcladas visualmente; hay que tocarlas en el orden correcto (de la más vieja a la más nueva) siguiendo las pistas descriptivas de cada una. |
| **El Baqueano** | Bifurcaciones sucesivas | Se presentan tres encrucijadas, una por vez; en cada una hay que elegir el camino correcto para avanzar a la siguiente. |
| **El Gaucho Malo** | Elegir el tono correcto | Cada pregunta ofrece tres formas de hacerla (respetuosa, firme o amenazante); solo una desbloquea la pista real, las otras dan respuestas evasivas. |
| **El Cantor** | Completar el verso | Cada verso tiene un espacio en blanco con tres palabras para elegir; solo una completa correctamente el dato histórico. |

`GestorInterrogatorio` no conoce los detalles de ninguna mecánica: según el
campo `personaje.tipoMecanica`, instancia la clase correspondiente
(`MecanicaRastreador`, `MecanicaBaqueano`, `MecanicaGauchoMalo` o
`MecanicaCantor`) y escucha su callback `onPista` para sumar el progreso,
exactamente igual sin importar cuál mecánica lo generó.

## Flujo

1. El jugador entra a la pulpería y ve a los cuatro personajes.
2. Al hacer clic en un personaje, **la pulpería desaparece por completo**
   y se abre una pantalla propia para ese personaje: un minijuego con su
   propia ambientación (fondo, iluminación, animaciones), sin ningún
   elemento visual de la pulpería de fondo.
3. Resuelve la mecánica para recolectar sus tres pistas. Al reunir las
   tres, el personaje queda marcado como interrogado.
4. Con el botón "VOLVER A LA PULPERÍA" cierra ese minijuego y regresa a
   la escena de selección de personajes.
5. Al interrogar a los cuatro personajes, se abre un cuestionario de
   verificación (igual mecánica que el Nivel 1, vía `GestorPreguntas`).
6. Luego se abre el tablero de versiones con 12 recortes mezclados
   (las 12 pistas recolectadas), vía `GestorTablero`.
7. El jugador debe relacionar los recortes de a tríadas; cada tríada
   corresponde a las tres pistas de un mismo personaje.
8. Al resolver las cuatro tríadas termina la instancia jugable.

## Las cuatro escenas de pantalla completa

Cada personaje ya no vive dentro de un modal sobre el escenario de la
pulpería: tiene su propia sección `<section class="screen escena-mecanica">`,
del mismo nivel jerárquico que las demás pantallas del juego (inicio,
niveles, créditos, etc.), con una ambientación completamente distinta,
armada con CSS y SVG propios (sin depender de imágenes externas ni de un
generador de IA, que no está disponible como herramienta en este entorno):

- **El Rastreador** — pampa al atardecer: cielo en degradé cálido, sol
  con resplandor, lomas superpuestas y pastizal en primer plano.
- **El Baqueano** — mapa nocturno: cielo estrellado animado (centelleo),
  luna con halo de luz y una textura de curvas de nivel de fondo.
- **El Gaucho Malo** — fogata en la oscuridad: viñeta oscura, llamas
  animadas, brasas que suben, y la silueta del personaje recortada en
  primer plano.
- **El Cantor** — noche cálida junto al fuego: fogata más chica, silueta
  de guitarra y notas musicales que flotan y se disuelven hacia arriba.

`GestorInterrogatorio` no dibuja nada de esto directamente: al elegir un
personaje, oculta la pulpería y muestra la escena que corresponde según
`personaje.tipoMecanica` (usando el mismo `alternarPantalla` que usa el
resto de la navegación del juego), monta ahí la mecánica y, al volver,
hace el camino inverso.

## Archivos nuevos

| Archivo | Responsabilidad |
| --- | --- |
| `js/datosNivelDos.js` | Contenido: personajes (con su `tipoMecanica` y `datosMecanica`), cuestionario final y grupos del tablero. |
| `js/estadoNivelDos.js` | Estado mutable de una partida del Nivel 2. |
| `js/interfazNivelDos.js` | Acceso centralizado al DOM del Nivel 2. |
| `js/interrogatorio.js` | Gestor que elige e inicializa la mecánica de cada personaje. |
| `js/mecanicaRastreador.js` | Mecánica de secuencia ordenada (huellas). |
| `js/mecanicaBaqueano.js` | Mecánica de bifurcaciones sucesivas (caminos). |
| `js/mecanicaGauchoMalo.js` | Mecánica de elegir el tono correcto (diálogo). |
| `js/mecanicaCantor.js` | Mecánica de completar el verso (payada). |
| `js/nivelDos.js` | Orquestador que conecta interrogatorio, cuestionario y tablero. |
| `css/nivelDos.css` | Estilos de la pulpería, los personajes, las cuatro mecánicas y las cuatro escenas de pantalla completa (fondos, luces, animaciones). |

## Archivos modificados en esta vuelta

- `index.html`: se quitó el modal único de diálogo (`#dialogo-modal`) y se
  agregaron las cuatro secciones `<section class="screen escena-mecanica">`
  de pantalla completa.
- `interfazNivelDos.js`: en vez de un solo conjunto de elementos de diálogo,
  expone `escenasMecanica`, con la raíz, el contenedor, el progreso y el
  botón de volver de cada una de las cuatro escenas.
- `interrogatorio.js`: `abrirPersonaje` ahora alterna pantallas completas
  (pulpería ↔ escena del personaje) en vez de mostrar/ocultar un modal.

## Archivos modificados (mínimo necesario)

- `js/configuracion.js`: se agregó la constante `NIVEL_DOS_JUGABLE`.
- `js/inicializacion.js`: ahora instancia `NivelUno` o `NivelDos` según el
  nivel elegido, sin alterar el flujo existente del Nivel 1.
- `index.html`: se agregó la sección `#game-screen-dos` con la escena, el
  modal de diálogo y los modales de cuestionario/tablero/nivel completado
  propios del Nivel 2 (mismos ids que el Nivel 1 mas el sufijo `-dos`).
- `css/estilos.css`: se agregó el `@import` de `nivelDos.css`.

Los módulos `preguntas.js` y `tablero.js` **no se modificaron**: ya eran
genéricos (reciben sus elementos del DOM y sus datos por parámetro), por lo
que se reutilizan tal cual para el Nivel 2.
