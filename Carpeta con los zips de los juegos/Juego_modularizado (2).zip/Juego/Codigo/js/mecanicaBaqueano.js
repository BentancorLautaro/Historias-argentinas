/**
 * Mecánica del Baqueano: elegir el camino correcto en encrucijadas sucesivas.
 * A diferencia del Rastreador (huellas dispersas sobre un terreno), acá se
 * dibuja un diagrama de bifurcación: una línea sale de un punto de partida
 * y se abre en dos ramas, cada una con un ícono propio que representa la
 * opción (sol, monte, pala, hoja, luna, brújula) en vez de texto largo.
 * Se presentan tres bifurcaciones, una por vez; si el jugador elige mal
 * puede reintentar esa misma bifurcación.
 */

// Íconos propios en SVG para cada opción posible de las bifurcaciones.
// Son dibujos simples y genéricos (no representan marcas ni personajes reales).
const ICONOS = {
  sol: `
    <svg viewBox="0 0 40 40" class="bifurcacion-svg" aria-hidden="true">
      <circle cx="20" cy="20" r="9" />
      <g stroke-width="3" stroke-linecap="round">
        <line x1="20" y1="2" x2="20" y2="8" />
        <line x1="20" y1="32" x2="20" y2="38" />
        <line x1="2" y1="20" x2="8" y2="20" />
        <line x1="32" y1="20" x2="38" y2="20" />
        <line x1="7" y1="7" x2="11" y2="11" />
        <line x1="29" y1="29" x2="33" y2="33" />
        <line x1="33" y1="7" x2="29" y2="11" />
        <line x1="11" y1="29" x2="7" y2="33" />
      </g>
    </svg>
  `,
  monte: `
    <svg viewBox="0 0 40 40" class="bifurcacion-svg" aria-hidden="true">
      <circle cx="12" cy="16" r="8" />
      <circle cx="22" cy="10" r="10" />
      <circle cx="30" cy="18" r="7" />
      <rect x="18" y="26" width="4" height="12" />
    </svg>
  `,
  pala: `
    <svg viewBox="0 0 40 40" class="bifurcacion-svg" aria-hidden="true">
      <line x1="14" y1="6" x2="30" y2="22" stroke-width="4" stroke-linecap="round" />
      <path d="M25 24 L36 30 L30 36 L22 28 Z" />
    </svg>
  `,
  hoja: `
    <svg viewBox="0 0 40 40" class="bifurcacion-svg" aria-hidden="true">
      <path d="M8 32 C8 12 32 8 34 6 C32 24 24 34 8 32 Z" />
      <line x1="10" y1="30" x2="30" y2="10" stroke-width="2" />
    </svg>
  `,
  luna: `
    <svg viewBox="0 0 40 40" class="bifurcacion-svg" aria-hidden="true">
      <path d="M26 4 A16 16 0 1 0 26 36 A13 13 0 0 1 26 4 Z" />
    </svg>
  `,
  brujula: `
    <svg viewBox="0 0 40 40" class="bifurcacion-svg" aria-hidden="true">
      <circle cx="20" cy="20" r="16" fill="none" stroke-width="3" />
      <path d="M20 9 L24 20 L20 31 L16 20 Z" />
    </svg>
  `
};

class MecanicaBaqueano {
  constructor({ contenedor, datos, audio, onPista }) {
    this.contenedor = contenedor;
    this.bifurcaciones = datos.bifurcaciones;
    this.audio = audio;
    this.onPista = onPista;
    this.actual = 0;
  }

  /** Cantidad total de pistas que entrega esta mecánica. */
  obtenerTotalPistas() {
    return this.bifurcaciones.length;
  }

  /** Punto de entrada: dibuja la primera bifurcación pendiente. */
  render() {
    this.actual = 0;
    this.renderizarBifurcacionActual();
  }

  /** Dibuja el diagrama de la bifurcación en curso, con sus dos ramas e íconos. */
  renderizarBifurcacionActual() {
    if (this.actual >= this.bifurcaciones.length) return;

    const bifurcacion = this.bifurcaciones[this.actual];

    this.contenedor.innerHTML = `
      <p class="mecanica-instruccion">ENCRUCIJADA ${this.actual + 1} / ${this.bifurcaciones.length} · ${bifurcacion.pregunta}</p>
      <div class="bifurcacion-diagrama">
        <svg viewBox="0 0 200 120" class="bifurcacion-ramas" aria-hidden="true">
          <path d="M100 110 L100 70 L35 20" fill="none" stroke-width="4" />
          <path d="M100 70 L165 20" fill="none" stroke-width="4" />
          <circle cx="100" cy="110" r="6" />
        </svg>
        <button type="button" class="bifurcacion-nodo bifurcacion-nodo-izq" data-indice="0">
          ${ICONOS[bifurcacion.opciones[0].icono]}
          <span class="bifurcacion-etiqueta">${bifurcacion.opciones[0].texto}</span>
        </button>
        <button type="button" class="bifurcacion-nodo bifurcacion-nodo-der" data-indice="1">
          ${ICONOS[bifurcacion.opciones[1].icono]}
          <span class="bifurcacion-etiqueta">${bifurcacion.opciones[1].texto}</span>
        </button>
      </div>
      <div class="bifurcacion-respuesta hidden"></div>
    `;

    this.contenedor.querySelectorAll('.bifurcacion-nodo').forEach((boton) => {
      boton.addEventListener('mouseenter', () => this.audio.reproducirHover());
      boton.addEventListener('click', () => this.elegirCamino(Number(boton.dataset.indice), boton));
    });
  }

  /** Resuelve la elección del jugador para la bifurcación actual. */
  elegirCamino(indiceOpcion, boton) {
    const bifurcacion = this.bifurcaciones[this.actual];
    const opcion = bifurcacion.opciones[indiceOpcion];
    const respuestaDiv = this.contenedor.querySelector('.bifurcacion-respuesta');

    respuestaDiv.textContent = opcion.respuesta;
    respuestaDiv.classList.remove('hidden');
    this.contenedor.querySelectorAll('.bifurcacion-nodo').forEach((b) => { b.disabled = true; });

    if (opcion.correcta) {
      boton.classList.add('bifurcacion-correcta');
      this.audio.reproducirClick();
      this.onPista(this.actual, bifurcacion.pista);
      this.actual += 1;
      setTimeout(() => this.renderizarBifurcacionActual(), 900);
      return;
    }

    boton.classList.add('bifurcacion-incorrecta');
    setTimeout(() => {
      this.contenedor.querySelectorAll('.bifurcacion-nodo').forEach((b) => {
        b.disabled = false;
        b.classList.remove('bifurcacion-incorrecta');
      });
      respuestaDiv.classList.add('hidden');
    }, 900);
  }
}

export { MecanicaBaqueano };
