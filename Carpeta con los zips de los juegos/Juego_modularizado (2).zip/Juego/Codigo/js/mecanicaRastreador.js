/**
 * Mecánica del Rastreador: seguir un rastro leyendo huellas dibujadas.
 * Las huellas se dibujan como ícono SVG (sin texto) desperdigadas sobre un
 * "terreno", y se diferencian entre sí solo por lo marcadas que están:
 * la más vieja aparece tenue y borrosa, la más nueva aparece nítida y
 * profunda. El jugador debe tocarlas en su orden real (de la más vieja a
 * la más nueva) para ir revelando, una por una, las pistas que guarda cada
 * huella.
 */

// Ícono de huella reutilizado para las tres, dibujado en SVG propio
// (sin depender de imágenes externas). El grado de "marca" se logra
// después con opacidad, desenfoque y sombra vía CSS, no con un dibujo distinto.
const SVG_HUELLA = `
  <svg viewBox="0 0 60 90" class="huella-svg" aria-hidden="true">
    <ellipse cx="30" cy="58" rx="17" ry="26" />
    <ellipse cx="22" cy="14" rx="6" ry="8" />
    <ellipse cx="34" cy="10" rx="6.5" ry="9" />
    <ellipse cx="46" cy="15" rx="5.5" ry="7.5" />
    <ellipse cx="12" cy="24" rx="5" ry="7" />
    <ellipse cx="52" cy="26" rx="4.5" ry="6.5" />
  </svg>
`;

// Posiciones fijas donde puede caer cada huella dentro del terreno; se
// reparten al azar entre las tres huellas en cada partida para que no
// siempre estén en el mismo lugar.
const POSICIONES_TERRENO = [
  { left: '12%', top: '18%' },
  { left: '46%', top: '52%' },
  { left: '76%', top: '12%' }
];

class MecanicaRastreador {
  constructor({ contenedor, datos, audio, onPista }) {
    this.contenedor = contenedor;
    this.instruccion = datos.instruccion;
    this.huellas = datos.huellas;
    this.audio = audio;
    this.onPista = onPista;
    this.siguienteEsperada = 0;
  }

  /** Cantidad total de pistas que entrega esta mecánica. */
  obtenerTotalPistas() {
    return this.huellas.length;
  }

  /** Dibuja la instrucción y las huellas, cada una en una posición al azar. */
  render() {
    this.siguienteEsperada = 0;

    const posiciones = [...POSICIONES_TERRENO].sort(() => Math.random() - 0.5);

    this.contenedor.innerHTML = `
      <p class="mecanica-instruccion">${this.instruccion}</p>
      <div class="huellas-terreno">
        ${this.huellas.map((huella, indice) => `
          <button
            type="button"
            class="huella-boton huella-edad-${indice}"
            data-indice="${indice}"
            style="left:${posiciones[indice].left}; top:${posiciones[indice].top};"
            aria-label="${huella.etiqueta}"
          >${SVG_HUELLA}</button>
        `).join('')}
      </div>
    `;

    this.contenedor.querySelectorAll('.huella-boton').forEach((boton) => {
      boton.addEventListener('mouseenter', () => this.audio.reproducirHover());
      boton.addEventListener('click', () => this.tocarHuella(Number(boton.dataset.indice), boton));
    });
  }

  /** Valida si la huella tocada es la que sigue en la secuencia correcta. */
  tocarHuella(indice, boton) {
    if (boton.disabled) return;

    if (indice === this.siguienteEsperada) {
      boton.disabled = true;
      boton.classList.add('huella-correcta');
      this.audio.reproducirClick();
      this.onPista(indice, this.huellas[indice].pista);
      this.siguienteEsperada += 1;
      return;
    }

    // Orden equivocado: se sacude en rojo y no se pierde el progreso ya hecho.
    boton.classList.add('huella-incorrecta');
    setTimeout(() => boton.classList.remove('huella-incorrecta'), 400);
  }
}

export { MecanicaRastreador };
