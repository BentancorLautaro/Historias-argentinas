/**
 * Mecánica del Gaucho Malo: encontrar el tono correcto para cada pregunta.
 * Cada pregunta ofrece tres formas de hacerla (tonos). Solo una desbloquea
 * la pista real; las otras dos devuelven una respuesta evasiva y pueden
 * reintentarse.
 */

class MecanicaGauchoMalo {
  constructor({ contenedor, datos, audio, onPista }) {
    this.contenedor = contenedor;
    this.preguntas = datos.preguntas;
    this.audio = audio;
    this.onPista = onPista;
    this.resueltas = new Set();
  }

  /** Cantidad total de pistas que entrega esta mecánica. */
  obtenerTotalPistas() {
    return this.preguntas.length;
  }

  /** Dibuja las tres preguntas junto con sus opciones de tono. */
  render() {
    this.resueltas.clear();

    this.contenedor.innerHTML = this.preguntas.map((pregunta, indicePregunta) => `
      <div class="tono-item" data-index="${indicePregunta}">
        <div class="tono-pregunta">${pregunta.pregunta}</div>
        <div class="tono-opciones">
          ${pregunta.tonos.map((tono, indiceTono) => `
            <button type="button" class="tono-boton" data-pregunta="${indicePregunta}" data-tono="${indiceTono}">${tono.texto}</button>
          `).join('')}
        </div>
        <div class="tono-respuesta hidden" data-respuesta="${indicePregunta}"></div>
      </div>
    `).join('');

    this.contenedor.querySelectorAll('.tono-boton').forEach((boton) => {
      boton.addEventListener('mouseenter', () => this.audio.reproducirHover());
      boton.addEventListener('click', () => this.elegirTono(
        Number(boton.dataset.pregunta),
        Number(boton.dataset.tono),
        boton
      ));
    });
  }

  /** Evalúa el tono elegido para una pregunta puntual. */
  elegirTono(indicePregunta, indiceTono, boton) {
    if (this.resueltas.has(indicePregunta)) return;

    const pregunta = this.preguntas[indicePregunta];
    const tono = pregunta.tonos[indiceTono];
    const respuestaDiv = this.contenedor.querySelector(`.tono-respuesta[data-respuesta="${indicePregunta}"]`);

    respuestaDiv.textContent = tono.respuesta;
    respuestaDiv.classList.remove('hidden');

    if (tono.correcta) {
      this.resueltas.add(indicePregunta);
      this.contenedor
        .querySelectorAll(`.tono-boton[data-pregunta="${indicePregunta}"]`)
        .forEach((b) => { b.disabled = true; });
      boton.classList.add('tono-correcto');
      this.audio.reproducirClick();
      this.onPista(indicePregunta, pregunta.pista);
      return;
    }

    boton.classList.add('tono-incorrecto');
    setTimeout(() => boton.classList.remove('tono-incorrecto'), 500);
  }
}

export { MecanicaGauchoMalo };
