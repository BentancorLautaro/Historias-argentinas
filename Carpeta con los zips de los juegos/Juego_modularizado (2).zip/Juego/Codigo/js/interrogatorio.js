/**
 * Gestiona la mecánica de interrogatorio del Nivel 2.
 * Su responsabilidad termina cuando los cuatro personajes fueron
 * interrogados por completo, igual que GestorDiarios termina cuando se
 * recolectan los cuatro diarios del Nivel 1.
 *
 * A diferencia del Nivel 1, cada personaje no abre un modal dentro del
 * mismo escenario: lleva a una pantalla completa propia, con su propia
 * ambientación, donde se juega una mecánica distinta (secuencia,
 * bifurcaciones, tono o versos). Este gestor no conoce los detalles de
 * cada mecánica: solo decide qué clase instanciar según
 * personaje.tipoMecanica y en qué escena montarla, y escucha su callback
 * onPista.
 */

import { alternarPantalla, establecerTexto } from './interfaz.js';
import { MecanicaRastreador } from './mecanicaRastreador.js';
import { MecanicaBaqueano } from './mecanicaBaqueano.js';
import { MecanicaGauchoMalo } from './mecanicaGauchoMalo.js';
import { MecanicaCantor } from './mecanicaCantor.js';

// Relaciona cada "tipoMecanica" de datosNivelDos.js con su clase de mecánica.
const CLASES_POR_TIPO_MECANICA = {
  rastreador: MecanicaRastreador,
  baqueano: MecanicaBaqueano,
  gauchoMalo: MecanicaGauchoMalo,
  cantor: MecanicaCantor
};

class GestorInterrogatorio {
  constructor({ elementos, estado, personajes, audio, alCompletarTodos }) {
    this.elementos = elementos;
    this.estado = estado;
    this.personajes = personajes;
    this.audio = audio;
    this.alCompletarTodos = alCompletarTodos;
    this.mecanicaActual = null;
    this.escenaActual = null;
  }

  /** Conecta los eventos de clic/hover de los personajes y el botón de volver de cada escena. */
  inicializarEventos() {
    document.querySelectorAll('.personaje').forEach((boton) => {
      boton.addEventListener('click', () => this.abrirPersonaje(Number(boton.dataset.personaje)));
      boton.addEventListener('mouseenter', () => this.audio.reproducirHover());
    });

    Object.values(this.elementos.escenasMecanica).forEach((escena) => {
      escena.botonVolver.addEventListener('click', () => this.volverALaPulperia());
    });
  }

  /** Prepara el estado inicial de la escena y muestra la pista de interacción. */
  iniciar() {
    this.estado.pistasActuales.clear();
    this.actualizarProgreso();
    establecerTexto(this.elementos.pistaInteraccion, 'HACÉ CLIC EN UN PERSONAJE PARA INTERROGARLO');
  }

  /** Deja la pulpería y lleva al minijuego de pantalla completa del personaje elegido. */
  abrirPersonaje(indice) {
    if (this.estado.personajesInterrogados.has(indice)) return;

    this.estado.personajeActual = indice;
    this.estado.pistasActuales.clear();

    const personaje = this.personajes[indice];
    this.escenaActual = this.elementos.escenasMecanica[personaje.tipoMecanica];

    alternarPantalla(this.elementos.juegoPantalla, false);
    this.iniciarMecanica(personaje);
    alternarPantalla(this.escenaActual.raiz, true);
  }

  /** Instancia la mecánica de juego propia de este personaje y la dibuja en su escena. */
  iniciarMecanica(personaje) {
    const ClaseMecanica = CLASES_POR_TIPO_MECANICA[personaje.tipoMecanica];

    this.mecanicaActual = new ClaseMecanica({
      contenedor: this.escenaActual.contenedor,
      datos: personaje.datosMecanica,
      audio: this.audio,
      onPista: (indicePista) => this.recolectarPista(indicePista)
    });

    establecerTexto(this.escenaActual.progreso, `0 / ${this.mecanicaActual.obtenerTotalPistas()} PISTAS`);
    this.escenaActual.progreso.classList.remove('complete');
    this.mecanicaActual.render();
  }

  /** Suma una pista al progreso del personaje actual, sin importar qué mecánica la generó. */
  recolectarPista(indice) {
    if (this.estado.pistasActuales.has(indice)) return;

    this.estado.pistasActuales.add(indice);

    const total = this.mecanicaActual.obtenerTotalPistas();
    const actual = this.estado.pistasActuales.size;

    establecerTexto(this.escenaActual.progreso, `${actual} / ${total} PISTAS`);

    if (actual === total) {
      this.escenaActual.progreso.classList.add('complete');
      // Se marca automáticamente al personaje como interrogado al reunir sus pistas.
      this.recolectarPersonaje();
    }
  }

  /** Marca al personaje actual como completamente interrogado. */
  recolectarPersonaje() {
    const total = this.mecanicaActual.obtenerTotalPistas();
    if (this.estado.pistasActuales.size !== total) return;
    if (this.estado.personajesInterrogados.has(this.estado.personajeActual)) return;

    this.estado.personajesInterrogados.add(this.estado.personajeActual);
    document
      .querySelector(`.personaje[data-personaje="${this.estado.personajeActual}"]`)
      ?.classList.add('interrogado');

    this.actualizarProgreso();
    this.audio.reproducirClick();
  }

  /** Actualiza el contador y la barra de progreso de personajes interrogados. */
  actualizarProgreso() {
    const total = this.personajes.length;
    const actual = this.estado.personajesInterrogados.size;
    establecerTexto(this.elementos.progresoPersonajes, `${actual} / ${total} PERSONAJES INTERROGADOS`);
    this.elementos.barraPersonajes.style.width = `${(actual / total) * 100}%`;
  }

  /** Cierra el minijuego actual, vuelve a la pulpería y avanza al cuestionario si ya no falta nadie. */
  volverALaPulperia() {
    if (this.escenaActual) alternarPantalla(this.escenaActual.raiz, false);
    this.escenaActual = null;
    this.mecanicaActual = null;
    alternarPantalla(this.elementos.juegoPantalla, true);
    this.audio.reproducirClick();

    if (this.estado.personajesInterrogados.size === this.personajes.length) {
      this.alCompletarTodos();
    }
  }
}

export { GestorInterrogatorio };
