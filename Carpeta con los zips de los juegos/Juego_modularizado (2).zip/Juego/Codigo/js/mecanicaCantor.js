/**
 * Mecánica del Cantor: completar el verso correcto (estilo payada).
 * Cada verso tiene un espacio en blanco y tres opciones para completarlo;
 * elegir la opción correcta revela la pista asociada a ese verso.
 */

class MecanicaCantor {
  constructor({ contenedor, datos, audio, onPista }) {
    this.contenedor = contenedor;
    this.versos = datos.versos;
    this.audio = audio;
    this.onPista = onPista;
    this.resueltos = new Set();
  }

  /** Cantidad total de pistas que entrega esta mecánica. */
  obtenerTotalPistas() {
    return this.versos.length;
  }

  /** Dibuja los tres versos con su espacio en blanco y sus opciones. */
  render() {
    this.resueltos.clear();

    this.contenedor.innerHTML = this.versos.map((verso, indiceVerso) => `
      <div class="verso-item" data-index="${indiceVerso}">
        <div class="verso-texto">${verso.texto.replace('___', '<span class="verso-hueco">___</span>')}</div>
        <div class="verso-opciones">
          ${verso.opciones.map((opcion, indiceOpcion) => `
            <button type="button" class="verso-boton" data-verso="${indiceVerso}" data-opcion="${indiceOpcion}">${opcion}</button>
          `).join('')}
        </div>
        <div class="verso-respuesta hidden" data-respuesta="${indiceVerso}"></div>
      </div>
    `).join('');

    this.contenedor.querySelectorAll('.verso-boton').forEach((boton) => {
      boton.addEventListener('mouseenter', () => this.audio.reproducirHover());
      boton.addEventListener('click', () => this.elegirPalabra(
        Number(boton.dataset.verso),
        Number(boton.dataset.opcion),
        boton
      ));
    });
  }

  /** Evalúa la palabra elegida para completar un verso puntual. */
  elegirPalabra(indiceVerso, indiceOpcion, boton) {
    if (this.resueltos.has(indiceVerso)) return;

    const verso = this.versos[indiceVerso];
    const respuestaDiv = this.contenedor.querySelector(`.verso-respuesta[data-respuesta="${indiceVerso}"]`);

    if (indiceOpcion === verso.correcta) {
      this.resueltos.add(indiceVerso);
      this.contenedor
        .querySelectorAll(`.verso-boton[data-verso="${indiceVerso}"]`)
        .forEach((b) => { b.disabled = true; });
      boton.classList.add('verso-correcto');
      respuestaDiv.textContent = verso.pista;
      respuestaDiv.classList.remove('hidden');
      this.audio.reproducirClick();
      this.onPista(indiceVerso, verso.pista);
      return;
    }

    boton.classList.add('verso-incorrecto');
    setTimeout(() => boton.classList.remove('verso-incorrecto'), 500);
  }
}

export { MecanicaCantor };
