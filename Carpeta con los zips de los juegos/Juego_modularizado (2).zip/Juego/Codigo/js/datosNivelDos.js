/**
 * Contenido didáctico del Nivel 2 · "Voces en la Pulpería".
 * Mantiene los textos, preguntas y relaciones separados de la lógica del nivel,
 * siguiendo el mismo criterio de organización que datosNivelUno.js.
 *
 * A diferencia del Nivel 1, acá cada personaje usa una mecánica distinta para
 * entregar sus tres pistas. El campo "tipoMecanica" le indica a
 * GestorInterrogatorio qué módulo de mecánica debe instanciar, y el campo
 * "datosMecanica" trae la información propia de esa mecánica.
 */

const personajesNivelDos = [
  {
    id: 'rastreador',
    nombre: 'EL RASTREADOR',
    apodo: 'Cirilo, rastreador de los Llanos',
    retrato: 'retrato-rastreador',
    presentacion:
      'Sigue huellas desde antes de que nadie más las note. No cuenta la historia de corrido: hay que leerla en el orden en que quedó marcada en el suelo.',
    tipoMecanica: 'rastreador',
    datosMecanica: {
      instruccion:
        'El rastro se marca con el paso del tiempo. Tocá las huellas en orden, de la más vieja (tenue y borrosa) a la más nueva (marcada y profunda).',
      huellas: [
        {
          etiqueta: 'Huella borrosa, casi borrada por el viento',
          pista: 'Antes de ser caudillo, Facundo fue un simple recluta del ejército en Buenos Aires'
        },
        {
          etiqueta: 'Huella parcialmente marcada, se nota un paso reciente',
          pista: 'Desertó y volvió a los Llanos, donde empezó a hacerse temer entre los gauchos'
        },
        {
          etiqueta: 'Huella fresca y profunda, recién dejada',
          pista: 'Terminó reuniendo bajo su mando a buena parte de los Llanos de la Rioja'
        }
      ]
    }
  },
  {
    id: 'baqueano',
    nombre: 'EL BAQUEANO',
    apodo: 'Don Eusebio, baqueano de la Rioja',
    retrato: 'retrato-baqueano',
    presentacion:
      'Conoce cada legua de los Llanos como la palma de su mano. Para sacarle una pista hay que resolver, como él, el camino correcto en cada encrucijada.',
    tipoMecanica: 'baqueano',
    datosMecanica: {
      bifurcaciones: [
        {
          pregunta: 'Facundo necesita cruzar los Llanos sin que sus enemigos lo vean. ¿Qué camino conviene tomar?',
          opciones: [
            { texto: 'Camino abierto', icono: 'sol', correcta: false, respuesta: 'Ese camino los hubiera dejado expuestos; no es lo que hizo un baqueano.' },
            { texto: 'Camino del monte', icono: 'monte', correcta: true, respuesta: 'Así es: Facundo aprovechaba el monte para moverse sin ser visto.' }
          ],
          pista: 'Facundo usaba caminos ocultos para moverse sin ser detectado por sus enemigos'
        },
        {
          pregunta: 'Sus tropas necesitan agua después de dos días de marcha. ¿Cómo la encuentra un baqueano en el desierto?',
          opciones: [
            { texto: 'Cavar al azar', icono: 'pala', correcta: false, respuesta: 'Así se pierde tiempo y agua; no es el método real.' },
            { texto: 'Leer la vegetación', icono: 'hoja', correcta: true, respuesta: 'Correcto: la vegetación y el suelo indican dónde hay agua cercana.' }
          ],
          pista: 'Un baqueano reconoce el agua oculta por la vegetación y el tipo de suelo'
        },
        {
          pregunta: 'Una tropa enemiga se acerca de noche. ¿Cómo se orienta un baqueano sin luz?',
          opciones: [
            { texto: 'Esperar el sol', icono: 'luna', correcta: false, respuesta: 'Eso hubiera significado perder toda ventaja.' },
            { texto: 'Leer el terreno', icono: 'brujula', correcta: true, respuesta: 'Exacto: de noche, el tacto y el conocimiento del terreno reemplazan a la vista.' }
          ],
          pista: 'De noche, el baqueano se orientaba por los árboles y la inclinación del terreno'
        }
      ]
    }
  },
  {
    id: 'gaucho-malo',
    nombre: 'EL GAUCHO MALO',
    apodo: 'El Chileno, un proscrito que lo conoció',
    retrato: 'retrato-gaucho-malo',
    presentacion:
      'Vive al margen de los pueblos y desconfía de cualquiera. No alcanza con preguntarle: hay que encontrar el tono justo, o solo vas a conseguir evasivas.',
    tipoMecanica: 'gauchoMalo',
    datosMecanica: {
      preguntas: [
        {
          pregunta: '¿Facundo alguna vez te pidió ayuda a vos?',
          tonos: [
            { texto: 'Preguntar con respeto', correcta: false, respuesta: 'No tengo nada que contarte. Andate.' },
            { texto: 'Preguntar con firmeza, sin amenazar', correcta: true, respuesta: 'Una vez. No lo voy a olvidar tan fácil.' },
            { texto: 'Amenazarlo para que hable', correcta: false, respuesta: 'Con vos no hablo ni loco.' }
          ],
          pista: 'El propio Facundo llegó a pedir ayuda a hombres como este, cuando lo necesitaba'
        },
        {
          pregunta: '¿Es cierto que castigaba a cualquiera que lo desafiara?',
          tonos: [
            { texto: 'Amenazarlo', correcta: false, respuesta: 'Cuidado con lo que decís. Yo no debo nada.' },
            { texto: 'Preguntar con respeto', correcta: false, respuesta: 'Prefiero no hablar de eso.' },
            { texto: 'Hablarle de igual a igual, sin miedo', correcta: true, respuesta: 'Sí. Y no hacía falta que fueras culpable de nada.' }
          ],
          pista: 'Aplicaba castigos duros incluso sin pruebas claras de que hubiera una falta real'
        },
        {
          pregunta: '¿Por qué terminó como terminó?',
          tonos: [
            { texto: 'Preguntar con firmeza', correcta: true, respuesta: 'Porque se hizo enemigos poderosos, y esos no perdonan.' },
            { texto: 'Amenazarlo', correcta: false, respuesta: 'No me vas a asustar, muchacho.' },
            { texto: 'Preguntar con respeto', correcta: false, respuesta: 'Eso mejor no lo pregunto yo.' }
          ],
          pista: 'Sus propios enemigos políticos prepararon su muerte en una emboscada'
        }
      ]
    }
  },
  {
    id: 'cantor',
    nombre: 'EL CANTOR',
    apodo: 'Payador que compuso versos sobre Facundo',
    retrato: 'retrato-cantor',
    presentacion:
      'Canta lo que otros solo cuentan en voz baja. Sus versos quedaron incompletos: hay que saber con qué palabra se cierran para entender la pista.',
    tipoMecanica: 'cantor',
    datosMecanica: {
      versos: [
        {
          texto: 'En los Llanos de la Rioja, ___ nació el que después fue temido.',
          opciones: ['un gaucho humilde', 'un noble extranjero', 'un militar europeo'],
          correcta: 0,
          pista: 'Facundo nació en los Llanos de la Rioja, hijo de un gaucho humilde'
        },
        {
          texto: 'No hubo cuartel que lo domara, porque su alma pedía ___.',
          opciones: ['mandar y no obedecer', 'estudiar y aprender', 'servir en silencio'],
          correcta: 0,
          pista: 'Su carácter pedía mandar, no obedecer: por eso no toleró la vida militar regular'
        },
        {
          texto: 'Y en Barranca Yaco, una tarde, ___ selló su historia.',
          opciones: ['una emboscada', 'una fiesta popular', 'un largo viaje'],
          correcta: 0,
          pista: 'Fue asesinado en una emboscada en Barranca Yaco'
        }
      ]
    }
  }
];

/**
 * Cuestionario final del Nivel 2. Se habilita cuando los cuatro personajes
 * ya fueron interrogados y sus doce pistas quedaron recolectadas.
 */
const preguntasNivelDos = [
  {
    q: 'Según lo que reconstruyó el Rastreador, ¿por qué Facundo no continuó su carrera en el ejército regular?',
    options: [
      'Porque desertó y volvió a los Llanos, donde empezó a hacerse temer',
      'Porque fue expulsado por no saber montar a caballo',
      'Porque prefería estudiar leyes en la ciudad'
    ],
    answer: 0,
    explain: 'El rastro que siguió el Rastreador muestra que Facundo fue recluta, desertó y volvió a los Llanos, donde empezó a hacerse temer entre los gauchos.'
  },
  {
    q: '¿Qué le permitía a Facundo dominar militarmente el interior del país?',
    options: [
      'Su conocimiento del terreno y la velocidad de sus tropas',
      'Un ejército europeo entrenado en Buenos Aires',
      'El apoyo exclusivo de un gobierno extranjero'
    ],
    answer: 0,
    explain: 'El Baqueano explica que Facundo, como buen conocedor del terreno, usaba caminos ocultos, sabía encontrar agua y orientarse de noche.'
  },
  {
    q: '¿Qué hecho marcó el fin de su poder?',
    options: [
      'Sus enemigos políticos prepararon una emboscada en Barranca Yaco',
      'Se retiró pacíficamente a Chile',
      'Ganó todas sus batallas hasta el final de su vida'
    ],
    answer: 0,
    explain: 'El Gaucho Malo cuenta que Facundo se hizo enemigos poderosos, que finalmente prepararon su muerte en una emboscada en Barranca Yaco.'
  },
  {
    q: '¿Por qué los cuatro testigos dan versiones distintas sobre Facundo?',
    options: [
      'Porque cada uno lo vivió desde un lugar distinto: temor, alianza o admiración',
      'Porque ninguno de los cuatro lo conoció realmente',
      'Porque todos se pusieron de acuerdo para mentir'
    ],
    answer: 0,
    explain: 'El Rastreador, el Baqueano, el Gaucho Malo y el Cantor conocieron a Facundo desde distintas posiciones, y por eso cada versión resalta un aspecto diferente del mismo personaje histórico.'
  }
];

/**
 * Grupos del tablero final. Cada grupo reúne las tres pistas de un mismo
 * personaje, igual que en el Nivel 1 cada grupo reunía las tres frases
 * clave de un mismo diario.
 */
const gruposTableroNivelDos = [
  {
    id: 'caracter-juventud',
    title: 'CARÁCTER Y JUVENTUD DE FACUNDO',
    fragments: [
      { text: 'Antes de ser caudillo, Facundo fue un simple recluta del ejército en Buenos Aires', source: 'EL RASTREADOR' },
      { text: 'Desertó y volvió a los Llanos, donde empezó a hacerse temer entre los gauchos', source: 'EL RASTREADOR' },
      { text: 'Terminó reuniendo bajo su mando a buena parte de los Llanos de la Rioja', source: 'EL RASTREADOR' }
    ]
  },
  {
    id: 'dominio-territorio',
    title: 'DOMINIO DEL TERRITORIO',
    fragments: [
      { text: 'Facundo usaba caminos ocultos para moverse sin ser detectado por sus enemigos', source: 'EL BAQUEANO' },
      { text: 'Un baqueano reconoce el agua oculta por la vegetación y el tipo de suelo', source: 'EL BAQUEANO' },
      { text: 'De noche, el baqueano se orientaba por los árboles y la inclinación del terreno', source: 'EL BAQUEANO' }
    ]
  },
  {
    id: 'violencia-caida',
    title: 'VIOLENCIA Y CAÍDA DEL CAUDILLO',
    fragments: [
      { text: 'El propio Facundo llegó a pedir ayuda a hombres como este, cuando lo necesitaba', source: 'EL GAUCHO MALO' },
      { text: 'Aplicaba castigos duros incluso sin pruebas claras de que hubiera una falta real', source: 'EL GAUCHO MALO' },
      { text: 'Sus propios enemigos políticos prepararon su muerte en una emboscada', source: 'EL GAUCHO MALO' }
    ]
  },
  {
    id: 'memoria-popular',
    title: 'FACUNDO EN LA MEMORIA POPULAR',
    fragments: [
      { text: 'Facundo nació en los Llanos de la Rioja, hijo de un gaucho humilde', source: 'EL CANTOR' },
      { text: 'Su carácter pedía mandar, no obedecer: por eso no toleró la vida militar regular', source: 'EL CANTOR' },
      { text: 'Fue asesinado en una emboscada en Barranca Yaco', source: 'EL CANTOR' }
    ]
  }
];

const recortesTableroNivelDos = gruposTableroNivelDos.flatMap((grupo) =>
  grupo.fragments.map((fragmento, indiceFragmento) => ({
    id: `${grupo.id}-${indiceFragmento}`,
    groupId: grupo.id,
    groupTitle: grupo.title,
    text: fragmento.text,
    source: fragmento.source
  }))
);

export {
  personajesNivelDos,
  preguntasNivelDos,
  gruposTableroNivelDos,
  recortesTableroNivelDos
};
