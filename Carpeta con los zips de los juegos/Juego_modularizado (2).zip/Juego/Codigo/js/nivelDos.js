/**
 * Orquestador del Nivel 2 · "Voces en la Pulpería".
 * Coordina módulos especializados sin concentrar toda la lógica en una sola
 * clase, siguiendo el mismo patrón que nivelUno.js usa para el Nivel 1.
 *
 * Reutiliza sin modificar GestorPreguntas y GestorTablero (ya genéricos),
 * y agrega GestorInterrogatorio como reemplazo de GestorDiarios, adaptado
 * a la mecánica propia de este nivel: preguntar y recolectar pistas.
 */

import {
  personajesNivelDos,
  preguntasNivelDos,
  gruposTableroNivelDos,
  recortesTableroNivelDos
} from './datosNivelDos.js';
import { EstadoNivelDos } from './estadoNivelDos.js';
import { obtenerElementosNivelDos } from './interfazNivelDos.js';
import { alternarPantalla, ocultar } from './interfaz.js';
import { GestorInterrogatorio } from './interrogatorio.js';
import { GestorPreguntas } from './preguntas.js';
import { GestorTablero } from './tablero.js';

class NivelDos {
  constructor(audio, alSalir) {
    this.audio = audio;
    this.alSalir = alSalir;
    this.elementos = obtenerElementosNivelDos();
    this.estado = new EstadoNivelDos();

    this.gestorInterrogatorio = new GestorInterrogatorio({
      elementos: this.elementos,
      estado: this.estado,
      personajes: personajesNivelDos,
      audio: this.audio,
      alCompletarTodos: () => this.gestorPreguntas.abrir()
    });

    this.gestorPreguntas = new GestorPreguntas({
      elementos: this.elementos,
      estado: this.estado,
      preguntas: preguntasNivelDos,
      audio: this.audio,
      alFinalizar: () => this.gestorTablero.abrir()
    });

    this.gestorTablero = new GestorTablero({
      elementos: this.elementos,
      estado: this.estado,
      grupos: gruposTableroNivelDos,
      recortes: recortesTableroNivelDos,
      audio: this.audio,
      alFinalizar: () => this.finalizarNivel()
    });

    this.inicializarEventos();
  }

  /** Conecta los eventos de todos los sub-gestores y el botón de volver al menú. */
  inicializarEventos() {
    this.gestorInterrogatorio.inicializarEventos();
    this.gestorPreguntas.inicializarEventos();
    this.gestorTablero.inicializarEventos();

    this.elementos.botonVolverMenu.addEventListener('click', () => {
      this.audio.reproducirClick();
      this.alSalir(2);
    });
  }

  /** Punto de entrada al nivel: reinicia el estado y muestra la pantalla. */
  iniciar() {
    this.reiniciar();
    this.audio.reproducirClick();
    alternarPantalla(this.elementos.juegoPantalla, true);
  }

  /** Vuelve el nivel a su estado inicial, por si se juega más de una vez. */
  reiniciar() {
    this.estado.reiniciar();

    document.querySelectorAll('.personaje').forEach((personaje) => {
      personaje.classList.remove('interrogado');
    });

    this.gestorInterrogatorio.iniciar();

    Object.values(this.elementos.escenasMecanica).forEach((escena) => ocultar(escena.raiz));
    [
      this.elementos.cuestionarioModal,
      this.elementos.tableroModal,
      this.elementos.nivelCompletadoModal
    ].forEach(ocultar);
  }

  /** Muestra el resumen final con los resultados del interrogatorio, el cuestionario y el tablero. */
  finalizarNivel() {
    this.elementos.resultadoPersonajes.textContent =
      `${this.estado.personajesInterrogados.size} / ${personajesNivelDos.length} TESTIGOS`;
    this.elementos.resultadoPreguntas.textContent =
      `${this.estado.puntuacionPreguntas} / ${preguntasNivelDos.length} RESPUESTAS · ${this.estado.puntuacionTablero} / ${gruposTableroNivelDos.length} VERSIONES`;

    this.elementos.nivelCompletadoModal.classList.remove('hidden');
    this.audio.reproducirClick();
  }
}

export { NivelDos };
