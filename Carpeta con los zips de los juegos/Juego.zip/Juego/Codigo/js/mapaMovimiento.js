/**
 * Movimiento del jugador sobre el mapa del pueblo (Nivel 2).
 *
 * Reemplaza la vieja "fila de botones" de la pulpería por un mapa que se
 * recorre de verdad con WASD o las flechas: el jugador es un puntito que
 * se mueve sobre la ilustración del pueblo y, al acercarse a un
 * personaje, puede hablarle con ESPACIO (o clic, que sigue funcionando
 * igual que antes).
 *
 * El Baqueano es el único que puede indicar el camino de salida del
 * pueblo, así que se lo marca como "bloqueado" (visualmente esquivo, sin
 * poder hablarle) hasta que los otros tres testigos ya fueron
 * interrogados. La decisión de bloquear la interacción de verdad vive en
 * GestorInterrogatorio (que es quien conoce las reglas del nivel); este
 * gestor solo se encarga de mover al jugador, detectar cercanía y avisar
 * visualmente cuál personaje todavía no se puede abrir.
 */

import { establecerTexto } from './interfaz.js';

const VELOCIDAD_PX_POR_SEG = 220;
const RADIO_INTERACCION_PX = 90;
const TECLAS_MOVIMIENTO = new Set(['w', 'a', 's', 'd', 'arrowup', 'arrowdown', 'arrowleft', 'arrowright']);

class GestorMapa {
  constructor({ elementos, estado, alInteractuar }) {
    this.elementos = elementos;
    this.estado = estado;
    this.alInteractuar = alInteractuar;

    this.teclasPresionadas = new Set();
    this.activo = false;
    this.ultimoTiempo = null;
    this.personajeCercano = null;
    this.posicion = { x: 18, y: 82 };

    this.alPresionarTecla = this.alPresionarTecla.bind(this);
    this.alSoltarTecla = this.alSoltarTecla.bind(this);
  }

  /** Engancha los listeners de teclado una sola vez, al armar el nivel. */
  inicializarEventos() {
    window.addEventListener('keydown', this.alPresionarTecla);
    window.addEventListener('keyup', this.alSoltarTecla);
  }

  alPresionarTecla(evento) {
    if (!this.activo) return;
    const tecla = evento.key.toLowerCase();

    if (TECLAS_MOVIMIENTO.has(tecla)) {
      evento.preventDefault();
      this.teclasPresionadas.add(tecla);
    }

    if ((tecla === ' ' || tecla === 'enter') && this.personajeCercano !== null) {
      evento.preventDefault();
      this.alInteractuar(this.personajeCercano);
    }
  }

  alSoltarTecla(evento) {
    this.teclasPresionadas.delete(evento.key.toLowerCase());
  }

  /** Pone al jugador en su punto de partida y arranca el bucle de movimiento. */
  iniciar() {
    this.posicion = { x: 18, y: 82 };
    this.aplicarPosicion();
    this.personajeCercano = null;
    this.teclasPresionadas.clear();
    this.ultimoTiempo = null;
    this.activo = true;
    requestAnimationFrame((tiempo) => this.recorrerBucle(tiempo));
  }

  /** Frena el movimiento (se llama al salir del nivel del todo). */
  detener() {
    this.activo = false;
    this.teclasPresionadas.clear();
  }

  recorrerBucle(tiempo) {
    if (!this.activo) return;

    // Mientras el jugador está adentro del minijuego de un personaje, la
    // escena del mundo queda oculta: el bucle sigue vivo pero no mueve
    // ni gasta tiempo, así al volver no hay ningún salto raro.
    if (this.elementos.juegoPantalla.classList.contains('hidden')) {
      this.ultimoTiempo = null;
      requestAnimationFrame((t) => this.recorrerBucle(t));
      return;
    }

    const delta = this.ultimoTiempo === null ? 0 : (tiempo - this.ultimoTiempo) / 1000;
    this.ultimoTiempo = tiempo;

    this.mover(delta);
    this.actualizarProximidad();

    requestAnimationFrame((t) => this.recorrerBucle(t));
  }

  mover(delta) {
    if (delta <= 0) return;

    const rect = this.elementos.escenaMundo.getBoundingClientRect();
    if (!rect.width || !rect.height) return;

    let dx = 0;
    let dy = 0;
    if (this.teclasPresionadas.has('a') || this.teclasPresionadas.has('arrowleft')) dx -= 1;
    if (this.teclasPresionadas.has('d') || this.teclasPresionadas.has('arrowright')) dx += 1;
    if (this.teclasPresionadas.has('w') || this.teclasPresionadas.has('arrowup')) dy -= 1;
    if (this.teclasPresionadas.has('s') || this.teclasPresionadas.has('arrowdown')) dy += 1;

    if (dx === 0 && dy === 0) return;

    // Normalizar para que moverse en diagonal no sea más rápido.
    const largo = Math.hypot(dx, dy) || 1;
    const desplazamientoX = (dx / largo) * VELOCIDAD_PX_POR_SEG * delta;
    const desplazamientoY = (dy / largo) * VELOCIDAD_PX_POR_SEG * delta;

    this.posicion.x += (desplazamientoX / rect.width) * 100;
    this.posicion.y += (desplazamientoY / rect.height) * 100;

    // Límites simples para no salirse del recuadro del mapa.
    this.posicion.x = Math.min(96, Math.max(3, this.posicion.x));
    this.posicion.y = Math.min(96, Math.max(14, this.posicion.y));

    this.aplicarPosicion();
  }

  aplicarPosicion() {
    this.elementos.jugadorMapa.style.left = `${this.posicion.x}%`;
    this.elementos.jugadorMapa.style.top = `${this.posicion.y}%`;
  }

  /**
   * Revisa la distancia del jugador a cada personaje, marca visualmente
   * cuál está cerca (o bloqueado, si es el Baqueano y todavía faltan los
   * otros tres) y actualiza el cartel de ayuda.
   */
  actualizarProximidad() {
    const rectJugador = this.elementos.jugadorMapa.getBoundingClientRect();
    const centroJugador = {
      x: rectJugador.left + rectJugador.width / 2,
      y: rectJugador.top + rectJugador.height / 2
    };

    let indiceMasCercano = null;
    let menorDistancia = RADIO_INTERACCION_PX;

    document.querySelectorAll('.personaje').forEach((boton) => {
      const indice = Number(boton.dataset.personaje);
      const yaInterrogado = this.estado.personajesInterrogados.has(indice);
      const esBaqueano = indice === 1;
      const bloqueado = esBaqueano
        && !yaInterrogado
        && this.estado.personajesInterrogados.size < 3;

      boton.classList.toggle('personaje-bloqueado', bloqueado);

      if (yaInterrogado || bloqueado) {
        boton.classList.remove('personaje-cerca');
        return;
      }

      const rectBoton = boton.getBoundingClientRect();
      const centroBoton = {
        x: rectBoton.left + rectBoton.width / 2,
        y: rectBoton.top + rectBoton.height * 0.3
      };
      const distancia = Math.hypot(centroJugador.x - centroBoton.x, centroJugador.y - centroBoton.y);

      boton.classList.toggle('personaje-cerca', distancia < RADIO_INTERACCION_PX);

      if (distancia < menorDistancia) {
        menorDistancia = distancia;
        indiceMasCercano = indice;
      }
    });

    if (indiceMasCercano === this.personajeCercano) return;
    this.personajeCercano = indiceMasCercano;

    if (indiceMasCercano === null) {
      establecerTexto(this.elementos.pistaInteraccion, 'MOVETE CON WASD O LAS FLECHAS Y ACERCATE A UN PERSONAJE');
      return;
    }

    const nombre = document
      .querySelector(`.personaje[data-personaje="${indiceMasCercano}"] .personaje-etiqueta`)
      ?.textContent || '';
    establecerTexto(this.elementos.pistaInteraccion, `PRESIONÁ ESPACIO PARA HABLAR CON ${nombre}`);
  }
}

export { GestorMapa };
