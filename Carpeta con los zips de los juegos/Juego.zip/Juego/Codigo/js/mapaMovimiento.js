/**
 * Movimiento del jugador sobre el mapa del pueblo (Nivel 2).
 *
 * Reemplaza la vieja "fila de botones" de la pulpería por un mapa que se
 * recorre de verdad con WASD o las flechas: el jugador es un puntito que
 * se mueve sobre la ilustración del pueblo y, al acercarse a un
 * personaje, puede hablarle con ESPACIO (o clic, que sigue funcionando
 * igual que antes).
 *
 * El Baqueano es el único que puede indicar el camino de salida del
 * pueblo, así que se lo marca como "bloqueado" (visualmente esquivo, sin
 * poder hablarle) hasta que los otros tres testigos ya fueron
 * interrogados. La decisión de bloquear la interacción de verdad vive en
 * GestorInterrogatorio (que es quien conoce las reglas del nivel); este
 * gestor solo se encarga de mover al jugador, detectar cercanía y avisar
 * visualmente cuál personaje todavía no se puede abrir.
 */

import { establecerTexto } from './interfaz.js';

const VELOCIDAD_PX_POR_SEG = 220;
const RADIO_INTERACCION_PX = 90;
const TECLAS_MOVIMIENTO = new Set(['w', 'a', 's', 'd', 'arrowup', 'arrowdown', 'arrowleft', 'arrowright']);

// El "mundo" (#mundo-dos) es más grande que la ventana visible
// (#game-world-dos): ZOOM_MUNDO define cuánto. La cámara después vuelve
// a agrandar ese mundo sobre la pantalla con ZOOM_CAMARA. Son dos zooms
// independientes a propósito: ZOOM_MUNDO controla cuánto mapa entra en
// pantalla (cuánto hay que caminar), ZOOM_CAMARA controla qué tan cerca
// se ve todo. Subir ZOOM_CAMARA agranda la escena sin cambiar el
// recorrido; subir ZOOM_MUNDO agranda el recorrido sin cambiar el
// acercamiento visual.
const ZOOM_MUNDO = 1.6;
const ZOOM_CAMARA = 1.6;

// Colisiones del pueblo, todas rectangulares, en % del tamaño del MUNDO
// (no de la pantalla ni del viewport). Coordenadas medidas por análisis
// de píxeles sobre los rectángulos blancos que marcaste en la imagen
// (no a ojo). Para agregar o mover algo, sumá/edita una entrada acá.
const COLISIONES_MUNDO = [
  // --- Edificios ---
  { nombre: 'casa-galeria', xMin: 20.3, xMax: 41.6, yMin: 0.7, yMax: 19.5 },
  { nombre: 'casa-medio', xMin: 19.6, xMax: 32.9, yMin: 26.0, yMax: 47.9 },
  { nombre: 'casa-aislada', xMin: 5.9, xMax: 15.8, yMin: 32.0, yMax: 64.6 },
  { nombre: 'casa-abajo', xMin: 20.1, xMax: 32.8, yMin: 61.8, yMax: 85.9 },
  { nombre: 'pulperia', xMin: 41.2, xMax: 64.3, yMin: 0.7, yMax: 32.6 },
  { nombre: 'pulperia-anexo', xMin: 64.7, xMax: 70.6, yMin: 7.2, yMax: 21.5 },
  { nombre: 'cartel', xMin: 73.4, xMax: 82.8, yMin: 32.6, yMax: 51.8 },

  // --- Objetos chicos ---
  { nombre: 'crate-galeria', xMin: 20.3, xMax: 25.1, yMin: 19.5, yMax: 26.0 },
  { nombre: 'crate-medio', xMin: 33.1, xMax: 35.3, yMin: 42.2, yMax: 46.7 },
  { nombre: 'barril-abajo', xMin: 34.7, xMax: 38.1, yMin: 65.1, yMax: 71.4 },
  { nombre: 'crate-abajo', xMin: 34.7, xMax: 38.1, yMin: 78.1, yMax: 84.6 },
  { nombre: 'crate-cartel', xMin: 79.8, xMax: 81.8, yMin: 52.2, yMax: 55.3 },
  { nombre: 'crate-cartel-2', xMin: 76.2, xMax: 79.9, yMin: 79.7, yMax: 88.0 },
  { nombre: 'valla-pulperia', xMin: 70.6, xMax: 82.3, yMin: 21.5, yMax: 28.6 },
  { nombre: 'maceta-izquierda', xMin: 45.0, xMax: 47.8, yMin: 29.3, yMax: 37.1 },
  { nombre: 'maceta-derecha', xMin: 49.3, xMax: 51.4, yMin: 29.3, yMax: 34.1 },
  { nombre: 'fuente', xMin: 45.9, xMax: 54.9, yMin: 49.2, yMax: 65.4 },

  // Poste/tranquera: partido en dos tramos para dejar un hueco donde
  // cruzarlo (el pasillo que conecta la casa-aislada con la plaza).
  // Antes era un solo rectángulo de punta a punta; ahora hay un corte
  // libre entre yMin 50.8 y yMax 61.7 (justo donde estaba el jugador
  // trabado).
  { nombre: 'poste-superior', xMin: 18.0, xMax: 19.5, yMin: 0, yMax: 50.8 },
  { nombre: 'poste-inferior', xMin: 18.0, xMax: 19.5, yMin: 61.7, yMax: 85.9 },

  // --- Árboles ---
  { nombre: 'arbol-doble-noroeste', xMin: 0, xMax: 28.0, yMin: 11.7, yMax: 26.0 },
  { nombre: 'arbol-suelto-oeste', xMin: 0, xMax: 8.7, yMin: 26.0, yMax: 41.7 },
  { nombre: 'bosque-suroeste', xMin: 0, xMax: 13.0, yMin: 52.6, yMax: 100 },
  { nombre: 'arbol-abajo-izquierda', xMin: 0, xMax: 5.5, yMin: 94.7, yMax: 100 },
  { nombre: 'arbol-abajo-centro-1', xMin: 20.9, xMax: 27.4, yMin: 95.8, yMax: 100 },
  { nombre: 'arbol-abajo-centro-2', xMin: 34.7, xMax: 43.7, yMin: 89.3, yMax: 100 },
  { nombre: 'arbol-abajo-centro-3', xMin: 56.9, xMax: 62.4, yMin: 92.1, yMax: 100 },
  { nombre: 'arbol-torre-1', xMin: 64.6, xMax: 70.6, yMin: 0, yMax: 6.9 },
  { nombre: 'arbol-torre-2', xMin: 70.6, xMax: 78.5, yMin: 0, yMax: 7.2 },
  { nombre: 'arbol-pulperia-grande', xMin: 70.6, xMax: 79.9, yMin: 8.5, yMax: 23.4 },
  { nombre: 'arbol-esquina-ne', xMin: 79.3, xMax: 85.1, yMin: 20.6, yMax: 32.8 },
  { nombre: 'arbol-lejano-ne', xMin: 92.7, xMax: 99.9, yMin: 26.8, yMax: 43.8 },
  { nombre: 'arbol-fuente', xMin: 63.1, xMax: 70.0, yMin: 41.1, yMax: 53.6 },
  { nombre: 'arbol-derecha-media', xMin: 86.1, xMax: 92.0, yMin: 71.1, yMax: 83.3 },
  { nombre: 'arbol-derecha-lejos', xMin: 96.0, xMax: 100, yMin: 61.8, yMax: 80.1 },
  { nombre: 'arbol-abajo-derecha', xMin: 73.5, xMax: 86.5, yMin: 88.3, yMax: 100 },
  { nombre: 'arbol-abajo-lejos', xMin: 94.1, xMax: 100, yMin: 88.9, yMax: 100 }
];

class GestorMapa {
  constructor({ elementos, estado, alInteractuar }) {
    this.elementos = elementos;
    this.estado = estado;
    this.alInteractuar = alInteractuar;

    this.teclasPresionadas = new Set();
    this.activo = false;
    this.ultimoTiempo = null;
    this.personajeCercano = null;

    // Posición del jugador en px DEL MUNDO (no % de pantalla, no px de
    // viewport). Se inicializa de verdad en iniciar(), una vez que ya
    // conocemos el tamaño real del mundo.
    this.posicion = { x: 0, y: 0 };
    this.mundoAncho = 0;
    this.mundoAlto = 0;

    this.alPresionarTecla = this.alPresionarTecla.bind(this);
    this.alSoltarTecla = this.alSoltarTecla.bind(this);
    this.alRedimensionar = this.alRedimensionar.bind(this);
  }

  /** Engancha los listeners de teclado y de resize una sola vez, al armar el nivel. */
  inicializarEventos() {
    window.addEventListener('keydown', this.alPresionarTecla);
    window.addEventListener('keyup', this.alSoltarTecla);
    window.addEventListener('resize', this.alRedimensionar);
  }

  /**
   * Si la ventana cambia de tamaño, el mundo (que depende del viewport
   * vía ZOOM_MUNDO) también cambia, así que hay que recalcularlo y
   * reubicar tanto al jugador (para que no quede "flotando" en un %
   * que ya no corresponde) como la cámara.
   */
  alRedimensionar() {
    if (!this.activo || !this.mundoAncho || !this.mundoAlto) return;
    const xPorcentaje = this.posicion.x / this.mundoAncho;
    const yPorcentaje = this.posicion.y / this.mundoAlto;
    this.calcularTamanioMundo();
    this.posicion.x = xPorcentaje * this.mundoAncho;
    this.posicion.y = yPorcentaje * this.mundoAlto;
    this.aplicarPosicion();
    this.actualizarCamara();
  }

  /**
   * Fija el tamaño en px de #mundo-dos a partir del tamaño actual del
   * visor (#game-world-dos) multiplicado por ZOOM_MUNDO. Hay que
   * llamarla antes de convertir cualquier % a px del mundo.
   */
  calcularTamanioMundo() {
    const rect = this.elementos.escenaMundo.getBoundingClientRect();
    if (!rect.width || !rect.height) return;

    const anchoViewport = rect.width;
    const altoViewport = rect.height;

    this.mundoAncho = anchoViewport * ZOOM_MUNDO;
    this.mundoAlto = altoViewport * ZOOM_MUNDO;

    this.elementos.mundoMapa.style.width = `${this.mundoAncho}px`;
    this.elementos.mundoMapa.style.height = `${this.mundoAlto}px`;
  }

  alPresionarTecla(evento) {
    if (!this.activo) return;
    const tecla = evento.key.toLowerCase();

    if (TECLAS_MOVIMIENTO.has(tecla)) {
      evento.preventDefault();
      this.teclasPresionadas.add(tecla);
    }

    if ((tecla === ' ' || tecla === 'enter') && this.personajeCercano !== null) {
      evento.preventDefault();
      this.alInteractuar(this.personajeCercano);
    }
  }

  alSoltarTecla(evento) {
    this.teclasPresionadas.delete(evento.key.toLowerCase());
  }

  /** Pone al jugador en su punto de partida y arranca el bucle de movimiento. */
  iniciar() {
    this.calcularTamanioMundo();

    // El punto de partida sigue siendo el mismo de siempre (18%, 82%),
    // solo que ahora se convierte a px del mundo ya calculado.
    this.posicion = {
      x: (18 / 100) * this.mundoAncho,
      y: (82 / 100) * this.mundoAlto
    };

    this.aplicarPosicion();
    this.actualizarCamara();
    this.personajeCercano = null;
    this.teclasPresionadas.clear();
    this.ultimoTiempo = null;
    this.activo = true;
    requestAnimationFrame((tiempo) => this.recorrerBucle(tiempo));
  }

  /** Frena el movimiento (se llama al salir del nivel del todo). */
  detener() {
    this.activo = false;
    this.teclasPresionadas.clear();
  }

  recorrerBucle(tiempo) {
    if (!this.activo) return;

    // Mientras el jugador está adentro del minijuego de un personaje, la
    // escena del mundo queda oculta: el bucle sigue vivo pero no mueve
    // ni gasta tiempo, así al volver no hay ningún salto raro.
    if (this.elementos.juegoPantalla.classList.contains('hidden')) {
      this.ultimoTiempo = null;
      requestAnimationFrame((t) => this.recorrerBucle(t));
      return;
    }

    const delta = this.ultimoTiempo === null ? 0 : (tiempo - this.ultimoTiempo) / 1000;
    this.ultimoTiempo = tiempo;

    this.mover(delta);
    this.actualizarProximidad();

    requestAnimationFrame((t) => this.recorrerBucle(t));
  }

  mover(delta) {
    if (delta <= 0) return;
    if (!this.mundoAncho || !this.mundoAlto) return;

    let dx = 0;
    let dy = 0;
    if (this.teclasPresionadas.has('a') || this.teclasPresionadas.has('arrowleft')) dx -= 1;
    if (this.teclasPresionadas.has('d') || this.teclasPresionadas.has('arrowright')) dx += 1;
    if (this.teclasPresionadas.has('w') || this.teclasPresionadas.has('arrowup')) dy -= 1;
    if (this.teclasPresionadas.has('s') || this.teclasPresionadas.has('arrowdown')) dy += 1;

    if (dx === 0 && dy === 0) return;

    // Normalizar para que moverse en diagonal no sea más rápido. La
    // velocidad se mide en px del MUNDO por segundo, así que no depende
    // del zoom de cámara (subir ZOOM_CAMARA no hace correr más rápido
    // ni más lento al personaje, solo se ve todo más grande).
    const largo = Math.hypot(dx, dy) || 1;
    const desplazamientoX = (dx / largo) * VELOCIDAD_PX_POR_SEG * delta;
    const desplazamientoY = (dy / largo) * VELOCIDAD_PX_POR_SEG * delta;

    // Límites del recuadro del mapa, iguales a los de antes (3%-96% en
    // X, 14%-96% en Y) pero ahora expresados en px del mundo.
    const limiteXMin = 0.03 * this.mundoAncho;
    const limiteXMax = 0.96 * this.mundoAncho;
    const limiteYMin = 0.14 * this.mundoAlto;
    const limiteYMax = 0.96 * this.mundoAlto;

    const xPropuesto = Math.min(limiteXMax, Math.max(limiteXMin, this.posicion.x + desplazamientoX));
    const yPropuesto = Math.min(limiteYMax, Math.max(limiteYMin, this.posicion.y + desplazamientoY));

    // Cada eje se resuelve por separado: así, si el jugador choca de
    // frente contra un edificio en diagonal, igual puede "deslizarse"
    // por el borde en el eje libre, en vez de quedar trabado.
    if (!this.colisionaConEdificio(xPropuesto, this.posicion.y)) {
      this.posicion.x = xPropuesto;
    }
    if (!this.colisionaConEdificio(this.posicion.x, yPropuesto)) {
      this.posicion.y = yPropuesto;
    }

    this.aplicarPosicion();
    this.actualizarCamara();
  }

  /** True si el punto (x, y), en px del mundo, cae dentro de algún obstáculo. */
  colisionaConEdificio(x, y) {
    const xPorcentaje = (x / this.mundoAncho) * 100;
    const yPorcentaje = (y / this.mundoAlto) * 100;

    return COLISIONES_MUNDO.some((obstaculo) =>
      xPorcentaje >= obstaculo.xMin && xPorcentaje <= obstaculo.xMax &&
      yPorcentaje >= obstaculo.yMin && yPorcentaje <= obstaculo.yMax
    );
  }

  aplicarPosicion() {
    this.elementos.jugadorMapa.style.left = `${this.posicion.x}px`;
    this.elementos.jugadorMapa.style.top = `${this.posicion.y}px`;
  }

  /**
   * Mueve y escala #mundo-dos para que el jugador quede centrado en la
   * pantalla, con zoom ZOOM_CAMARA. #mundo-dos tiene transform-origin
   * en 0 0 (ver nivelDos.css), así que un punto (x, y) del mundo cae en
   * pantalla en (offsetX + x*ZOOM_CAMARA, offsetY + y*ZOOM_CAMARA).
   * Para centrar al jugador despejamos offsetX/offsetY de esa fórmula
   * pidiendo que el punto del jugador caiga en el centro del visor.
   */
  actualizarCamara() {
    if (!this.mundoAncho || !this.mundoAlto) return;

    const rectEscena = this.elementos.escenaMundo.getBoundingClientRect();
    const centroX = rectEscena.width / 2;
    const centroY = rectEscena.height / 2;

    let offsetX = centroX - this.posicion.x * ZOOM_CAMARA;
    let offsetY = centroY - this.posicion.y * ZOOM_CAMARA;

    // Clamp para no dejar ver "más allá" del borde del mundo escalado
    // (fondo negro de .pulperia-scene) salvo que el mundo sea más chico
    // que el visor en ese eje, caso en el que no hay nada que clampear.
    const mundoEscaladoAncho = this.mundoAncho * ZOOM_CAMARA;
    const mundoEscaladoAlto = this.mundoAlto * ZOOM_CAMARA;

    const offsetXMin = Math.min(0, rectEscena.width - mundoEscaladoAncho);
    const offsetYMin = Math.min(0, rectEscena.height - mundoEscaladoAlto);

    offsetX = Math.min(0, Math.max(offsetXMin, offsetX));
    offsetY = Math.min(0, Math.max(offsetYMin, offsetY));

    this.elementos.mundoMapa.style.transform =
      `translate(${offsetX}px, ${offsetY}px) scale(${ZOOM_CAMARA})`;
  }

  /**
   * Revisa la distancia del jugador a cada personaje, marca visualmente
   * cuál está cerca (o bloqueado, si es el Baqueano y todavía faltan los
   * otros tres) y actualiza el cartel de ayuda.
   */
  actualizarProximidad() {
    const rectJugador = this.elementos.jugadorMapa.getBoundingClientRect();
    const centroJugador = {
      x: rectJugador.left + rectJugador.width / 2,
      y: rectJugador.top + rectJugador.height / 2
    };

    let indiceMasCercano = null;
    let menorDistancia = RADIO_INTERACCION_PX;

    document.querySelectorAll('.personaje').forEach((boton) => {
      const indice = Number(boton.dataset.personaje);
      const yaInterrogado = this.estado.personajesInterrogados.has(indice);
      const esBaqueano = indice === 1;
      const bloqueado = esBaqueano
        && !yaInterrogado
        && this.estado.personajesInterrogados.size < 3;

      boton.classList.toggle('personaje-bloqueado', bloqueado);

      if (yaInterrogado || bloqueado) {
        boton.classList.remove('personaje-cerca');
        return;
      }

      const rectBoton = boton.getBoundingClientRect();
      const centroBoton = {
        x: rectBoton.left + rectBoton.width / 2,
        y: rectBoton.top + rectBoton.height * 0.3
      };
      const distancia = Math.hypot(centroJugador.x - centroBoton.x, centroJugador.y - centroBoton.y);

      boton.classList.toggle('personaje-cerca', distancia < RADIO_INTERACCION_PX);

      if (distancia < menorDistancia) {
        menorDistancia = distancia;
        indiceMasCercano = indice;
      }
    });

    if (indiceMasCercano === this.personajeCercano) return;
    this.personajeCercano = indiceMasCercano;

    if (indiceMasCercano === null) {
      establecerTexto(this.elementos.pistaInteraccion, 'MOVETE CON WASD O LAS FLECHAS Y ACERCATE A UN PERSONAJE');
      return;
    }

    const nombre = document
      .querySelector(`.personaje[data-personaje="${indiceMasCercano}"] .personaje-etiqueta`)
      ?.textContent || '';
    establecerTexto(this.elementos.pistaInteraccion, `PRESIONÁ ESPACIO PARA HABLAR CON ${nombre}`);
  }
}

export { GestorMapa };
