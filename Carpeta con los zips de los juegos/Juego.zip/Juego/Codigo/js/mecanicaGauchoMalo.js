/**
 * Mecánica del Gaucho Malo: "Que no te agarren".
 *
 * Basada en el retrato que hace Sarmiento del gaucho malo en el Capítulo
 * 2 del Facundo: un proscrito perseguido por la justicia, que sobrevive
 * gracias a su desconfianza y a saber leer cada situación. En vez de
 * acertar "el tono" de una pregunta, acá cada una de las tres escenas
 * plantea una situación de riesgo con una partida (milicianos) buscando
 * a alguien, y el jugador elige cómo salir de esa.
 *
 * Cada situación ofrece tres salidas con distinto riesgo:
 *   - 'seguro'   → siempre funciona y entrega la pista.
 *   - 'riesgo'   → tiene una chance de fallar (moneda al aire); si sale
 *                  bien, igual entrega la pista, pero "raspando".
 *   - 'fracaso'  → una salida imprudente que siempre falla; no hay
 *                  penalidad real más que perder el turno, así que el
 *                  jugador puede probar otra opción sin trabarse.
 * Fallar no bloquea nada: el jugador puede reintentar la misma escena
 * con otra opción las veces que haga falta, igual que en la mecánica
 * original de tonos.
 */

class MecanicaGauchoMalo {
  constructor({ contenedor, datos, audio, onPista }) {
    this.contenedor = contenedor;
    this.situaciones = datos.situaciones;
    this.audio = audio;
    this.onPista = onPista;
    this.resueltas = new Set();
  }

  /** Cantidad total de pistas que entrega esta mecánica. */
  obtenerTotalPistas() {
    return this.situaciones.length;
  }

  /** Dibuja las tres escenas de persecución junto con sus salidas posibles. */
  render() {
    this.resueltas.clear();

    this.contenedor.innerHTML = this.situaciones.map((situacion, indiceSituacion) => `
      <div class="persecucion-item" data-index="${indiceSituacion}">
        <div class="persecucion-situacion">${situacion.texto}</div>
        <div class="persecucion-opciones">
          ${situacion.opciones.map((opcion, indiceOpcion) => `
            <button type="button" class="persecucion-boton" data-situacion="${indiceSituacion}" data-opcion="${indiceOpcion}">${opcion.texto}</button>
          `).join('')}
        </div>
        <div class="persecucion-resultado hidden" data-resultado="${indiceSituacion}"></div>
      </div>
    `).join('');

    this.contenedor.querySelectorAll('.persecucion-boton').forEach((boton) => {
      boton.addEventListener('mouseenter', () => this.audio.reproducirHover());
      boton.addEventListener('click', () => this.elegirOpcion(
        Number(boton.dataset.situacion),
        Number(boton.dataset.opcion),
        boton
      ));
    });
  }

  /** Resuelve la salida elegida para una escena puntual. */
  elegirOpcion(indiceSituacion, indiceOpcion, boton) {
    if (this.resueltas.has(indiceSituacion)) return;

    const situacion = this.situaciones[indiceSituacion];
    const opcion = situacion.opciones[indiceOpcion];
    const resultadoDiv = this.contenedor.querySelector(`.persecucion-resultado[data-resultado="${indiceSituacion}"]`);

    let logrado;
    let texto;

    if (opcion.tipo === 'seguro') {
      logrado = true;
      texto = opcion.respuesta;
    } else if (opcion.tipo === 'riesgo') {
      logrado = Math.random() < (opcion.probabilidadExito ?? 0.5);
      texto = logrado ? opcion.respuestaExito : opcion.respuestaFallo;
    } else {
      logrado = false;
      texto = opcion.respuesta;
    }

    resultadoDiv.textContent = texto;
    resultadoDiv.classList.remove('hidden');

    if (logrado) {
      this.resueltas.add(indiceSituacion);
      this.contenedor
        .querySelectorAll(`.persecucion-boton[data-situacion="${indiceSituacion}"]`)
        .forEach((b) => { b.disabled = true; });
      boton.classList.add('persecucion-correcto');
      this.audio.reproducirClick();
      this.onPista(indiceSituacion, situacion.pista);
      return;
    }

    boton.classList.add('persecucion-incorrecto');
    setTimeout(() => boton.classList.remove('persecucion-incorrecto'), 600);
  }
}

export { MecanicaGauchoMalo };
