/**
 * Orquestador del Nivel 1.
 * Coordina módulos especializados sin concentrar toda la lógica en una sola clase.
 */

import {
  diariosNivelUno,
  preguntasNivelUno,
  gruposTableroNivelUno,
  recortesTableroNivelUno
} from './datosNivelUno.js';
import { EstadoJuego } from './estadoJuego.js';
import { obtenerElementosNivelUno, alternarPantalla, ocultar, establecerTexto } from './interfaz.js';
import { GestorDiarios } from './diarios.js';
import { GestorPreguntas } from './preguntas.js';
import { GestorTablero } from './tablero.js';
import {
  guardarPartida,
  cargarPartida,
  existePartidaGuardada
} from './persistencia.js';
import { NIVEL_JUGABLE } from './configuracion.js';

class NivelUno {
  constructor(audio, alSalir) {
    this.audio = audio;
    this.alSalir = alSalir;
    this.elementos = obtenerElementosNivelUno();
    this.estado = new EstadoJuego();

    this.gestorDiarios = new GestorDiarios({
      elementos: this.elementos,
      estado: this.estado,
      diarios: diariosNivelUno,
      audio: this.audio,
      alCompletarTodos: () => this.gestorPreguntas.abrir()
    });

    this.gestorPreguntas = new GestorPreguntas({
      elementos: this.elementos,
      estado: this.estado,
      preguntas: preguntasNivelUno,
      audio: this.audio,
      alFinalizar: () => this.gestorTablero.abrir()
    });

    this.gestorTablero = new GestorTablero({
      elementos: this.elementos,
      estado: this.estado,
      grupos: gruposTableroNivelUno,
      recortes: recortesTableroNivelUno,
      audio: this.audio,
      alFinalizar: () => this.finalizarNivel()
    });

    this.inicializarEventos();
  }

  inicializarEventos() {
    this.gestorDiarios.inicializarEventos();
    this.gestorPreguntas.inicializarEventos();
    this.gestorTablero.inicializarEventos();

    this.elementos.botonVolverMenu.addEventListener('click', () => {
      this.audio.reproducirClick();
      this.audio.detenerHojas();
      this.alSalir(1);
    });

    this.elementos.botonGuardarPartida.addEventListener('click', () => this.guardar());
    this.elementos.botonCargarPartida.addEventListener('click', () => this.cargar());
  }

  iniciar() {
    this.reiniciar();
    this.actualizarDisponibilidadCarga();
    this.audio.reproducirClick();
    alternarPantalla(this.elementos.juegoPantalla, true);
  }

  actualizarDisponibilidadCarga() {
    this.elementos.botonCargarPartida.disabled = !existePartidaGuardada();
  }

  mostrarMensajePartida(texto, esError = false) {
    establecerTexto(this.elementos.mensajePartida, texto);
    this.elementos.mensajePartida.classList.toggle('es-error', esError);
  }

  guardar() {
    this.audio.reproducirClick();
    guardarPartida(NIVEL_JUGABLE, this.estado).then((resultado) => {
      if (resultado.exito) {
        this.mostrarMensajePartida('PARTIDA GUARDADA CORRECTAMENTE.');
        this.actualizarDisponibilidadCarga();
      } else {
        this.mostrarMensajePartida(resultado.error.toUpperCase(), true);
      }
    });
  }

  cargar() {
    this.audio.reproducirClick();
    cargarPartida().then((partida) => {
      if (!partida || partida.nivel !== NIVEL_JUGABLE) {
        this.mostrarMensajePartida('NO HAY NINGUNA PARTIDA GUARDADA PARA ESTE NIVEL.', true);
        this.actualizarDisponibilidadCarga();
        return;
      }

      this.aplicarPartidaGuardada(partida);
      this.mostrarMensajePartida('PARTIDA RECUPERADA.');
    });
  }

  aplicarPartidaGuardada(partida) {
    this.estado.diariosRecolectados = new Set(partida.diariosRecolectados);
    this.estado.puntuacionPreguntas = partida.puntuacionPreguntas;
    this.estado.gruposTableroCompletados = new Set(partida.gruposTableroCompletados);
    this.estado.puntuacionTablero = partida.puntuacionTablero;

    document.querySelectorAll('.newspaper').forEach((diario) => {
      const indice = Number(diario.dataset.paper);
      diario.classList.toggle('collected', this.estado.diariosRecolectados.has(indice));
    });

    this.gestorDiarios.actualizarProgreso();

    if (this.estado.diariosRecolectados.size === diariosNivelUno.length) {
      establecerTexto(this.elementos.pistaInteraccion, 'TODOS LOS DIARIOS FUERON LEÍDOS · CONTINUÁ CON EL CUESTIONARIO');
      this.gestorPreguntas.abrir();
    }
  }

  reiniciar() {
    this.estado.reiniciar();

    document.querySelectorAll('.newspaper').forEach((diario) => {
      diario.classList.remove('collected');
    });

    this.gestorDiarios.iniciar();
    [
      this.elementos.diarioModal,
      this.elementos.cuestionarioModal,
      this.elementos.tableroModal,
      this.elementos.nivelCompletadoModal
    ].forEach(ocultar);

    this.audio.detenerHojas();
  }

  finalizarNivel() {
    this.elementos.resultadoDiarios.textContent =
      `${this.estado.diariosRecolectados.size} / ${diariosNivelUno.length} DIARIOS`;
    this.elementos.resultadoPreguntas.textContent =
      `${this.estado.puntuacionPreguntas} / ${preguntasNivelUno.length} RESPUESTAS · ${this.estado.puntuacionTablero} / ${gruposTableroNivelUno.length} TRÍADAS`;

    this.elementos.nivelCompletadoModal.classList.remove('hidden');
    this.audio.detenerHojas();
    this.audio.reproducirClick();
  }
}

export { NivelUno };
